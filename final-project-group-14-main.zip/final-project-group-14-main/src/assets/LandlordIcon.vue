<template>
<svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M16.666 0C12.266 0 8.66602 4.48 8.66602 10C8.66602 15.52 12.266 20 16.666 20C21.066 20 24.666 15.52 24.666 10C24.666 4.48 21.066 0 16.666 0ZM8.30602 20C4.06602 20.2 0.666016 23.68 0.666016 28V32H32.666V28C32.666 23.68 29.306 20.2 25.026 20C22.866 22.44 19.906 24 16.666 24C13.426 24 10.466 22.44 8.30602 20Z" fill="black"/>
</svg>


</template>

<script>
export default {
    name: 'LandloardIcon'
}
</script>
