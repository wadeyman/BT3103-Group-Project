import { createRouter, createWebHistory } from "vue-router";
import { getAuth, onAuthStateChanged } from "firebase/auth";
import Dashboard from "../views/DashboardPage.vue";
import TenantManagement from "../views/TenantManagement.vue";
import PropertyManagement from "../views/PropertyManagement.vue";
import LandlordManagement from "../views/LandlordManagement.vue";
import IncidentManagement from "../views/IncidentManagement.vue";
import CreateNewTenant from "../views/CreateNewTenant.vue";
import CreateNewLandlord from "../views/CreateNewLandlord.vue";
import CreateNewIncident from "../views/CreateNewIncident.vue";
import CreateNewProperty from "../views/CreateNewProperty.vue";
import ViewTenant from "../views/ViewTenant.vue";
import ViewLandlord from "../views/ViewLandlord.vue";
import ViewProperty from "../views/ViewProperty.vue";
import ViewIncident from "../views/ViewIncident.vue";
import CreateNewLease from "../views/CreateNewLease.vue";

const routes = [
  { path: "/", component: Dashboard, meta: { requiresAuth: true } },
  {
    path: "/tenant-management",
    component: TenantManagement,
    meta: { requiresAuth: true },
  },
  {
    path: "/property-management",
    component: PropertyManagement,
    meta: { requiresAuth: true },
  },
  {
    path: "/landlord-management",
    component: LandlordManagement,
    meta: { requiresAuth: true },
  },
  {
    path: "/incident-management",
    component: IncidentManagement,
    meta: { requiresAuth: true },
  },
  {
    path: "/login",
    component: () => import("../views/LoginPage.vue"),
    meta: { requiresAuth: false },
  },
  {
    path: "/signup",
    component: () => import("../views/SignupPage.vue"),
    meta: { requiresAuth: false },
  },
  {
    path: "/create-new-tenant",
    component: CreateNewTenant,
    meta: { requiresAuth: true },
  },
  {
    path: "/create-new-landlord",
    component: CreateNewLandlord,
    meta: { requiresAuth: true },
  },
  {
    path: "/create-new-incident",
    component: CreateNewIncident,
    meta: { requiresAuth: true },
  },
  {
    path: "/create-new-property",
    component: CreateNewProperty,
    meta: { requiresAuth: true },
  },
  {
    path: "/tenant-management/view-tenant/:tenantID",
    component: ViewTenant,
    name: 'view-tenant',
    props: true,
    meta: { requiresAuth: true },
  },
  {
    path: "/property-management/view-property/:propertyID",
    component: ViewProperty,
    name: 'view-property',
    props: true,
    meta: { requiresAuth: true },
  },
  {
    path: "/landlord-management/view-landlord/:landlordID",
    component: ViewLandlord,
    name: 'view-landlord',
    props: true,
    meta: { requiresAuth: true },
  },
  {
    path: "/incident-management/view-incident/:incidentID",
    component: ViewIncident,
    name: 'view-incident',
    props: true,
    meta: { requiresAuth: true },
  },
  {
    path: "/create-new-lease/:propertyID/:landlordID",
    component: CreateNewLease,
    name: 'create-new-lease',
    props: true,
    meta: { requiresAuth: true },
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

const auth = getAuth();

router.beforeEach((to, from, next) => {
  const requiresAuth = to.matched.some((record) => record.meta.requiresAuth);

  // Use onAuthStateChanged to ensure we get the current user
  onAuthStateChanged(auth, (currentUser) => {
    if (requiresAuth && !currentUser) {
      next("/login");
    } else if (!requiresAuth && currentUser) {
      next("/");
    } else {
      next();
    }
  });
});

export default router;
