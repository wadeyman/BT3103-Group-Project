<template>
  <div class="modal-backdrop">
    <div class="modal">
      <header class="modal-header">
        <slot name="header">
          <h3> Create New Rental History </h3> 

          <button
            type="button"
            class="btn-close"
            @click="close"
            aria-label="Close modal"
          >
            x
          </button>
        </slot>
      </header>

      <section class="modal-body">
        <slot name="body">
          
          <div class="in-twos"> 
                <div class="input-wrapper2" style='width: 95%; margin-bottom: 0px;'>
                    <label for="email">Tenant Name</label>
                    <input class="input_small_wide" style="width: 95%" :value="tenantName" disabled id="email" placeholder="Tenant Name" /><br /><br />
                </div>

            </div>

            <div class="in-twos">
                <div class="input-wrapper">    
                    <label for="email">Rate</label>
                    <input class="input_small" v-model="rate"  id="dob" required="yes" placeholder="$..." /><br /><br />
                </div>
                <div class="input-wrapper">
                    <label for="gender">Month</label>
                    <input class="input_small" v-model="month"  id="gender" required="yes" placeholder="Month..." /><br /><br />
                </div>
            </div>


        </slot>
       </section>
        <footer class="modal-footer">
          <div class='button-wrapper'>
          <button
          type="button"
          class="btn-primary"
          @click="savePaymentHistory"
        >
          Save Record
        </button>

        </div>
        
                </footer>
    </div>
  </div>
</template>

<script>
  export default {
    // eslint-disable-next-line vue/multi-word-component-names
    name: 'CreateNewPaymentHistory',
    props: {
      tenantName: String, 
    },
    data() { 
      return { 
        tenantNameLater: '',
        rate: '', 
        month: ''
      }
    },
    mounted() { 
      // Initialise the tenantName that is passed from ViewProperty.vue
      this.tenantNameLater = this.tenantName;
    },
    methods: {
      // On Emit, ViewProperty will savePaymentHistory with the rate and month as Params
      savePaymentHistory() {
        this.$emit('savePaymentHistory', {rate: this.rate, month: this.month});
      },
      // Closes the Modal
      close() {
        this.$emit('close');
      },
    },

  };
</script>

<style>
  .modal-backdrop {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background-color: rgba(0, 0, 0, 0.3);
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .modal {
    background: white;
    box-shadow: 2px 2px 20px 1px;
    overflow-x: auto;
    display: flex;
    flex-direction: column;
    border-radius: 10px;
    width: 35%;
  }

  .modal-header,
  .modal-footer {
    padding: 15px;
    display: flex;
    font-size: 18px;
  }

  .modal-header {
    position: relative;
    color: black;
    justify-content: space-between;
    padding-left: 20px;
  }

  .modal-footer {
    border-top: 1px solid #eeeeee;
    flex-direction: column;
    justify-content: flex-end;
  }

  .modal-body {
    position: relative;
    padding: 20px 10px;
    padding-left: 20px;
  }

  .btn-close {
    position: absolute;
    top: 0;
    right: 0;
    border: none;
    font-size: 20px;
    padding: 10px;
    cursor: pointer;
    font-weight: bold;
    color: var(--primary-accent);
    background: transparent;
  }

  .btn-primary {
    color: white;
    background: var(--primary-accent);
    border: 1px solid var(--primary-accent);
    border-radius: 10px;
    height: 50px;
    width: 200px;
    font-size: 18px;
    cursor: pointer;
  }

  .btn-secondary {
    color: black;
    background: transparent;
    border: 3px solid var(--primary-accent);
    border-radius: 10px;
    height: 50px;
    width: 200px;
    font-size: 18px;
    cursor: pointer;
  }

  .button-wrapper { 
    display: flex; 
    width: 100%; 
    justify-content: space-around;
  }
</style>