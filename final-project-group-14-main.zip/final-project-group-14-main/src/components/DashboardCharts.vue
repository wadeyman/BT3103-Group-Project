<template>
    
    <div class="container">

        <!-- Title-->
        <div id ="title">
            <h1> Dashboard </h1>
        </div>

        <!-- 1st row -->
        <!-- This contains the 4 key statistics at the top of the page -->
        <div class="chart-tile-row">  
            <div class = "tile" >
              <div class="circle-container">
                <!-- Image -->
                <img src="@/assets/document.png" alt="Image description" class="tile-image">
                </div>
                <!-- 1st statistic -->
                <div class = "inner">
                    <div id = "number">
                        <b> {{ leasesExpiring }} </b>
                    </div>
                    
                    <div id = "title">
                        <h2 class="tile-title">Lease Expiring Within 3 Months </h2> 
                        <h2 class="tile-title"></h2> 
                    </div>
                </div>
            </div>
            <div class = "tile" >
              <div class="circle-container" style="background-color: rgba(3,168,158,0.1); ">
                <!-- Image -->
                <img src="@/assets/active.png" alt="Image description" class="tile-image">
                </div>
                <!-- 2nd statistic -->
                <div class = "inner">
                    <div id = "number">
                        <b> {{ activeLeases }} </b>
                    </div>
                    
                    <div id = "title">
                        <h2 class="tile-title">Active Leases</h2> 
                        <h2 class="tile-title"></h2>
                    </div>
                </div>
            </div>

            <div class = "tile" >
              <div class="circle-container" style="background-color: rgba(255,105,180,0.1); ">
                <!-- Image -->
                <img src="@/assets/occupancy.png" alt="Image description" class="tile-image">
                </div>
                <!-- 3rd statistic -->
                <div class = "inner">
                    <div id = "number">
                       <b> {{ occupancyRate }} % </b>
                    </div>
                    
                    <div id = "title">
                        <h2 class="tile-title">Occupancy Rate</h2> 
                        <h2 class="tile-title"></h2>                        
                    </div>
                </div>
            </div>

            <div class = "tile" >
              <div class="circle-container">
                <!-- Image -->
                <img src="@/assets/alarm.png" alt="Image description" class="tile-image">
                </div>
                <!-- 4th statistic -->
                <div class = "inner">
                    <div id = "number">
                        <b> {{ propertiesWithoutActiveLease }} </b>
                    </div>
                    
                    <div id = "title">
                        <h2 class="tile-title">Properties Without Active Lease</h2> 
                    </div>
                </div>
            </div>

        </div>
        
        <!-- 2nd row -->
        <!-- This row has the "Leases Expiring" table on the left 
              and the "Incident Resolve" donut chart on the right -->
        <div class = "chart-row">  

            <div class = "tabletile" style="overflow-x:auto; max-height:360px; padding: 0px 30px;">
                <div> 
                    <h3 style=" margin-bottom: 0px; color: rgba(0,0,0,0.7); font-weight: 400;" > Lease Expiring </h3>
                </div> 
                <!-- This is the table listing all the properties with leases
                     expiring within the next 30 days and information like expiry
                     dates and tenant names  -->
                <table>
                    <thead>
                        <tr>
                            <th style="text-align: left; ">Property Name</th>
                            <th>Rate</th>
                            <th>Lease Expiry</th>
                            <th>Tenant Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="lease in leasesExpiringSoon" :key="lease.id">
                            <td style="text-align: left; color: #3A36DB;">{{ lease.propertyName }}</td>
                            <td>{{ lease.rate }}</td>
                            <td>{{ lease.leaseExpiry }}</td>
                            <td>{{ lease.tenantName }}</td>
                        </tr>
                    </tbody>     
                </table>
            </div>
           
            <!-- This is a donut chart showing the Incident Resolve Rate in Past 30 days -->
            <div class = "charttile">
                <div class="chart">
                    <h4> Incident Resolve Rate in Past 30 days</h4>
                    <pie-chart :donut = "true" class = 'user' width =500px :dataset="{borderWidth: 8, borderRadius: 15, borderJoinStyle: 'round'}" 
                     :data = "chartDataOne" legend = "bottom" :colors="['#603DD1', '#03A89E','#F337A5']"></pie-chart >
                </div>
            </div>

        </div>
        
        <!-- 3rd row -->
        <!-- This row has the "Leases with Missed Payment" table on the left 
              and the "Monthly Payment Status" donut chart on the right -->
        <div class = "chart-row">  

            <div class = "tabletile" style="overflow-x:auto; max-height:360px; padding: 0px 30px;">
                <div> 
                    <h3 style=" margin-bottom: 0px; color: rgba(0,0,0,0.7); font-weight: 400;"> Missed Payment </h3>
                </div> 
                
                <!-- This is the table listing all the leases with missed payments
                     and information like last payment dates and tenant names  -->
                <table>
                    <thead>
                        <tr>
                            <th style="text-align: left;">Property Name</th>
                            <th>Rate</th>
                            <th>Last Payment Month</th>
                            <th>Tenant Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="lease in leasesWithMissedPayments" :key="lease.id">
                            <td style="text-align: left; color: #3A36DB;">{{ lease.propertyName }}</td>
                            <td>{{ lease.rate }}</td>
                            <td>{{ lease.lastPaymentDate }}</td>
                            <td>{{ lease.tenantName }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <!-- This is a donut chart showing the Monthly Payment Status for the current month -->
            <div class = "charttile">
                <div class="chart">
                    <h3> Monthly Payment Status </h3>
                    <pie-chart :donut = "true" class = 'user' width =500px :dataset="{borderWidth: 8, borderRadius: 15, borderJoinStyle: 'round'}"
                    :data = "chartDataTwo" legend = "bottom" :colors="['#603DD1', '#03A89E','#F337A5']" ></pie-chart >
                </div>
            </div>

        </div>

    </div>
    
</template>


<script setup>

import { ref, onMounted } from 'vue';
import { doc, query, collection, getDocs, getDoc } from "firebase/firestore"
import { db, auth} from "@/firebase.js";

// Fetches the current user's database
const dbUser = doc(db, "Users", auth.currentUser.email);

// The function below is to calculate number of leases expiring within 3 months
const leasesExpiring = ref(0);
const getLeasesExpiringSoon = async() => {

    const now = new Date();
    const now2 = new Date();
    const leases = ref([]);
    const threeMonthsFromNow = new Date(now2.setMonth(now2.getMonth() + 3));
    const leaseCollectionRef = collection(dbUser, "Lease");
    const q = query(leaseCollectionRef);
    const querySnapshot = await getDocs(q);

    querySnapshot.forEach((document) => {
      const lease = document.data();
      const endDate = lease.endDate.toDate();
      // For each lease, check if it is active & expiring within 3 months
      if (endDate <= threeMonthsFromNow && endDate > now) { 
        leases.value.push(lease);
      }
    });
    leasesExpiring.value = leases.value.length;
}

// The function below is to get number of active leases
const activeLeases = ref(0);
const getActiveLeases = async () => {

    const now = new Date();
    const leaseCollectionRef = collection(dbUser, "Lease");
    const q = query(leaseCollectionRef);
    const querySnapshot = await getDocs(q);
    const temp = ref([]);
    
    querySnapshot.forEach((doc) => {
      const lease = doc.data();
      const endDate = lease.endDate.toDate();
      
      // Check if the lease is still active
      if (endDate > now) {
        temp.value.push(lease);
      }
    });
    
    activeLeases.value = temp.value.length;
};

// The function below is to calculate occupancy rate and number of properties without active lease
const occupancyRate = ref(0);
const propertiesWithoutActiveLease = ref(0);
const getOccupancy = async () => {

    const now = new Date();
    const propertyCollectionRef = collection(dbUser, "Property");
    const q = query(propertyCollectionRef);
    const querySnapshot = await getDocs(q);
    const properties = ref([]);
    
    querySnapshot.forEach(async (document) => {
      const property = document.data();
      properties.value.push(property); // Add to property list
      const leasesID = property.leasesID;
      
      // Check if this property has an active lease
      let hasActiveLease = false;
      for (let i = 0; i < leasesID.length; i++) {
        //Property has no lease or does bot start with "L" (wrong data)
        if (leasesID[i] == "" || leasesID[i][0] != "L" ) { 
            break
        }
        const leaseDocRef = doc(dbUser, "Lease", leasesID[i]);
        const leaseDocSnapshot = await getDoc(leaseDocRef);
        if (leaseDocSnapshot.exists) {
          const lease = leaseDocSnapshot.data();
          const endDate = lease.endDate.toDate();
          if (endDate > now) {
            hasActiveLease = true;
            break;
          }
        }
      }
      
      // If property has no active lease, increment counter
      if (!hasActiveLease) {
        propertiesWithoutActiveLease.value++;
      }
      
    });
  
    // Calculates occupancy rate by dividing properties with active lease 
    // by total number of properties
    occupancyRate.value = (100 * ((properties.value.length - propertiesWithoutActiveLease.value)
                                 / properties.value.length)).toFixed(1); //Round to 1 decimal place
                                 
};

// The function below is to fill Leases Expiring Table
const leasesExpiringSoon = ref([]);
const getLeasesExpiringTable = async () => {
  const now = new Date();
  const currentMonth = now.toLocaleString('default', { month: 'short' });
  const currentYear = now.getFullYear();
  const now2 = new Date(); // Need to declare else now will be modified
  const oneMonthFromNow = new Date(now2.setMonth(now2.getMonth() + 1));
  const leaseCollectionRef = collection(dbUser, "Lease");
  const q = query(leaseCollectionRef);
  const querySnapshot = await getDocs(q);
  
  querySnapshot.forEach(async (document) => {
    const lease = document.data();
    const endDate = lease.endDate.toDate();
    
    // Check if the lease expires within the next 30 days
    if (endDate <= oneMonthFromNow && endDate > now) {
      const propertyDocRef = doc(dbUser, "Property", lease.propertyID);
      const propertyDocSnapshot = await getDoc(propertyDocRef);
      if (propertyDocSnapshot.exists) {
        const property = propertyDocSnapshot.data();
        
        // Fetch the tenant's name from the "Tenant" collection
        const tenantDocRef = doc(dbUser, "Tenant", lease.tenantID);
        const tenantDocSnapshot = await getDoc(tenantDocRef);
        let tenantName = '';
        if (tenantDocSnapshot.exists) {
          const tenant = tenantDocSnapshot.data();
          tenantName = tenant.tenantName;
        }

        leasesExpiringSoon.value.push({
          id: doc.id,
          propertyName: property.propertyName,
          rate: lease.paymentHistory[lease.paymentHistory.length - 1].rate,
          leaseExpiry: endDate.getDate() +` ${currentMonth} ${currentYear}`,
          tenantName: tenantName
        });
      }
    }
  });
};

// The function below is to fill "Missed Payments" table
const leasesWithMissedPayments = ref([]);
const getLeasesWithMissedPayments = async () => {
  const now = new Date();
  const currentMonth = now.toLocaleString('default', { month: 'short' });
  const currentYear = now.getFullYear();
  const leaseCollectionRef = collection(dbUser, "Lease");
  const q = query(leaseCollectionRef);
  const querySnapshot = await getDocs(q);
  
  querySnapshot.forEach(async (document) => {
    const lease = document.data();
    const paymentHistory = lease.paymentHistory;
    
    // Check if the last payment was missed
    let lastPaidMonth;
    for (let i = paymentHistory.length - 1; i >= 0; i--) {
      if (paymentHistory[i].status === "Paid") {
        lastPaidMonth = paymentHistory[i].month;
        break;
      }
    }
    
    // If the last paid month is not the current month, means there is a missed payment
    if (lastPaidMonth && lastPaidMonth != currentMonth) {
      const propertyDocRef = doc(dbUser, "Property", lease.propertyID);
      const propertyDocSnapshot = await getDoc(propertyDocRef);
      if (propertyDocSnapshot.exists) {
        const property = propertyDocSnapshot.data();
        
        // Fetch the tenant's name from the "Tenant" collection
        const tenantDocRef = doc(dbUser, "Tenant", lease.tenantID);
        const tenantDocSnapshot = await getDoc(tenantDocRef);
        let tenantName = '';
        if (tenantDocSnapshot.exists) {
          const tenant = tenantDocSnapshot.data();
          tenantName = tenant.tenantName;
        }
        
        leasesWithMissedPayments.value.push({
          id: doc.id,
          propertyName: property.propertyName,
          rate: paymentHistory[paymentHistory.length - 1].rate,
          lastPaymentDate: `${lastPaidMonth} ${currentYear}`,
          tenantName: tenantName
        });
      }
    }
  });
};

// The function below is to populate the "Incident Resolve Rate" chart
const chartDataOne = ref([]);
const getIncidentResolveRates = async () => {
  const now = new Date();
  const now2 = new Date();
  const thirtyDaysAgo = new Date(now2.setDate(now2.getDate() - 30));
  const incidentCollectionRef = collection(dbUser, "Incident");
  const q = query(incidentCollectionRef);
  const querySnapshot = await getDocs(q);
  
  let resolvedCount = 0;
  let resolvingCount = 0;
  let unresolvedCount = 0;
  
  querySnapshot.forEach((document) => {
    const incident = document.data();
    const reportedDate = incident.reportedDate.toDate();
    
    // Check if the incident was reported within the past 30 days
    // If so, increment the respective counts 
    if (reportedDate >= thirtyDaysAgo && reportedDate <= now) {
      switch (incident.status) {
        case "Resolved":
          resolvedCount++;
          break;
        case "Resolving":
          resolvingCount++;
          break;
        case "Not Resolved": 
          unresolvedCount++;
          break;
      }
    }
  });
  
  chartDataOne.value = {
     'Resolving': resolvingCount,
     'Resolved': resolvedCount,
     'Unresolved': unresolvedCount
  };
};

// The function below is to populate "Monthly Payment Status" chart //
const chartDataTwo = ref([]);
const getMonthlyPaymentStatuses = async () => {
  const leaseCollectionRef = collection(dbUser, "Lease");
  const q = query(leaseCollectionRef);
  const querySnapshot = await getDocs(q);
  
  let pendingCount = 0;
  let paidCount = 0;
  let notPaidCount = 0;
  
  querySnapshot.forEach((document) => {
    const lease = document.data();
    const paymentHistory = lease.paymentHistory;
    
    // Check the status of the last payment & increment respective counters
    if (paymentHistory.length > 0) {
      switch (paymentHistory[paymentHistory.length - 1].status) {
        case "Pending":
          pendingCount++;
          break;
        case "Paid":
          paidCount++;
          break;
        case "Overdue":
          notPaidCount++;
          break;
      }
    }
  });
  
  chartDataTwo.value = {
     'Pending': pendingCount,
     'Paid': paidCount,
     'Overdue': notPaidCount
  };
};

// Lifecycle hook that is called after a component is mounted to the DOM. 
// Typically used to run code after the component has finished initial rendering and created the DOM nodes
onMounted(getLeasesExpiringSoon);
onMounted(getActiveLeases);
onMounted(getOccupancy);
onMounted(getLeasesExpiringTable);
onMounted(getLeasesWithMissedPayments);
onMounted(getIncidentResolveRates);
onMounted(getMonthlyPaymentStatuses);

</script>

<style scoped>
th { 
  font-weight: 200;
  font-size: 16px;
}

.container {
    display: flex;
    flex-direction: column;
}

.chart-tile-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap:10px;
    margin-bottom: 20px;
}

.chart-row {
    display: flex;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 10px;
    margin-bottom: 20px;
}

.user{
    flex: 1;
    max-width: 300px; 
}
.charttile {
    display: flex;
    flex: 0.4;
    margin: 0;
    flex-direction: grid;
    justify-content: center;
    align-items: center; 
    height: auto;
    border: none;
    background-color: white;
    border-radius: 10px;
}

.tabletile {
    text-align: left;
    vertical-align: top;
    flex: 0.6;
    margin: 0;
    height: auto;
    border: none;
    background-color: white;
    border-radius: 10px;
}

.tile {
    display: flex;
    margin: 0;
    flex-direction: auto;
    justify-content: left;
    align-items: center; 
    height: 100px;
    border: none;
    background-color: white;
    border-radius: 10px;
    padding-right: 15px;
    /*rgba(224, 223, 223, 0.861)*/
}

.tile-title {
  margin: 0; 
  font-family:Arial, Helvetica, sans-serif;
  font-size: 85%;
  word-wrap: wrap;
  display: flex;
  font-weight: 100;

}

table {
    width: 100%;
    border-collapse: collapse;
}

table { 
  width: 100%;
  border-collapse: separate;
  border-spacing: 0 1em;
}

tr { 
    padding-bottom: 30px;
}

th {
  padding: 5px;
  font-size: 16px;
  background-color: white;
  text-align: center;
  color: black;

}
td {
  padding: 5px;
  font-size: 16px;
  background-color: white;
  border-bottom: 1px rgba(177, 177, 177, 0.5) solid;
  text-align: center;
  padding-bottom: 15px;
  
}

.chart {
    text-align: center;
    margin: 0 auto;
    justify-content: center;
}

.user .slice {
  width: 20px;
}

.tile-image {
  height: 30px;
  width: 30px;
  min-height: 30px;
  min-width: 30px;
  display: block; 
  position: absolute; 
  top: 50%; 
  left: 44%;
  transform: translate(-50%, -50%);
  z-index: 99;
}
.circle-container {
  width: 60px; 
  height: 60px;
  min-height: 60px;
  min-width: 60px;
  border-radius: 50%; 
  overflow: hidden; 
  position: relative; 
  background-color: grey;
  margin-left: 20px;
  margin-right: 20px;
  background-color: rgba(58,54,219, 0.1);
}
#number {
    display: flex;
    flex-direction: column; 
    align-content: left;
    font-family:Arial, Helvetica, sans-serif;
    font-size: 22px;
    color:rgba(0, 0, 0, 0.7)
}

.inner {
    display: flex; 
    flex-direction: column; 
    justify-content: left;
}

#third {
    width:32%;
    height: 60%;
}

#title {
    display: flex; 
    flex-direction: column;
    justify-content: left; 
    align-items: left;
    border-radius: 10px;

}

caption {
    font-size: 110%;
}


</style>