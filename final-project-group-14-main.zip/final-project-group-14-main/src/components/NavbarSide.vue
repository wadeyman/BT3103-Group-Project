<template>
  <div v-if="user">
    <div id="navbar-side">
      <div class="side-logo">
        <img src="@/assets/logo.png" alt="logo" />
        <h3 class="title">Real Estate Management</h3>
      </div>
      <nav>
        <router-link class="nav-item" to="/">
          <div class="nav-item-wrapper">
            <DashboardIcon class="icon" /> Dashboard
          </div>
        </router-link>
        <router-link class="nav-item" to="/property-management">
          <div class="nav-item-wrapper">
            <PropertyIcon class="icon" />Property Management
          </div>
        </router-link>
        <router-link class="nav-item" to="/tenant-management">
          <div class="nav-item-wrapper">
            <TenantIcon class="icon" />Tenant Management
          </div>
        </router-link>

        <router-link class="nav-item" to="/landlord-management">
          <div class="nav-item-wrapper">
            <LandlordIcon class="icon" />Landlord Management
          </div>
        </router-link>
        <router-link class="nav-item" to="/incident-management">
          <div class="nav-item-wrapper">
            <IncidentIcon class="icon" />Incident Management
          </div>
        </router-link>
      </nav>
      <div class="logout-container">
        <div class="user-details">
          <h4 style="margin-bottom: 8px">{{ user.displayName }}</h4>
          <p style="font-size: 10px">{{ user.email }}</p>
        </div>

        <img
          src="@/assets/Logout.png"
          alt="Logout"
          style="margin-left: 20px; cursor: pointer"
          @click="logout"
        />

        <!-- <button @click="logout" class="logout-button">Logout</button> -->
      </div>
    </div>
  </div>
  <MessageModal
    v-show="isMessageModalVisible"
    @close="closeMessageModal"
    :message="modalMessage"
  />
</template>

<script>
import { ref } from "vue";
import { getAuth, onAuthStateChanged, signOut } from "firebase/auth";
import useUser from "@/composables/useUser";
import DashboardIcon from "@/assets/DashboardIcon";
import PropertyIcon from "@/assets/PropertyIcon";
import TenantIcon from "@/assets/TenantIcon";
import LandlordIcon from "@/assets/LandlordIcon";
import IncidentIcon from "@/assets/IncidentIcon";
import MessageModal from "@/components/MessageModal.vue";

export default {
  name: "NavbarSide",
  data() {
    return {
      user: false,
      modalMessage: "",
      isMessageModalVisible: false,
    };
  },
  mounted() {
    const user = ref(null);
    const auth = getAuth();

    onAuthStateChanged(auth, (newUser) => {
      user.value = newUser;
      this.user = newUser;
    });

    const { logout } = useUser();
    return { logout, user };
  },

  components: {
    /* Icons in the Navigation are SVG saved as Vue Components. 
        This is to allow easier manipulation of the Icon Colors when the Navigation is active. 
        */
    DashboardIcon,
    PropertyIcon,
    TenantIcon,
    LandlordIcon,
    IncidentIcon,
    MessageModal,
  },

  methods: {
    logout() {
      const auth = getAuth();
      const user = auth.currentUser;
      try {
        signOut(auth, user);
        this.showMessageModal(
          "Logout Successfully. Redirecting you to Login Page."
        );
        this.$router.push("/login");
      } catch (error) {
        console.log("Cannot Logout", error);
      }
    },
    // Modal with messages to indicate the user has successfully logout
    showMessageModal(otherMessage) {
      this.isMessageModalVisible = true;
      this.modalMessage = otherMessage;
    },
    // Allows Users to close the message modal
    closeMessageModal() {
      this.isMessageModalVisible = false;
    },
  },
};
</script>

<style>
#navbar-side {
  width: 220px;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  background-color: #ffffff;
  box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
}

.isSelected {
  fill: #000;
}

.side-logo {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  text-align: center;
  margin-top: 20px;
}

.title {
  margin-top: 10px;
  margin-bottom: 10px;
}

.nav-item {
  display: block;
  padding: 10px 20px;
  text-decoration: none;
  color: rgba(0, 0, 0, 0.5);
  margin: 5px 0px;
  font-weight: 550;
}

.nav-item-wrapper {
  text-decoration: none;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
}

.nav-item:hover {
  background-color: var(--primary-accent);
  color: white;
}

.nav-container {
  flex-grow: 1;
}

.logout-container {
  display: flex;
  position: absolute;
  flex-direction: row;
  bottom: 0;
  margin-left: 25px;
  align-items: center;
  margin-bottom: 30px;
  align-items: center;
}

.logout-button {
  background-color: #f44336;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 0px 0px;
  cursor: pointer;
  transition: background-color 0.3s ease-in-out;
}

.logout-button:hover {
  background-color: #d32f2f;
}

.icon {
  margin-right: 10px;
}
.icon path {
  fill: #99b2c6;
}

#navbar-side .nav-item.router-link-exact-active {
  background-color: rgba(153, 178, 198, 0.3);
  color: var(--primary-accent);
}

#navbar-side .nav-item.router-link-exact-active .icon path {
  fill: var(--primary-accent);
}
</style>
