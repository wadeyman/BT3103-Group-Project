<template>
  <div class="container">
    <div class="header">
      <h1 style="margin-top: 0px; margin-bottom: 0px">Property Management</h1>
      <div class="header-controls">
        <input
          type="text"
          v-model="searchName"
          placeholder="Search Property Name"
          class="search-box"
        />
        <button class="add-new-button" @click="handleAddNew">+ Add New</button>
      </div>
    </div>
    <div class="tbl-header">
      <table cellpadding="0" cellspacing="0" border="0">
        <thead>
          <tr>
            <th>Landlord</th>
            <th>Property Name</th>
            <th>Property Address</th>
            <th>Lease Expiry</th>
            <th>Payment Status</th>
            <th>Actions</th>
          </tr>
        </thead>
      </table>
    </div>
    <div class="tbl-content">
      <table cellpadding="0" cellspacing="0" border="0">
        <tbody>
          <tr v-for="prop in paginatedProps" :key="prop.id">
            <td>{{ prop.landlordName }}</td>
            <td>{{ prop.propertyName }}</td>
            <td>{{ prop.propertyAddress }}</td>
            <td>{{ prop.expiryDate }}</td>
            <td>
              <div class="wrapper" v-if="prop.status === 'Complete'">
                <button @click="handleButtonClick" class="complete">
                  {{ prop.status }}
                </button>
              </div>
              <div class="wrapper" v-else-if="prop.status === 'Overdue'">
                <button @click="handleButtonClick" class="overdue">
                  {{ prop.status }}
                </button>
              </div>
              <div class="wrapper" v-else>
                <button @click="handleButtonClick" class="pending">
                  {{ prop.status }}
                </button>
              </div>
            </td>

            <td>
              <button @click="handleButtonClick(prop.id)" class="view-button">
                View
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <br /><br />
    <!-- Pagination -->
    <div class="pagination">
      <button
        v-for="pageNum in totalPages"
        :key="pageNum"
        @click="changePage(pageNum)"
        :class="{ active: pageNum === currentPage }"
      >
        {{ pageNum }}
      </button>
    </div>
  </div>
</template>

<script>
import { db, auth } from "@/firebase.js";
import { collection, doc, getDocs, query } from "firebase/firestore";

export default {
  data() {
    return {
      sortAscending: false,
      sortByField: null,
      propertyArray: null,
      itemsPerPage: 10,
      currentPage: 1,
      searchName: "",
    };
  },
  async created() {
    // Get all Docs from Property Collection //
    const dbUser = doc(db, "Users", auth.currentUser.email);
    const propertyCollectionRef = collection(dbUser, "Property");
    const q = query(propertyCollectionRef);
    const querySnapshot = await getDocs(q);
    const results = querySnapshot.docs.map((doc) => {
      // Include the Property ID in the mapped data object //
      return { id: doc.id, ...doc.data() };
    });

    this.propertyArray = results;

    // Find the Latest Lease for Each Property//
    this.doExpiryMatching();

    // Find the Latest Payment Status of that Lease //
    this.doStatusMatching();
  },
  watch: {
    // Handles the Search for Property when changes to Search Bar is made //
    searchName: function () {
      this.performSearchName();
    },
  },
  methods: {
    // Handles Creation of New Property //
    handleAddNew() {
      this.$router.push("create-new-property");
    },
    // Handles View of Individual Property //
    handleButtonClick(propertyID) {
      this.$router.push({ name: "view-property", params: { propertyID } });
    },
    // Formats Timestamp to Date Format for Display //
    formatDate(timestamp) {
      const date = new Date(timestamp * 1000); // Convert timestamp to Date //
      const day = date.getDate();
      const month = date.toLocaleString("default", { month: "long" });
      const year = date.getFullYear();
      return `${day} ${month} ${year}`;
    },
    // Searches the Property based on the input from PropertyName //
    async performSearchName() {
      // Get Property Data //
      const dbUser = doc(db, "Users", auth.currentUser.email);
      const propertyCollectionRef = collection(dbUser, "Property");
      const q = query(propertyCollectionRef);
      const querySnapshot = await getDocs(q);
      const results = querySnapshot.docs
        .map((doc) => {
          // Include the Property ID in the mapped data object
          return { id: doc.id, ...doc.data() };
        }) // Filters for Property that has matching PropertyName //
        .filter((data) => data.propertyName.includes(this.searchName));

      this.propertyArray = results;
      // Find the Latest Lease for Each Property//
      this.doExpiryMatching();

      // Find the Latest Payment Status of that Lease /
      this.doStatusMatching();
    },
    async doExpiryMatching() {
      const dbUser = doc(db, "Users", auth.currentUser.email);

      // GET ALL LEASE INFORMATION //
      const leaseCollectionRef = collection(dbUser, "Lease");
      const q = query(leaseCollectionRef);
      const querySnapshotLease = await getDocs(q);
      const leaseData = querySnapshotLease.docs.map((doc) => {
        // Include the Property ID in the mapped data object
        return { id: doc.id, ...doc.data() };
      });

      // GET ALL LANDLORD INFORMATION //
      const landlordCollectionRef = collection(dbUser, "Landlord");
      const qLandlord = query(landlordCollectionRef);
      const querySnapshotLandlord = await getDocs(qLandlord);
      const landlordData = querySnapshotLandlord.docs.map((doc) => {
        // Include the Property ID in the mapped data object
        return { id: doc.id, ...doc.data() };
      });

      this.propertyArray.forEach((docs) => {
        // Find Latest Lease Expiry Date //
        const thisDocLease = docs.leasesID;
        const filteredLeases = leaseData.filter((lease) =>
          thisDocLease.includes(lease.id)
        );
        const leaseExpiryDate = filteredLeases.map(
          (lease) => lease.endDate.seconds
        );
        if (leaseExpiryDate.length !== 0) {
          // Format and Get Latest Timestamp //
          docs.expiryDate = this.formatDate(Math.max(...leaseExpiryDate));
        } else {
          docs.expiryDate = "No Current Lease";
        }

        // Match Landlord Name //
        const propertyLandlord = landlordData.find(
          (landlord) => landlord.id === docs.landlordID
        );
        docs.landlordName = propertyLandlord.landlordName;
      });
    },

    async doStatusMatching() {
      const dbUser = doc(db, "Users", auth.currentUser.email);

      // GET ALL LEASE INFORMATION //
      const leaseCollectionRef = collection(dbUser, "Lease");
      const q = query(leaseCollectionRef);
      const querySnapshotLease = await getDocs(q);
      const leaseData = querySnapshotLease.docs.map((doc) => {
        // Include the Property ID in the mapped data object //
        return { id: doc.id, ...doc.data() };
      });

      this.propertyArray.forEach((docs) => {
        // Find Latest Lease Expiry Date
        const thisDocLease = docs.leasesID;

        const filteredLeases = leaseData.filter((lease) =>
          thisDocLease.includes(lease.id)
        );
        const leaseStatuses = filteredLeases.map(
          (lease) =>
            lease.paymentHistory[lease.paymentHistory.length - 1].status
        );
        if (leaseStatuses.includes("Pending")) {
          docs.status = "Pending";
        } else if (leaseStatuses.includes("Overdue")) {
          docs.status = "Overdue";
        } else {
          docs.status = "Complete";
        }
      });
    },
    // Handles the Change in New Page Number //
    changePage(pageNumber) {
      this.currentPage = pageNumber;
    },
  },
  computed: {
    // Computed the Total Number of Pages //
    totalPages() {
      try {
        const number = Math.ceil(this.propertyArray.length / this.itemsPerPage);
        return number;
      } catch {
        return 1;
      }
    },
    // Returns the 10 Incident to be Displayed based on the currentPage Number //
    paginatedProps() {
      try {
        const start = (this.currentPage - 1) * this.itemsPerPage;
        const end = this.currentPage * this.itemsPerPage;
        return this.propertyArray.slice(start, end);
      } catch {
        return this.propertyArray;
      }
    },
  },
};
</script>

<style scoped>
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.header-controls {
  display: flex;
  align-items: center;
}

.search-box {
  margin-right: 10px;
  padding: 8px;
  width: 200px;
  height: 28px;
  border: 1px solid #ffffff;
  border-radius: 4px;
  color: black; /* Text color */
  background-color: white;
  border-radius: 10px;
}

.add-new-button {
  margin-right: 10px;
  padding: 8px;
  width: 120px;
  height: 44px;
  border: 1px solid #ffffff;
  border-radius: 4px;
  background-color: #3c38db; /* Text color */
  color: #fff;
  cursor: pointer;
  border-radius: 10px;
  margin-top: 0px;
  margin-bottom: 0px;
}

h3 {
  color: black;
  text-align: left;
  margin: 0;
}

table {
  width: 100%;
  table-layout: auto;
  background-color: #f1f4fa;
}

.tbl-header {
  background-color: #f1f4fa;
}

.tbl-content {
  height: fit-content;
  margin-top: 0px;
  border: 1px solid #f1f4fa;
}

th {
  padding: 20px 8px;
  text-align: left;
  font-weight: 500;
  font-size: 14.22px;
  background-color: #f1f4fa;
}

td {
  padding: 8px;
  font-weight: 300;
  font-size: 14.22px;
  background-color: white;
  border-bottom: solid 1px rgba(255, 255, 255, 0.1);
}

th:nth-child(1) {
  text-align: left;
  padding-left: 15px;
  width: 15%;
}

td:nth-child(1) {
  border-top-left-radius: 20px; /* Add a curve to the top-left corner */
  border-bottom-left-radius: 20px; /* Add a curve to the bottom-left corner */
  padding-left: 15px;
  width: 15%;
  text-align: left;
}

td:nth-child(2) {
  text-align: left;
  padding-left: 8px;
  width: 20%;
}
th:nth-child(2) {
  text-align: left;
  width: 20%;
}

td:nth-child(3) {
  text-align: left;
  padding-left: 8px;
  width: 20%;
}
th:nth-child(3) {
  text-align: left;
  width: 20%;
}

td:nth-child(4) {
  text-align: center;
  padding-left: 8px;
  width: 15%;
  /* overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap; */
}
th:nth-child(4) {
  text-align: center;
  width: 15%;
}

td:nth-child(5) {
  text-align: center;
  padding-left: 8px;
  width: 15%;
  /* overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap; */
  margin: auto;
}
th:nth-child(5) {
  text-align: center;
  width: 15%;
}
th:nth-child(6) {
  text-align: center;
  width: 15%;
}
.wrapper {
  display: flex;
  justify-content: center;
}
td {
  padding: 8px;
  text-align: left;
  vertical-align: middle;
  font-weight: 300;
  font-size: 14.22px;
  background-color: white;
  border-bottom: solid 1px rgba(255, 255, 255, 0.1);
  height: 50px;
}
td:last-child {
  border-top-right-radius: 20px; /* Add a curve to the top-right corner */
  border-bottom-right-radius: 20px; /* Add a curve to the bottom-right corner */
  text-align: center;
}

/* Add a small separator between rows */
tr + tr td {
  border-top: 10px solid #f7f7f8;
}

@import url(https://fonts.googleapis.com/css?family=Roboto:400,500,300,700);
body {
  background: -webkit-linear-gradient(left, #25c481, #25b7c4);
  background: linear-gradient(to right, #25c481, #25b7c4);
  font-family: "Roboto", sans-serif;
}

/* Style the button on hover (optional) */
.view-button:hover {
  background-color: #4c9cac;
}
.sort-icon {
  display: inline-block;
  width: 0;
  height: 0;
  border-left: 5px solid transparent;
  border-right: 5px solid transparent;
  border-top: 8px solid #000; /* Adjust color as needed */
}

.asc {
  transform: rotate(180deg); /* Upside-down triangle for ascending order */
}

.desc {
  transform: rotate(180deg); /* Normal triangle for descending order */
}

.status-column {
  display: flex;
  align-items: left;
  justify-content: left;
}

.status-indicator {
  width: 150px;
  height: 40px;
  border-radius: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: normal;
}

.status-text {
  margin: 0; /* Reset default margin */
}

.complete {
  background-color: #e6f7f6;
  color: #13aea4;
}

.pending {
  background-color: #ecebfc;
  color: #3c38db;
}

.pagination {
  display: flex;
  justify-content: flex-end;
}

.pagination button {
  border: none; /* Remove the outline */
  color: #06152b; /* Set the text color */
  background-color: #f1f4fa;
  text-decoration: none;
}

.pagination button.active {
  text-decoration: underline; /* Underline the selected page */
}

.complete {
  width: 100px;
  height: 35px;
  border-radius: 16px;
  background-color: #e6f7f6;
  color: #13aea4;
  cursor: pointer;
  border: none;
}

.overdue {
  width: 100px;
  height: 35px;
  border-radius: 16px;
  background-color: #fff0f8;
  color: #ff69b4;
  cursor: pointer;
  border: none;
}

.pending {
  width: 100px;
  height: 35px;
  border-radius: 16px;
  background-color: #ecebfc;
  color: #3c38db;
  cursor: pointer;
  border: none;
}

.view-button {
  width: 100px;
  height: 35px;
  border-radius: 16px;
  background-color: #364153;
  color: #fff;
  cursor: pointer;
  border: none;
}
</style>
