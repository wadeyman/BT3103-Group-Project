<template>
  <div class="container">
    <div class="header">
      <h1 style="margin-top: 0px; margin-bottom: 0px">Landlord Management</h1>
      <div class="header-controls">
        <input
          type="text"
          v-model="searchName"
          placeholder="Search Landlord Name"
          class="search-box"
        />
        <button class="add-new-button" @click="handleAddNew">+ Add New</button>
      </div>
    </div>
    <div class="tbl-header">
      <table cellpadding="0" cellspacing="0" border="0">
        <thead>
          <tr>
            <th>Landlord Name</th>
            <th>Phone Number</th>
            <th>Email Address</th>
            <th>Number of Rental Unit</th>
            <!-- Need to have a formula to check number of units -->
            <th>Nationality</th>
            <th>Actions</th>
          </tr>
        </thead>
      </table>
    </div>
    <div class="tbl-content">
      <table cellpadding="0" cellspacing="0" border="0" id="tbl2">
        <tbody>
          <tr v-for="ll in paginatedLL" :key="ll.id">
            <!-- need slice? -->
            <td>{{ ll.landlordName }}</td>
            <td>{{ ll.landlordNumber }}</td>
            <td>{{ ll.landlordEmail }}</td>
            <td>{{ countByLandlord[ll.id] || 0 }}</td>
            <!-- for now use DOB to substitute date expiry -->
            <td>{{ ll.landlordNationality }}</td>
            <td>
              <div class="wrapper">
                <button @click="handleButtonClick(ll.id)" class="view-button">
                  View
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <br /><br />
    <!-- Pagination -->
    <div class="pagination">
      <button
        v-for="pageNum in totalPages"
        :key="pageNum"
        @click="changePage(pageNum)"
        :class="{ active: pageNum === currentPage }"
      >
        {{ pageNum }}
      </button>
    </div>
  </div>
</template>

<script>
import { collection, query, getDocs, doc } from "firebase/firestore"; // Import Firestore functions
import { auth, db } from "@/firebase.js";

export default {
  data() {
    return {
      LL_Data: [],
      Properties: [],
      sortAscending: false,
      sortByField: null,
      countByLandlord: {},
      itemsPerPage: 10, // need edit
      currentPage: 1,
      searchName: "",
    };
  },
  created() {
    const dbUser = doc(db, "Users", auth.currentUser.email);
    const LLCollectionRef = collection(dbUser, "Landlord");
    const PropsRef = collection(dbUser, "Property");

    const p = query(PropsRef);
    const q = query(LLCollectionRef);

    // Get all Docs from Landlord Collection //
    getDocs(q)
      .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
          this.LL_Data.push({ id: doc.id, ...doc.data() }); // Include doc ID in LL_Data
        });
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
      });

    // Get all Docs from Property Collection //
    getDocs(p).then((querySnapshot) => {
      querySnapshot.forEach((doc) => {
        this.Properties.push(doc.data());
      });
      // Count the Number of Properties belonging to each Landlord //
      this.countLandlordOccurrences(this.Properties);
    });
  },
  watch: {
    // Handles the Search for Landlord when changes to Search Bar is made //
    searchName: function () {
      this.performSearchName();
    },
  },
  methods: {
    // Searches the Landlord based on the input from LandlordName //
    async performSearchName() {
      // Get Landlord Data //
      const landlordDocument = "Landlord";
      const dbUser = doc(db, "Users", auth.currentUser.email);
      const landlordCollectionRef = collection(dbUser, landlordDocument);

      const q = query(landlordCollectionRef);
      const querySnapshot = await getDocs(q);
      const results = querySnapshot.docs
        .map((doc) => {
          // Include the document ID in the mapped data object //
          return { id: doc.id, ...doc.data() };
        }) // Filters for Landlord with Matching Landlord Name //
        .filter((data) => data.landlordName.includes(this.searchName));

      this.LL_Data = results;

      // Count the Number of Properties belonging to each Landlord //
      this.countLandlordOccurrences(this.Properties);
    },
    // Handles View of Individual Landlord //
    handleButtonClick(landlordID) {
      this.$router.push({ name: "view-landlord", params: { landlordID } });
    },
    // Handles Creation of New Landlord //
    handleAddNew() {
      this.$router.push("create-new-landlord");
    },
    // Formats Timestamp to Date Format for Display //
    formatDate(timestamp) {
      const date = new Date(timestamp.seconds * 1000); // Convert timestamp to Date
      const day = date.getDate();
      const month = date.toLocaleString("default", { month: "long" });
      const year = date.getFullYear();
      return `${day} ${month} ${year}`;
    },
    // Count the Number of Properties for Each Landlord //
    countLandlordOccurrences(props) {
      this.countByLandlord = props.reduce((acc, current) => {
        const { landlordID } = current;
        if (landlordID) {
          acc[landlordID] = (acc[landlordID] || 0) + 1;
        }
        return acc;
      }, {});
    },
    // Handles the Change in New Page Number //
    changePage(pageNumber) {
      this.currentPage = pageNumber;
    },
  },
  computed: {
    // Computed the Total Number of Pages //
    totalPages() {
      return Math.ceil(this.LL_Data.length / this.itemsPerPage);
    },
    // Returns the 10 Incident to be Displayed based on the currentPage Number //
    paginatedLL() {
      try {
        const start = (this.currentPage - 1) * this.itemsPerPage;
        const end = this.currentPage * this.itemsPerPage;
        return this.LL_Data.slice(start, end);
      } catch (error) {
        return 1;
      }
    },
  },
};
</script>

<style scoped>
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.header-controls {
  display: flex;
  align-items: center;
}

.search-box {
  margin-right: 10px;
  padding: 8px;
  width: 200px;
  height: 28px;
  border: 1px solid #ffffff;
  border-radius: 4px;
  color: black; /* Text color */
  background-color: white;
  border-radius: 10px;
}

.add-new-button {
  margin-right: 10px;
  padding: 8px;
  width: 120px;
  height: 44px;
  border: 1px solid #ffffff;
  border-radius: 4px;
  background-color: #3c38db; /* Text color */
  color: #fff;
  cursor: pointer;
  border-radius: 10px;
  margin-top: 0px;
  margin-bottom: 0px;
}

h3 {
  color: black;
  text-align: left;
  margin: 0;
}

table {
  width: 100%;
  table-layout: auto;
  background-color: #f1f4fa;
}

.tbl-header {
  background-color: #f7f7f8;
}

.tbl-content {
  height: fit-content;
  margin-top: 0px;
  border: 1px solid #f1f4fa;
}

th {
  padding: 20px 8px;
  width: 16.67%;
  font-weight: 500;
  font-size: 14.22px;
  background-color: #f1f4fa;
}

td {
  padding: 8px;
  font-weight: 300;
  font-size: 14.22px;
  background-color: white;
  border-bottom: solid 1px rgba(255, 255, 255, 0.1);
}
th:nth-child(1) {
  text-align: left;
  padding-left: 15px;
}

td:first-child {
  border-top-left-radius: 20px; /* Add a curve to the top-left corner */
  border-bottom-left-radius: 20px; /* Add a curve to the bottom-left corner */
  padding-left: 15px;
  width: 16.67%;
  text-align: left;
}

td:nth-child(2) {
  text-align: left;
  padding-left: 14px;
  width: 16.67%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
th:nth-child(2) {
  text-align: left;
  width: 16.67%;
}

td:nth-child(3) {
  text-align: left;
  padding-left: 8px;
  width: 16.67%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
th:nth-child(3) {
  text-align: left;
  width: 16.67%;
}

td:nth-child(4) {
  text-align: center;
  padding-left: 25px;
  width: 16.67%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
th:nth-child(4) {
  text-align: center;
  width: 16.67%;
}

td:nth-child(5) {
  text-align: center;
  padding-left: 50px;
  width: 16.67%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin: auto;
}
th:nth-child(5) {
  text-align: center;
  width: 15%;
}
th:nth-child(6) {
  text-align: center;
  width: 15%;
}
.wrapper {
  display: flex;
  justify-content: center;
}

td {
  padding: 8px;
  text-align: left;
  vertical-align: middle;
  font-weight: 300;
  font-size: 14.22px;
  background-color: white;
  border-bottom: solid 1px rgba(255, 255, 255, 0.1);
  height: 50px;
}

td:last-child {
  border-top-right-radius: 20px; /* Add a curve to the top-right corner */
  border-bottom-right-radius: 20px; /* Add a curve to the bottom-right corner */
  text-align: center;
  padding-left: 30px;
}

/* small separator between rows */
tr + tr td {
  border-top: 10px solid #f1f4fa;
}

@import url(https://fonts.googleapis.com/css?family=Roboto:400,500,300,700);
body {
  background: -webkit-linear-gradient(left, #25c481, #25b7c4);
  background: linear-gradient(to right, #25c481, #25b7c4);
  font-family: "Roboto", sans-serif;
}

.pagination {
  display: flex;
  justify-content: flex-end; /* Push the pagination to the right */
}

.pagination button {
  border: none; /* Remove the outline */
  color: #06152b; /* Set the text color */
  background-color: #f1f4fa;
  text-decoration: none;
}

.pagination button.active {
  text-decoration: underline; /* Underline the selected page */
}

.view-button {
  width: 100px;
  height: 35px;
  border-radius: 16px;
  background-color: #364153;
  color: #fff;
  cursor: pointer;
  border: none;
}

/* Style the button on hover (optional) */
.view-button:hover {
  background-color: #4c9cac;
}
.sort-icon {
  display: inline-block;
  width: 0;
  height: 0;
  border-left: 5px solid transparent;
  border-right: 5px solid transparent;
  border-top: 8px solid #000; /* Adjust color as needed */
}

.asc {
  transform: rotate(180deg); /* Upside-down triangle for ascending order */
}

.desc {
  transform: rotate(180deg); /* Normal triangle for descending order */
}
</style>
