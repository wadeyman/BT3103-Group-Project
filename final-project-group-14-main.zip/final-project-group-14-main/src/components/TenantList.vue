<template>
  <div class="container">
    <div class="header">
      <h1 style="margin-top: 0px; margin-bottom: 0px">Tenant Management</h1>
      <div class="header-controls">
        <input
          type="text"
          v-model="searchName"
          placeholder="Search Tenant Name"
          class="search-box"
        />
        <button class="add-new-button" @click="handleAddNew">+ Add New</button>
      </div>
    </div>

    <div class="tbl-header">
      <table cellpadding="0" cellspacing="0" border="0">
        <thead>
          <tr>
            <th>
              Tenant Name
              <span
                @click="sortBy('tenantName')"
                :class="{
                  asc: sortByField === 'tenantName' && isAscending,
                  desc: sortByField === 'tenantName' && isDescending,
                }"
              >
                <i class="sort-icon"></i>
              </span>
            </th>
            <th>Phone Number</th>
            <th>Email Address</th>
            <th>Date of Birth</th>
            <th>
              Nationality
              <span
                @click="sortBy('tenantNationality')"
                :class="{
                  asc: sortByField === 'tenantNationality' && isAscending,
                  desc: sortByField === 'tenantNationality' && isDescending,
                }"
              >
                <i class="sort-icon"></i>
              </span>
            </th>
            <th>Actions</th>
          </tr>
        </thead>
      </table>
    </div>

    <div class="tbl-content">
      <table cellpadding="0" cellspacing="0" border="0">
        <tbody>
          <tr v-for="tenant in paginatedTenants" :key="tenant.id">
            <td>{{ tenant.tenantName }}</td>
            <td>{{ tenant.tenantNumber }}</td>
            <td>{{ tenant.tenantEmail }}</td>
            <td>{{ formatDate(tenant.tenantDOB) }}</td>
            <!-- for now use DOB to substitute date expiry -->
            <td>{{ tenant.tenantNationality }}</td>
            <td>
              <div class="wrapper">
                <button
                  @click="handleButtonClick(tenant.id)"
                  class="view-button"
                >
                  View
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <br /><br />
    <div class="pagination">
      <button
        v-for="pageNum in totalPages"
        :key="pageNum"
        @click="changePage(pageNum)"
        :class="{ active: pageNum === currentPage }"
      >
        {{ pageNum }}
      </button>
    </div>
  </div>
</template>

<script>
import { collection, query, getDocs, doc } from "firebase/firestore"; // Import Firestore functions
import { db, auth } from "@/firebase.js";

export default {
  data() {
    return {
      tenantData: [],
      sortAscending: false,
      sortByField: null,
      itemsPerPage: 10,
      currentPage: 1,
      searchName: "",
    };
  },
  watch: {
    searchName: function () {
      this.performSearchName();
    },
  },
  async created() {
    // Get all Docs from Tenant Collection //
    const dbUser = doc(db, "Users", auth.currentUser.email);
    const tenantCollectionRef = collection(dbUser, "Tenant");

    const qTenant = query(tenantCollectionRef);
    const querySnapshotTenant = await getDocs(qTenant);
    this.tenantData = querySnapshotTenant.docs.map((doc) => {
      // Include the Property ID in the mapped data object
      return { id: doc.id, ...doc.data() };
    });
  },
  methods: {
    // Handles Creation of New Tenant //
    handleAddNew() {
      this.$router.push("create-new-tenant");
    },
    // Handles View of Tenant Incident //
    handleButtonClick(tenantID) {
      this.$router.push({ name: "view-tenant", params: { tenantID } });
    },
    // Formats Timestamp to Date Format for Display //
    formatDate(timestamp) {
      const date = new Date(timestamp.seconds * 1000); // Convert timestamp to Date
      const day = date.getDate();
      const month = date.toLocaleString("default", { month: "long" });
      const year = date.getFullYear();
      return `${day} ${month} ${year}`;
    },
    // Searches the Tenant based on the input from TenantName //
    async performSearchName() {
      // Get Tenant Data //
      const dbUser = doc(db, "Users", auth.currentUser.email);
      const tenantCollectionRef = collection(dbUser, "Tenant");

      const qTenant = query(tenantCollectionRef);
      const querySnapshotTenant = await getDocs(qTenant);
      this.tenantData = querySnapshotTenant.docs
        .map((doc) => {
          // Include the Property ID in the mapped data object
          return { id: doc.id, ...doc.data() };
        }) // Filters for Tenant that has matching TenantName //
        .filter((data) => data.tenantName.includes(this.searchName));
    },
    sortBy(field) {
      if (this.sortByField === field) {
        this.sortAscending = !this.sortAscending;
      } else {
        this.sortByField = field;
        this.sortAscending = true;
      }

      // Sort the data array based on the selected field and sort order
      this.tenantData.sort((a, b) => {
        const aValue = a[field];
        const bValue = b[field];

        if (this.sortAscending) {
          return aValue.localeCompare(bValue);
        } else {
          return bValue.localeCompare(aValue);
        }
      });
    },
    // Handles the Change in New Page Number //
    changePage(pageNumber) {
      this.currentPage = pageNumber;
    },
  },

  computed: {
    sortedTenantData() {
      // Return a sorted copy of the data
      const sortedData = [...this.tenantData];
      if (this.sortByField) {
        sortedData.sort((a, b) => {
          const aValue = a[this.sortByField];
          const bValue = b[this.sortByField];

          if (this.sortAscending) {
            return aValue.localeCompare(bValue);
          } else {
            return bValue.localeCompare(aValue);
          }
        });
      }
      return sortedData;
    },
    // Computed the Total Number of Pages //
    totalPages() {
      try {
        const number = Math.ceil(this.tenantData.length / this.itemsPerPage);
        return number;
      } catch {
        return 1;
      }
    },
    // Returns the 10 Incident to be Displayed based on the currentPage Number //
    paginatedTenants() {
      try {
        const start = (this.currentPage - 1) * this.itemsPerPage;
        const end = this.currentPage * this.itemsPerPage;
        return this.tenantData.slice(start, end);
      } catch {
        return this.tenantData;
      }
    },
  },
};
</script>

<style scoped>
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.header-controls {
  display: flex;
  align-items: center;
}

.search-box {
  margin-right: 10px;
  padding: 8px;
  width: 200px;
  height: 28px;
  border: 1px solid #ffffff;
  border-radius: 4px;
  color: black; /* Text color */
  background-color: white;
  border-radius: 10px;
}

.add-new-button {
  margin-right: 10px;
  padding: 8px;
  width: 120px;
  height: 44px;
  border: 1px solid #ffffff;
  border-radius: 4px;
  background-color: #3c38db; /* Text color */
  color: #fff;
  cursor: pointer;
  border-radius: 10px;
  margin-top: 0px;
  margin-bottom: 0px;
}
h3 {
  color: black;
  text-align: left;
  margin: 0;
}

table {
  width: 100%;
  table-layout: auto;
  background-color: #f1f4fa;
}

.tbl-header {
  background-color: #f1f4fa;
}

.tbl-content {
  height: fit-content;
  margin-top: 0px;
  border: 1px solid #f1f4fa;
}

th {
  padding: 20px 8px;
  text-align: left;
  font-weight: 500;
  font-size: 14.22px;
  background-color: #f1f4fa;
}

td {
  padding: 8px;
  font-weight: 300;
  font-size: 14.22px;
  background-color: white;
  border-bottom: solid 1px rgba(255, 255, 255, 0.1);
}

th:nth-child(1) {
  text-align: left;
  padding-left: 15px;
  width: 20%;
}

td:nth-child(1) {
  border-top-left-radius: 20px; /* Add a curve to the top-left corner */
  border-bottom-left-radius: 20px; /* Add a curve to the bottom-left corner */
  padding-left: 15px;
  width: 20%;
  text-align: left;
}

td:nth-child(2) {
  text-align: center;
  padding-left: 8px;
  width: 15%;
  /* overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap; */
}
th:nth-child(2) {
  text-align: center;
  width: 15%;
}

td:nth-child(3) {
  text-align: left;
  padding-left: 8px;
  width: 20%;
  /* overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap; */
}
th:nth-child(3) {
  text-align: left;
  width: 20%;
}

td:nth-child(4) {
  text-align: center;
  padding-left: 8px;
  width: 15%;
  /* overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap; */
}
th:nth-child(4) {
  text-align: center;
  width: 15%;
}

td:nth-child(5) {
  text-align: center;
  padding-left: 8px;
  width: 15%;
}
th:nth-child(5) {
  text-align: center;
  width: 15%;
}
th:nth-child(6) {
  text-align: center;
  width: 15%;
}
.wrapper {
  display: flex;
  justify-content: center;
}
td {
  padding: 8px;
  text-align: left;
  vertical-align: middle;
  font-weight: 300;
  font-size: 14.22px;
  background-color: white;
  border-bottom: solid 1px rgba(255, 255, 255, 0.1);
  height: 50px;
}
td:last-child {
  border-top-right-radius: 20px; /* Add a curve to the top-right corner */
  border-bottom-right-radius: 20px; /* Add a curve to the bottom-right corner */
  text-align: center;
}

/* Add a small separator between rows */
tr + tr td {
  border-top: 10px solid #f7f7f8;
}

@import url(https://fonts.googleapis.com/css?family=Roboto:400,500,300,700);
body {
  background: -webkit-linear-gradient(left, #25c481, #25b7c4);
  background: linear-gradient(to right, #25c481, #25b7c4);
  font-family: "Roboto", sans-serif;
}

section {
  margin: 50px;
}

.view-button {
  width: 100px;
  height: 35px;
  border-radius: 16px;
  background-color: #364153;
  color: #fff;
  cursor: pointer;
  border: none;
}

/* Style the button on hover (optional) */
.view-button:hover {
  background-color: #4c9cac;
}
.sort-icon {
  display: inline-block;
  width: 0;
  height: 0;
  border-left: 5px solid transparent;
  border-right: 5px solid transparent;
  border-top: 8px solid #000; /* Adjust color as needed */
}

.asc {
  transform: rotate(180deg); /* Upside-down triangle for ascending order */
}

.desc {
  transform: rotate(180deg); /* Normal triangle for descending order */
}

.pagination {
  display: flex;
  justify-content: flex-end;
}

.pagination button {
  border: none; /* Remove the outline */
  color: #06152b; /* Set the text color */
  background-color: #f1f4fa;
  text-decoration: none;
}

.pagination button.active {
  text-decoration: underline; /* Underline the selected page */
}
</style>
