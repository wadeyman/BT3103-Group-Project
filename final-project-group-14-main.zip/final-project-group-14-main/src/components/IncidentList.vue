<template>
  <div class="container">
    <div class="header">
      <h1 style="margin-top: 0px; margin-bottom: 0px">Incident Management</h1>
      <div class="header-controls">
        <input
          v-model="searchName"
          type="text"
          placeholder="Search Incident Title"
          class="search-box"
        />
        <button @click="handleAddNew" class="add-new-button">+ Add New</button>
      </div>
    </div>
    <div class="tbl-header">
      <table cellpadding="0" cellspacing="0" border="0">
        <thead>
          <tr>
            <th>Reporter</th>
            <th>Property Name</th>
            <th>Incident</th>
            <th>Incident Date</th>
            <th>Resolve Status</th>
            <th>Actions</th>
          </tr>
        </thead>
      </table>
    </div>
    <div class="tbl-content">
      <table cellpadding="0" cellspacing="0" border="0">
        <tbody>
          <tr v-for="incident in paginatedIncidents" :key="incident.id">
            <td>{{ incident.reporterName }}</td>
            <td>{{ incident.propertyName }}</td>
            <td>{{ incident.title }}</td>
            <td>{{ this.formatDate(incident.reportedDate) }}</td>
            <td>
              <div class="wrapper" v-if="incident.status === 'Resolved'">
                <p class="status-indicator resolved">{{ incident.status }}</p>
              </div>
              <div class="wrapper" v-else-if="incident.status === 'Resolving'">
                <p class="status-indicator resolving">{{ incident.status }}</p>
              </div>
              <div class="wrapper" v-else>
                <p class="status-indicator unresolved">{{ incident.status }}</p>
              </div>
            </td>
            <td>
              <div class="wrapper">
                <button
                  @click="handleButtonClick(incident.id)"
                  class="view-button"
                >
                  View
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <br /><br />
    <!-- Pagination -->
    <div class="pagination">
      <button
        v-for="pageNum in totalPages"
        :key="pageNum"
        @click="changePage(pageNum)"
        :class="{ active: pageNum === currentPage }"
      >
        {{ pageNum }}
      </button>
    </div>
  </div>
</template>

<script>
import { db, auth } from "@/firebase.js";
import { collection, doc, getDocs, query } from "firebase/firestore";

export default {
  data() {
    return {
      sortAscending: false,
      sortByField: null,
      incidentArray: [],
      itemsPerPage: 10,
      currentPage: 1,
      searchName: "",
    };
  },
  async created() {
    // Get all Docs from Incident Collection //
    const dbUser = doc(db, "Users", auth.currentUser.email);
    const incidentCollectionref = collection(dbUser, "Incident");
    const q = query(incidentCollectionref);
    const querySnapshot = await getDocs(q);
    const results = querySnapshot.docs.map((doc) => {
      // Include the Property ID in the mapped data object //
      return { id: doc.id, ...doc.data() };
    });

    this.incidentArray = results;

    // Get Reporter Name of Each Incident based on Reporter ID //
    this.doNameInsert();
  },
  watch: {
    // Handles the Search for Incident when changes to Search Bar is made //
    searchName: function () {
      this.performSearchName();
    },
  },
  methods: {
    // Handles Creation of New Incident //
    handleAddNew() {
      this.$router.push("create-new-incident");
    },
    // Handles View of Individual Incident //
    handleButtonClick(incidentID) {
      this.$router.push({ name: "view-incident", params: { incidentID } });
    },
    // Formats Timestamp to Date Format for Display //
    formatDate(timestamp) {
      const date = new Date(timestamp.seconds * 1000); // Convert timestamp to Date
      const day = date.getDate();
      const month = date.toLocaleString("default", { month: "long" });
      const year = date.getFullYear();
      return `${day} ${month} ${year}`;
    },
    // Searches the Incident based on the input from Incident Title //
    async performSearchName() {
      // Get Incident Data //
      const dbUser = doc(db, "Users", auth.currentUser.email);
      const incidentCollectionref = collection(dbUser, "Incident");
      const q = query(incidentCollectionref);
      const querySnapshot = await getDocs(q);
      const results = querySnapshot.docs
        .map((doc) => {
          // Include the Property ID in the mapped data object //
          return { id: doc.id, ...doc.data() };
        }) // Filters for Incident that has matching Incident Title //
        .filter((data) => data.title.includes(this.searchName));

      this.incidentArray = results;
      // Get Reporter Name of Each Incident based on Reporter ID //
      this.doNameInsert();
    },
    async doNameInsert() {
      const dbUser = doc(db, "Users", auth.currentUser.email);

      // GET ALL PROPERTY INFORMATION //
      const propColRef = collection(dbUser, "Property");
      const q = query(propColRef);
      const querySnapshotProp = await getDocs(q);
      const propsData = querySnapshotProp.docs.map((doc) => {
        // Include the Property ID in the mapped data object
        return { id: doc.id, ...doc.data() };
      });

      // GET ALL TENANT INFORMATION //
      const TenantColRef = collection(dbUser, "Tenant");
      const t = query(TenantColRef);
      const querySnapshotTenant = await getDocs(t);
      const tenData = querySnapshotTenant.docs.map((doc) => {
        // Include the tenant ID in the mapped data object
        return { id: doc.id, ...doc.data() };
      });

      // GET ALL LANDLORD INFORMATION //
      const LLColRef = collection(dbUser, "Landlord");
      const L = query(LLColRef);
      const querySnapshotLL = await getDocs(L);
      const llData = querySnapshotLL.docs.map((doc) => {
        // Include the tenant ID in the mapped data object
        return { id: doc.id, ...doc.data() };
      });

      this.incidentArray.forEach((docs) => {
        // Match PropertyID of Incident to Property Colleciton //
        const property = propsData.find(
          (props) => props.id === docs.propertyID
        );
        // Extract Property Name //
        docs.propertyName = property.propertyName;

        // Find the name of the Reporter based on if they are Tenant or Landlord //
        if (docs.reporterID.includes("Tenant")) {
          const tenant = tenData.find(
            (tenants) => tenants.id === docs.reporterID
          );
          docs.reporterName = tenant.tenantName;
        } else if (docs.reporterID.includes("Landlord")) {
          const landlord = llData.find((ll) => ll.id === docs.reporterID);
          docs.reporterName = landlord.landlordName;
        }
      });
    },
    // Handles the Change in New Page Number //
    changePage(pageNumber) {
      this.currentPage = pageNumber;
    },
  },

  computed: {
    // Computed the Total Number of Pages //
    totalPages() {
      try {
        const number = Math.ceil(this.incidentArray.length / this.itemsPerPage);
        return number;
      } catch {
        return 1;
      }
    },
    // Returns the 10 Incident to be Displayed based on the currentPage Number //
    paginatedIncidents() {
      try {
        const start = (this.currentPage - 1) * this.itemsPerPage;
        const end = this.currentPage * this.itemsPerPage;
        return this.incidentArray.slice(start, end);
      } catch {
        return this.incidentArray;
      }
    },
  },
};
</script>

<style scoped>
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.header-controls {
  display: flex;
  align-items: center;
}

.search-box {
  margin-right: 10px;
  padding: 8px;
  width: 200px;
  height: 28px;
  border: 1px solid #ffffff;
  border-radius: 4px;
  color: black; /* Text color */
  background-color: white;
  border-radius: 10px;
}

.add-new-button {
  margin-right: 10px;
  padding: 8px;
  width: 120px;
  height: 44px;
  border: 1px solid #ffffff;
  border-radius: 4px;
  background-color: #3c38db; /* Text color */
  color: #fff;
  cursor: pointer;
  border-radius: 10px;
  margin-top: 0px;
  margin-bottom: 0px;
}

h3 {
  color: black;
  text-align: left;
  margin: 0;
}

table {
  width: 100%;
  table-layout: auto;
  background-color: #f1f4fa;
}

.tbl-header {
  background-color: #f7f7f8;
}

.tbl-content {
  height: fit-content;
  margin-top: 0px;
  border: 1px solid #f1f4fa;
}

th {
  padding: 20px 8px;
  font-weight: 500;
  font-size: 14.22px;
  background-color: #f1f4fa;
}

th:nth-child(1) {
  text-align: left;
  padding-left: 15px;
  width: 15%;
}

td:first-child {
  border-top-left-radius: 20px; /* Add a curve to the top-left corner */
  border-bottom-left-radius: 20px; /* Add a curve to the bottom-left corner */
  padding-left: 15px;
  width: 15%;
  text-align: left;
}

td:nth-child(2) {
  text-align: left;
  padding-left: 8px;
  width: 20%;
}
th:nth-child(2) {
  text-align: left;
  width: 20%;
}

td:nth-child(3) {
  text-align: left;
  padding-left: 8px;
  width: 20%;
}
th:nth-child(3) {
  text-align: left;
  width: 20%;
}

td:nth-child(4) {
  text-align: center;
  padding-left: 8px;
  width: 15%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
th:nth-child(4) {
  text-align: center;
  width: 15%;
}

td:nth-child(5) {
  text-align: center;
  padding-left: 8px;
  width: 15%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin: auto;
}
th:nth-child(5) {
  text-align: center;
  width: 15%;
}

.wrapper {
  display: flex;
  justify-content: center;
}

td {
  padding: 8px;
  text-align: left;
  vertical-align: middle;
  font-weight: 300;
  font-size: 14.22px;
  background-color: white;
  border-bottom: solid 1px rgba(255, 255, 255, 0.1);
  height: 50px;
}

td:last-child {
  border-top-right-radius: 20px; /* Add a curve to the top-right corner */
  border-bottom-right-radius: 20px; /* Add a curve to the bottom-right corner */
  text-align: middle;
}

/* Add a small separator between rows */
tr + tr td {
  border-top: 10px solid #f7f7f8;
}

@import url(https://fonts.googleapis.com/css?family=Roboto:400,500,300,700);
body {
  background: -webkit-linear-gradient(left, #25c481, #25b7c4);
  background: linear-gradient(to right, #25c481, #25b7c4);
  font-family: "Roboto", sans-serif;
}

.pagination {
  display: flex;
  justify-content: flex-end;
}

.pagination button {
  border: none; /* Remove the outline */
  color: #06152b; /* Set the text color */
  background-color: #f1f4fa;
  text-decoration: none;
}

.pagination button.active {
  text-decoration: underline; /* Underline the selected page */
}
.view-button {
  width: 100px;
  height: 35px;
  border-radius: 16px;
  background-color: #364153;
  color: #fff;
  cursor: pointer;
  border: none;
}

/* Style the button on hover (optional) */
.view-button:hover {
  background-color: #4c9cac;
}
.sort-icon {
  display: inline-block;
  width: 0;
  height: 0;
  border-left: 5px solid transparent;
  border-right: 5px solid transparent;
  border-top: 8px solid #000; /* Adjust color as needed */
}

.asc {
  transform: rotate(180deg); /* Upside-down triangle for ascending order */
}

.desc {
  transform: rotate(180deg); /* Normal triangle for descending order */
}

.status-indicator {
  width: 150px;
  height: 40px;
  border-radius: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: normal;
  margin: 0; /* Reset default margin */
}

.resolved {
  background-color: #e6f7f6;
  color: #13aea4;
}

.resolving {
  background-color: #ecebfc;
  color: #3c38db;
}

.unresolved {
  background-color: #fff0f8;
  color: #ff69b4;
}
</style>
