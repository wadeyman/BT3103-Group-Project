<template>
  <div class="modal-backdrop">
    <div class="modal">
      <header class="modal-header">
        <slot name="header">
          {{message}}
        </slot>

          <button
            type="button"
            class="btn-close"
            @click="close"
            aria-label="Close modal"
          >
            x
          </button>
      </header>

        <footer class="modal-footer">
          <div class='button-wrapper'>
          <button
          type="button"
          class="btn-primary"
          @click="close"
        >
          Confirm </button>
        </div>
        
                </footer>
    </div>
  </div>
</template>

<script>
  export default {
    // eslint-disable-next-line vue/multi-word-component-names
    name: 'MessageModal',
    props: {
      message: String, 
    },
    methods: {
      close() {
        this.$emit('close');
      },
    }
  };
</script>

<style>
  .modal-backdrop {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background-color: rgba(0, 0, 0, 0.3);
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .modal {
    background: #F1F4FA;
    box-shadow: 2px 2px 20px 1px;
    overflow-x: auto;
    display: flex;
    flex-direction: column;
    border-radius: 10px;
    width: 30%;
  }

  .modal-header,
  .modal-footer {
    padding: 15px;
    display: flex;
    font-size: 18px;
  }

  .modal-header {
    position: relative;
    border-bottom: 1px solid #eeeeee;
    color: var(--primary-accent);
    justify-content: space-between;
    padding-left: 20px;
  }

  .modal-footer {
    border-top: 1px solid #eeeeee;
    flex-direction: column;
    justify-content: flex-end;
  }

  .modal-body {
    position: relative;
    padding: 20px 10px;
    padding-left: 20px;
  }

  .btn-close {
    position: absolute;
    top: 0;
    right: 0;
    border: none;
    font-size: 20px;
    padding: 10px;
    cursor: pointer;
    font-weight: bold;
    color: var(--primary-accent);
    background: transparent;
  }

  .btn-primary {
    color: white;
    background: var(--primary-accent);
    border: 1px solid var(--primary-accent);
    border-radius: 10px;
    height: 50px;
    width: 200px;
    font-size: 18px;
    cursor: pointer;
  }

  .btn-secondary {
    color: black;
    background: transparent;
    border: 3px solid var(--primary-accent);
    border-radius: 10px;
    height: 50px;
    width: 200px;
    font-size: 18px;
    cursor: pointer;
  }

  .button-wrapper { 
    display: flex; 
    width: 100%; 
    justify-content: space-around;
  }
</style>