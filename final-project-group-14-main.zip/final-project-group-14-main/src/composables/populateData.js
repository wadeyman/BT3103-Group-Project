/* eslint-disable */ 
import {firebaseApp} from '../firebase.js'
import { getFirestore} from 'firebase/firestore'
import { collection, doc, setDoc, Timestamp} from 'firebase/firestore'
import { getStorage, ref, uploadBytes} from 'firebase/storage'
// import Property1 from '@/assets/Property1.jpg'
// import Property2 from '@/assets/Property2.jpg'
// import Property3 from '@/assets/Property3.jpg'
// import Property4 from '@/assets/Property4.jpg'
// import Property5 from '@/assets/Property5.jpg'
// import Property6 from '@/assets/Property6.jpg'
// import Property7 from '@/assets/Property7.jpg'
// import Property8 from '@/assets/Property8.jpg'
// import Property9 from '@/assets/Property9.jpg'
// import Property10 from '@/assets/Property10.jpg'
// import Property11 from '@/assets/Property11.jpg'
// import Property12 from '@/assets/Property12.jpg'


export async function populateData(user) { 
    const db = getFirestore(firebaseApp); 

    generateTenantData();
    generateLandlordData();
    generateIncidentData();
    generatePropertyData();
    generateLeaseData();
    // uploadPropertyPhotos();

    // async function uploadPropertyPhotos() {
   
    //     let storageImagesRef;     
    //     storageImagesRef = ref(getStorage(firebaseApp),'images/Property1.jpg');
    //     let response = await fetch(Property1)
    //     let blob = await response.blob();
    //     uploadBytes(storageImagesRef, blob).then(() => {console.log("Images Uploaded Successfully")});

    //     storageImagesRef = ref(getStorage(firebaseApp),'images/Property2.jpg');
    //     response = await fetch(Property2)
    //     blob = await response.blob();
    //     uploadBytes(storageImagesRef, blob).then(() => {console.log("Images Uploaded Successfully")});
    
    //     storageImagesRef = ref(getStorage(firebaseApp),'images/Property3.jpg');
    //     response = await fetch(Property3)
    //     blob = await response.blob();
    //     uploadBytes(storageImagesRef, blob).then(() => {console.log("Images Uploaded Successfully")});

    //     storageImagesRef = ref(getStorage(firebaseApp),'images/Property4.jpg');
    //     response = await fetch(Property4)
    //     blob = await response.blob();
    //     uploadBytes(storageImagesRef, blob).then(() => {console.log("Images Uploaded Successfully")});

    //     storageImagesRef = ref(getStorage(firebaseApp),'images/Property5.jpg');
    //     response = await fetch(Property5)
    //     blob = await response.blob();
    //     uploadBytes(storageImagesRef, blob).then(() => {console.log("Images Uploaded Successfully")});

    //     storageImagesRef = ref(getStorage(firebaseApp),'images/Property6.jpg');
    //     response = await fetch(Property6)
    //     blob = await response.blob();
    //     uploadBytes(storageImagesRef, blob).then(() => {console.log("Images Uploaded Successfully")});

    //     storageImagesRef = ref(getStorage(firebaseApp),'images/Property7.jpg');
    //     response = await fetch(Property7)
    //     blob = await response.blob();
    //     uploadBytes(storageImagesRef, blob).then(() => {console.log("Images Uploaded Successfully")});

    //     storageImagesRef = ref(getStorage(firebaseApp),'images/Property8.jpg');
    //     response = await fetch(Property8)
    //     blob = await response.blob();
    //     uploadBytes(storageImagesRef, blob).then(() => {console.log("Images Uploaded Successfully")});

    //     storageImagesRef = ref(getStorage(firebaseApp),'images/Property9.jpg');
    //     response = await fetch(Property9)
    //     blob = await response.blob();
    //     uploadBytes(storageImagesRef, blob).then(() => {console.log("Images Uploaded Successfully")});

    //     storageImagesRef = ref(getStorage(firebaseApp),'images/Property10.jpg');
    //     response = await fetch(Property10)
    //     blob = await response.blob();
    //     uploadBytes(storageImagesRef, blob).then(() => {console.log("Images Uploaded Successfully")});

    //     storageImagesRef = ref(getStorage(firebaseApp),'images/Property11.jpg');
    //     response = await fetch(Property11)
    //     blob = await response.blob();
    //     uploadBytes(storageImagesRef, blob).then(() => {console.log("Images Uploaded Successfully")});

    //     storageImagesRef = ref(getStorage(firebaseApp),'images/Property12.jpg');
    //     response = await fetch(Property12)
    //     blob = await response.blob();
    //     uploadBytes(storageImagesRef, blob).then(() => {console.log("Images Uploaded Successfully")});

    // }

    // CREATE DATA FOR TENANT //
    function generateTenantData() { 

        const tenantDocument = 'Tenant'        
        const dbUser = doc(db, "Users", user.email);
        const tenantDocumentRef = collection(dbUser, tenantDocument);
    
        const tenantDataList = [
            { tenantName: 'Lim Jun Ying', tenantNumber: '+65 98412178', tenantEmail: 'Lim_Jun_Ying@gmail.com', tenantNationality: 'Singaporean',
              tenantDOB: new Date('1998-05-10'), tenantGender: 'Male', tenantAddress: 'Yishun Ring Road 764251 #04-5648'},
            { tenantName: 'Hui Rong', tenantNumber: '+65 93453453', tenantEmail: 'Hui_Rong@gmail.com', tenantNationality: 'Singaporean',
              tenantDOB: new Date('2000-06-10'), tenantGender: 'Male', tenantAddress: 'Geylang Drive Blk123 #05-1344'},
            { tenantName: 'Sarah Han', tenantNumber: '+65 93534654', tenantEmail: 'Sarah_Han@gmail.com', tenantNationality: 'Singaporean',
              tenantDOB: new Date('1998-06-10'), tenantGender: 'Female', tenantAddress: 'Sim Lim Avenue Blk454'},
            { tenantName: 'Wei Han', tenantNumber: '+65 98536535', tenantEmail: 'Wei_Han@gmail.com', tenantNationality: 'Singaporean',
              tenantDOB: new Date('1987-12-13'), tenantGender: 'Male', tenantAddress: '34 Serangoon Road 874542'},
            { tenantName: 'Tyler Ong', tenantNumber: '+65 94754444', tenantEmail: 'Tyler@gmail.com', tenantNationality: 'Singaporean',
              tenantDOB: new Date('1968-01-10'), tenantGender: 'Male', tenantAddress: '21 Wan Lee Rd'},
            { tenantName: 'Christopher', tenantNumber: '+65 98455443', tenantEmail: 'Chris_Ong@gmail.com', tenantNationality: 'German',
              tenantDOB: new Date('1998-02-11'), tenantGender: 'Male', tenantAddress: 'asia 30 raffles place 23-00 chevron house'},
            { tenantName: 'Angela Lim', tenantNumber: '+65 95365365', tenantEmail: 'Angela_Lim@gmail.com', tenantNationality: 'Singaporean',
              tenantDOB: new Date('1996-03-12'), tenantGender: 'Female', tenantAddress: '727 Clementi West Street 2'},
            { tenantName: 'Rachel Aw', tenantNumber: '+65 82342455', tenantEmail: 'Rachel@gmail.com', tenantNationality: 'Singaporean',
              tenantDOB: new Date('1995-04-13'), tenantGender: 'Female', tenantAddress: 'Lorong 7 Toa Payoh Block 22A Food Centre 22A Lorong 7 Toa Payoh #01-414'},
            { tenantName: 'Germaine Ow', tenantNumber: '+65 84552424', tenantEmail: 'Germaine@gmail.com', tenantNationality: 'Singaporean',
              tenantDOB: new Date('1994-05-14'), tenantGender: 'Female', tenantAddress: '80 Playfair Road Blk A'},
            { tenantName: 'Muhamand Ali', tenantNumber: '+65 92452414', tenantEmail: 'Muhamand_Ali@gmail.com', tenantNationality: 'Malaysian',
              tenantDOB: new Date('2000-06-15'), tenantGender: 'Male', tenantAddress: '10 HOE CHIANG ROAD, #14-04A'},
            { tenantName: 'Francis Kho', tenantNumber: '+65 92454222', tenantEmail: 'Francis@gmail.com', tenantNationality: 'Filiphino',
              tenantDOB: new Date('2001-07-16'), tenantGender: 'Male', tenantAddress: '30 Tech Park Crescent'},
            { tenantName: 'Jesscia Specter', tenantNumber: '+65 84352543', tenantEmail: 'Jesscia_Specter@gmail.com', tenantNationality: 'American',
              tenantDOB: new Date('1994-08-17'), tenantGender: 'Female', tenantAddress: '170 Lorong 1 Toa Payoh, Toa Payoh'},
            { tenantName: 'Mike Ross', tenantNumber: '+65 82352234', tenantEmail: 'Mike_Ross@gmail.com', tenantNationality: 'Amercian',
              tenantDOB: new Date('1994-09-18'), tenantGender: 'Male', tenantAddress: '230B BALESTIER ROAD'},
            { tenantName: 'Harvey Spector', tenantNumber: '+65 92452465', tenantEmail: 'Harvey Spector@gmail.com', tenantNationality: 'British',
              tenantDOB: new Date('1996-10-19'), tenantGender: 'Male', tenantAddress: '101 THOMSON ROAD, #B1-28'},
      ]
      
      tenantDataList.forEach(async (tenantData, index) => {
          const tenantID = `Tenant${index + 1}`;
  
          const tenantDocRef = doc(tenantDocumentRef, tenantID);
          
          const birthDataTimeStamp = Timestamp.fromDate(tenantData.tenantDOB);
  
          tenantData.tenantDOB = birthDataTimeStamp;
  
          tenantData.leasesID = [];
  
          try {
              await setDoc(tenantDocRef, tenantData);
          } catch (error) {
              console.error("Error", error);
          }
      }
          
  
      )      
    }

    // CREATE DATA FOR LANDLORD //
    function generateLandlordData() { 

        const Document = 'Landlord'        
        const dbUser = doc(db, "Users", user.email);
        const userCollection = collection(dbUser, Document);
    
        const DataList = [
            { landlordName: 'Angela', landlordNumber: '+65 98145622', landlordEmail: 'Angela@gmail.com', landlordNationality: 'Singaporean',
                landlordDOB: new Date('1998-05-10'), landlordGender: 'Female', landlordAddress: '105 105 Sims Avenue 05-12 Chancerlodge Complex'},
            { landlordName: 'Lambert Michaela', landlordNumber: '+65 81568122', landlordEmail: 'Lambert@gmail.com', landlordNationality: 'Singaporean',
                landlordDOB: new Date('1997-02-11'), landlordGender: 'Male', landlordAddress: 'Blk 22 Woodlands Link #04-01/04 Woodlands East Ind Est S'},
            { landlordName: 'Marianne Garcia', landlordNumber: '+65 98788121', landlordEmail: 'Marianne@gmail.com', landlordNationality: 'Malaysian',
                landlordDOB: new Date('1996-04-12'), landlordGender: 'Female', landlordAddress: 'Y52 College Green'},
            { landlordName: 'Amira Odling', landlordNumber: '+65 8156218', landlordEmail: 'Amira@gmail.com', landlordNationality: 'Singaporean',
                landlordDOB: new Date('1996-05-13'), landlordGender: 'Male', landlordAddress: 'HDB-Clementi 325 Clementi Avenue 5 #01-155'},
            { landlordName: 'Kobe Weiss', landlordNumber: '+65 98421451', landlordEmail: 'Weiss@gmail.com', landlordNationality: 'German',
                landlordDOB: new Date('1995-06-14'), landlordGender: 'Male', landlordAddress: '9008 Tampines St 93 #04-07'},
            { landlordName: 'Kobi Chase', landlordNumber: '+65 81561127', landlordEmail: 'Chase@gmail.com', landlordNationality: 'British',
                landlordDOB: new Date('1994-07-15'), landlordGender: 'Male', landlordAddress: '1002 Jalan Bukit Merah, 06-12'},
            { landlordName: 'Mari Vance', landlordNumber: '+65 99156784', landlordEmail: 'Vance@gmail.com', landlordNationality: 'Singaporean',
                landlordDOB: new Date('1993-08-16'), landlordGender: 'Female', landlordAddress: '105 CECIL STREET 18-00'},
            { landlordName: 'Junior Mendoza', landlordNumber: '+65 81675468', landlordEmail: 'Mendoza@gmail.com', landlordNationality: 'Malaysian',
                landlordDOB: new Date('1992-09-17'), landlordGender: 'Male', landlordAddress: ' 8 Tuas Avenue 2'},
            { landlordName: 'Jessie Ayala', landlordNumber: '+65 98157534', landlordEmail: 'Ayala@gmail.com', landlordNationality: 'German',
                landlordDOB: new Date('1991-10-18'), landlordGender: 'Female', landlordAddress: '10 Veerasamy Road'},
            { landlordName: 'Clifford Daniels', landlordNumber: '+65 81238888', landlordEmail: 'Daniels@gmail.com', landlordNationality: 'Singaporean',
                landlordDOB: new Date('1990-11-19'), landlordGender: 'Male', landlordAddress: ' 10 Jalan Kilang Timor #05-04A LTH BUILDING'},
            { landlordName: 'Georgia Walton', landlordNumber: '+65 98435815', landlordEmail: 'Walton@gmail.com', landlordNationality: 'Malaysian',
                landlordDOB: new Date('1989-12-20'), landlordGender: 'Male', landlordAddress: '113 Aljunied Ave 2 #01-11'},
            { landlordName: 'Kamran Douglas', landlordNumber: '+65 98425427', landlordEmail: 'Douglas@gmail.com', landlordNationality: 'Malaysian',
                landlordDOB: new Date('1996-05-21'), landlordGender: 'Male', landlordAddress: 'HDB-Bukit Batok 284 Bukit Batok East Avenue 3 #01-251'},
            { landlordName: 'Melanie Turner', landlordNumber: '+65 98712372', landlordEmail: 'Turner@gmail.com', landlordNationality: 'Singaporean',
                landlordDOB: new Date('1968-02-22'), landlordGender: 'Male', landlordAddress: '1 Rochor Road #03-550 Rochor Centre'},
            { landlordName: 'Rhodri Odling', landlordNumber: '+65 94567878', landlordEmail: 'Odling@gmail.com', landlordNationality: 'Singaporean',
                landlordDOB: new Date('1973-01-23'), landlordGender: 'Male', landlordAddress: '167 Jalan Bukit Merah #06-12 Connection One'},
            { landlordName: 'Yasir Miranda', landlordNumber: '+65 98754321', landlordEmail: 'Miranda@gmail.com', landlordNationality: 'American',
                landlordDOB: new Date('1988-03-24'), landlordGender: 'Female', landlordAddress: '139 Ave'},
            { landlordName: 'Bobby Palmer', landlordNumber: '+65 87447775', landlordEmail: 'Palmer@gmail.com', landlordNationality: 'Singaporean',
                landlordDOB: new Date('1985-04-25'), landlordGender: 'Male', landlordAddress: '190 SYED ALWI RD'},
            { landlordName: 'Nathaniel Mathews', landlordNumber: '+65 98425254', landlordEmail: 'Mathews@gmail.com', landlordNationality: 'Singaporean',
                landlordDOB: new Date('1983-06-26'), landlordGender: 'Male', landlordAddress: '15 Defu Lane 7'},
        ]
        
        DataList.forEach(async (Data, index) => {
            const documentID = `Landlord${index + 1}`;
    
            const docRef = doc(userCollection, documentID);
            const birthDataTimeStamp = Timestamp.fromDate(Data.landlordDOB);
    
            Data.landlordDOB = birthDataTimeStamp;
    
            // Data.leasesID = [];

            try {
                await setDoc(docRef, Data);
            } catch (error) {
                console.error("Error", error);
            }
        }
            
    
        )      
      }

    // CREATE DATA FOR INCIDENT //
    function generateIncidentData() { 

        const Document = 'Incident'        
        const dbUser = doc(db, "Users", user.email);
        const userCollection = collection(dbUser, Document);
    
        const DataList = [
            { propertyID: 'Property1', reporterID: 'Tenant1', title: 'Aircon Malfunction. Not Cold', description: 'Tenant have complained that the aircon is no longer old. Servicing may be required for the unit as it may have been so time since it was last serviced',
                status: "Resolved", reportedDate: new Date('2023-10-10'), resolvedDate: new Date('2023-10-12')},
            { propertyID: 'Property2', reporterID: 'Tenant2', title: 'Water Leakage at Toilet Sink', description: 'Tenant have complained that the sink has been leaking for some time now. This incident require immediate attention as this mean additional water bill incurred on the tenant',
                status: "Resolved", reportedDate: new Date('2023-10-11'), resolvedDate: new Date('2023-10-13')},
            { propertyID: 'Property3', reporterID: 'Tenant3', title: 'Fan Malfunction. Not Working', description: 'Tenant have complained that the Fan is not working and it is very hot and humid to stay in given the hot and humid whether this season. Recommended to replace ASAP',
                status: "Resolved", reportedDate: new Date('2023-10-12'), resolvedDate: new Date('2023-10-14')},
            { propertyID: 'Property4', reporterID: 'Tenant4', title: 'Water Leakage at Toilet Sink', description: 'Tenant have complained that the sink has been leaking for some time now. This incident require immediate attention as this mean additional water bill incurred on the tenant',
                status: "Resolved", reportedDate: new Date('2023-10-13'), resolvedDate: new Date('2023-10-15')},
            { propertyID: 'Property5', reporterID: 'Tenant5', title: 'Fan Malfunction. Not Working', description: 'Tenant have complained that the Fan is not working and it is very hot and humid to stay in given the hot and humid whether this season. Recommended to replace ASAP',
                status: "Resolved", reportedDate: new Date('2023-10-14'), resolvedDate: new Date('2023-10-16')},
            { propertyID: 'Property6', reporterID: 'Tenant6', title: 'Aircon Malfunction. Not Cold', description: 'Tenant have complained that the aircon is no longer old. Servicing may be required for the unit as it may have been so time since it was last serviced',
                status: "Resolved", reportedDate: new Date('2023-10-15'), resolvedDate: new Date('2023-10-17')},
            { propertyID: 'Property7', reporterID: 'Tenant7', title: 'Other Noisy Tenants', description: 'Tenant have complaied that other Tenant is making noisy throughout the night and it is affecting his ability to sleep at night. Need to go talk to other Tenants to reolsve this issue.',
                status: "Resolved", reportedDate: new Date('2023-10-16'), resolvedDate: new Date('2023-10-18')},
            { propertyID: 'Property8', reporterID: 'Landlord8', title: 'Tenant making the place dirty', description: 'Landlord have complained that the Tenant is not doing their part in ensuring the cleaniess of the unit. Unit is very dirty and there is no basic cleaning done by the Tenant',
                status: "Resolved", reportedDate: new Date('2023-10-17'), resolvedDate: new Date('2023-10-19')},
            { propertyID: 'Property9', reporterID: 'Tenant9', title: 'Aircon Malfunction. Not Cold', description: 'Tenant have complained that the aircon is no longer old. Servicing may be required for the unit as it may have been so time since it was last serviced',
                status: "Resolving", reportedDate: new Date('2023-10-18'), resolvedDate: ''},
            { propertyID: 'Property10', reporterID: 'Tenant10', title: 'Aircon Malfunction. Not Cold', description: 'enant have complained that the aircon is no longer old. Servicing may be required for the unit as it may have been so time since it was last serviced',
                status: "Resolving", reportedDate: new Date('2023-10-19'), resolvedDate: ''},
            { propertyID: 'Property1', reporterID: 'Tenant1', title: 'Water Leakage at Toilet Sink', description: 'Tenant have complained that the sink has been leaking for some time now. This incident require immediate attention as this mean additional water bill incurred on the tenant',
                status: "Resolving", reportedDate: new Date('2023-10-20'), resolvedDate: ''},
            { propertyID: 'Property2', reporterID: 'Tenant2', title: 'Other Noisy Tenants', description: 'Tenant have complaied that other Tenant is making noisy throughout the night and it is affecting his ability to sleep at night. Need to go talk to other Tenants to reolsve this issue.',
                status: "Resolving", reportedDate: new Date('2023-10-21'), resolvedDate: ''},
            { propertyID: 'Property3', reporterID: 'Landlord3', title: 'Tenant making the place dirty', description: 'Landlord have complained that the Tenant is not doing their part in ensuring the cleaniess of the unit. Unit is very dirty and there is no basic cleaning done by the Tenant',
                status: "Not Resolved", reportedDate: new Date('2023-10-22'), resolvedDate: ''},
            { propertyID: 'Property4', reporterID: 'Tenant4', title: 'Aircon Malfunction. Not Cold', description: 'Tenant have complained that the aircon is no longer old. Servicing may be required for the unit as it may have been so time since it was last serviced',
                status: "Not Resolved", reportedDate: new Date('2023-10-23'), resolvedDate: ''},
            { propertyID: 'Property5', reporterID: 'Tenant5', title: 'Water Leakage at Toilet Sink', description: 'Tenant have complained that the sink has been leaking for some time now. This incident require immediate attention as this mean additional water bill incurred on the tenant',
                status: "Not Resolved", reportedDate: new Date('2023-10-24'), resolvedDate: ''},
            { propertyID: 'Property6', reporterID: 'Tenant6', title: 'Other Noisy Tenants', description: 'Tenant have complaied that other Tenant is making noisy throughout the night and it is affecting his ability to sleep at night. Need to go talk to other Tenants to reolsve this issue.',
                status: "Not Resolved", reportedDate: new Date('2023-10-25'), resolvedDate: ''},
            { propertyID: 'Property7', reporterID: 'Tenant7', title: 'Tenant making the place dirty', description: 'Landlord have complained that the Tenant is not doing their part in ensuring the cleaniess of the unit. Unit is very dirty and there is no basic cleaning done by the Tenant',
                status: "Not Resolved", reportedDate: new Date('2023-10-26'), resolvedDate: ''},
        ]
        
        DataList.forEach(async (Data, index) => {
            const documentID = `Incident${index + 1}`;
    
            const docRef = doc(userCollection, documentID);
            const reportDataTimeStamp = Timestamp.fromDate(Data.reportedDate);
            const resolveDataTimeStamp = Timestamp.fromDate(Data.reportedDate);
    
            Data.reportedDate = reportDataTimeStamp;
            Data.resolvedDate = resolveDataTimeStamp;
    
            // Data.leasesID = [];

            try {
                await setDoc(docRef, Data);
            } catch (error) {
                console.error("Error", error);
            }
        }
            
    
        )      
      }

    // CREATE DATA FOR PROPERTY //
    function generatePropertyData() { 

        const Document = 'Property'        
        const dbUser = doc(db, "Users", user.email);
        const userCollection = collection(dbUser, Document);
    
        const DataList = [
            { propertyName: 'Suntec Tower Two Office Rental', propertyAddress: '9 Temasek Boulevard 29-02A Suntec Tower Two', landlordID: 'Landlord1', leasesID: ['Lease1', 'Lease11'],
                picture: "images/Property1.jpg"},
            { propertyName: 'Thomson Road 5Room HDB', propertyAddress: 'BLK 1 THOMSON ROAD#03-350E', landlordID: 'Landlord2', leasesID: ['Lease2', 'Lease12'],
                picture: "images/Property2.jpg"},
            { propertyName: 'Kings Road 3 Room HDB', propertyAddress: '151G Kings Rd #20-28', landlordID: 'Landlord3', leasesID: ['Lease3', 'Lease13'],
                picture: "images/Property3.jpg"},
            { propertyName: 'Ubi Condo 4 Room', propertyAddress: '3021 Ubi Ave 2 #03-191', landlordID: 'Landlord4', leasesID: ['Lease4', 'Lease14'],
                picture: "images/Property4.jpg"},
            { propertyName: 'Robinson Road 4 Room HDB', propertyAddress: '112 ROBINSON ROAD 12-00', landlordID: 'Landlord5', leasesID: ['Lease5', 'Lease15'],
                picture: "images/Property5.jpg"},
            { propertyName: 'Potong Pasir 4 Room HDB', propertyAddress: '148 Potong Pasir Ave 1 #01-37', landlordID: 'Landlord6', leasesID: ['Lease6', 'Lease16'],
                picture: "images/Property6.jpg"},
            { propertyName: 'Anson Road Executive Condo', propertyAddress: '10 Anson Rd #30-11', landlordID: 'Landlord7', leasesID: ['Lease7', 'Lease17'],
                picture: "images/Property7.jpg"},
            { propertyName: 'Balestier Road Duplex', propertyAddress: '238 BALESTIER ROAD', landlordID: 'Landlord8', leasesID: ['Lease8', 'Lease18'],
                picture: "images/Property8.jpg"},
            { propertyName: 'Alexandra Road 4 Room HDB', propertyAddress: '370 ALEXANDRA ROAD, #B1-20-29', landlordID: 'Landlord9', leasesID: ['Lease9', 'Lease19'],
                picture: "images/Property9.jpg"},
            { propertyName: 'Joo Chiat GCB', propertyAddress: '214 Joo Chiat Rd', landlordID: 'Landlord10', leasesID: ['Lease10', 'Lease20'],
                picture: "images/Property10.jpg"},
            { propertyName: 'Serangoon North 3 ROOOM HDB', propertyAddress: 'BLK 107 SERANGOON NORTH AVENUE 1#01-675', landlordID: 'Landlord11', leasesID: ['Lease21'],
                picture: "images/Property11.jpg"},
            { propertyName: 'Lau Pat Sat Unit Rental', propertyAddress: '18 Raffles Quay #01-68/69/70 Lau Pa Sat', landlordID: 'Landlord12', leasesID: ['Lease22'],
                picture: "images/Property12.jpg"}

        ]
        
        DataList.forEach(async (Data, index) => {
            const documentID = `Property${index + 1}`;
    
            const docRef = doc(userCollection, documentID);

            try {
                await setDoc(docRef, Data);
            } catch (error) {
                console.error("Error", error);
            }
        }
            
    
        )      
      }
    
      // CREATE DATA FOR PROPERTY //
      function generateLeaseData() { 

        const Document = 'Lease'        
        const dbUser = doc(db, "Users", user.email);
        const userCollection = collection(dbUser, Document);
    
        const DataList = [
            { tenantID: 'Tenant1', propertyID: 'Property1', landlordID: 'Landlord1',  startDate: new Date('2022-11-20'), endDate: new Date('2023-11-20'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 25th of the Month', leaseDocument: 'images/Document1.pdf', 
                    paymentHistory: [{tenantName: 'Lim Jun Ying', rate: '$13000', month: 'Dec', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$13000', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$13000', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$13000', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$13000', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$13000', month: 'May', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$13000', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$13000', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$13000', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$13000', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$13000', month: 'Nov', status: 'Pending'}]},
            { tenantID: 'Tenant2', propertyID: 'Property2', landlordID: 'Landlord2',  startDate: new Date('2022-12-15'), endDate: new Date('2023-12-15'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 15th of the Month', leaseDocument: 'images/Document2.pdf', 
                    paymentHistory: [{tenantName: 'Hui Rong', rate: '$4800', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$4800', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$4800', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$4800', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$4800', month: 'May', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$4800', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$4800', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$4800', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$4800', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$4800', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$4800', month: 'Nov', status: 'Pending'}]},
            { tenantID: 'Tenant3', propertyID: 'Property3', landlordID: 'Landlord3',  startDate: new Date('2023-08-01'), endDate: new Date('2024-08-01'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 25th of the Month', leaseDocument: 'images/Document3.pdf', 
                    paymentHistory: [{tenantName: 'Sarah Han', rate: '$2600', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$2600', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$2600', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$2600', month: 'Nov', status: 'Paid'},]},
            { tenantID: 'Tenant4', propertyID: 'Property4', landlordID: 'Landlord4',  startDate: new Date('2022-11-01'), endDate: new Date('2023-10-30'),
                leaseTenure: '1 Year', collectionMethod: 'Bank Transfer', rentDueDate: 'Every 1st of the Month', leaseDocument: 'images/Document4.pdf', 
                    paymentHistory: [{tenantName: 'Wei Han', rate: '$6000', month: 'Nov', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$6000', month: 'Dec', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$6000', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$6000', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$6000', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$6000', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$6000', month: 'May', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$6000', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$6000', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$6000', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$6000', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$6000', month: 'Oct', status: 'Overdue'},]},
            { tenantID: 'Tenant5', propertyID: 'Property5', landlordID: 'Landlord5',  startDate: new Date('2023-06-01'), endDate: new Date('2024-05-30'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 1st of the Month', leaseDocument: 'images/Document5.pdf', 
                    paymentHistory: [{tenantName: 'Tyler Ong', rate: '$4900', month: 'Jun', status: 'Paid'},
                                            {tenantName: 'Tyler Ong', rate: '$4900', month: 'Jul', status: 'Paid'},
                                            {tenantName: 'Tyler Ong', rate: '$4900', month: 'Aug', status: 'Paid'},
                                            {tenantName: 'Tyler Ong', rate: '$4900', month: 'Sep', status: 'Paid'},
                                            {tenantName: 'Tyler Ong', rate: '$4900', month: 'Oct', status: 'Paid'},
                                            {tenantName: 'Tyler Ong', rate: '$4900', month: 'Nov', status: 'Overdue'}]},
            { tenantID: 'Tenant6', propertyID: 'Property6', landlordID: 'Landlord6',  startDate: new Date('2023-01-01'), endDate: new Date('2023-12-30'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 25th of the Month', leaseDocument: 'images/Document6.pdf', 
                    paymentHistory: [{tenantName: 'Christopher', rate: '$3800', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$3800', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$3800', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$3800', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$3800', month: 'May', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$3800', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$3800', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$3800', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$3800', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$3800', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$3800', month: 'Nov', status: 'Overdue'}]},
            { tenantID: 'Tenant7', propertyID: 'Property7', landlordID: 'Landlord7',  startDate: new Date('2022-11-30'), endDate: new Date('2023-12-01'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 1st of the Month', leaseDocument: 'images/Document7.pdf', 
                    paymentHistory: [{tenantName: 'Angela Lim', rate: '$7000', month: 'Dec', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$7000', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$7000', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$7000', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$7000', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$7000', month: 'May', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$7000', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$7000', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$7000', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$7000', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$7000', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$7000', month: 'Nov', status: 'Pending'}]},
            { tenantID: 'Tenant8', propertyID: 'Property8', landlordID: 'Landlord8',  startDate: new Date('2022-12-30'), endDate: new Date('2024-01-01'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 30th of the Month', leaseDocument: 'images/Document8.pdf', 
                    paymentHistory: [{tenantName: 'Rachel Aw', rate: '$16000', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Rachel Aw', rate: '$16000', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Rachel Aw', rate: '$16000', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Rachel Aw', rate: '$16000', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Rachel Aw', rate: '$16000', month: 'May', status: 'Paid'},
                                        {tenantName: 'Rachel Aw', rate: '$16000', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Rachel Aw', rate: '$16000', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Rachel Aw', rate: '$16000', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Rachel Aw', rate: '$16000', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Rachel Aw', rate: '$16000', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Rachel Aw', rate: '$16000', month: 'Nov', status: 'Paid'}]},
            { tenantID: 'Tenant9', propertyID: 'Property9', landlordID: 'Landlord9',  startDate: new Date('2023-06-01'), endDate: new Date('2024-05-30'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 25th of the Month', leaseDocument: 'images/Document9.pdf', 
                    paymentHistory: [{tenantName: 'Germaine Ow', rate: '$3600', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Germaine Ow', rate: '$3600', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Germaine Ow', rate: '$3600', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Germaine Ow', rate: '$3600', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Germaine Ow', rate: '$3600', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Germaine Ow', rate: '$3600', month: 'Nov', status: 'Pending'}]},
            { tenantID: 'Tenant10', propertyID: 'Property10', landlordID: 'Landlord10',  startDate: new Date('2022-11-30'), endDate: new Date('2023-11-30'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 1st of the Month', leaseDocument: 'images/Document10.pdf', 
                    paymentHistory: [{tenantName: 'Muhamand Ali', rate: '$25000', month: 'Dec', status: 'Paid'},
                                        {tenantName: 'Muhamand Ali', rate: '$25000', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Muhamand Ali', rate: '$25000', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Muhamand Ali', rate: '$25000', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Muhamand Ali', rate: '$25000', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Muhamand Ali', rate: '$25000', month: 'May', status: 'Paid'},
                                        {tenantName: 'Muhamand Ali', rate: '$25000', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Muhamand Ali', rate: '$25000', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Muhamand Ali', rate: '$25000', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Muhamand Ali', rate: '$25000', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Muhamand Ali', rate: '$25000', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Muhamand Ali', rate: '$25000', month: 'Nov', status: 'Paid'}]},
            { tenantID: 'Tenant11', propertyID: 'Property1', landlordID: 'Landlord1',  startDate: new Date('2021-12-15'), endDate: new Date('2022-12-15'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 25th of the Month', leaseDocument: 'images/Document11.pdf', 
                    paymentHistory: [{tenantName: 'Francis Kho', rate: '$11500', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Francis Kho', rate: '$11500', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Francis Kho', rate: '$11500', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Francis Kho', rate: '$11500', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Francis Kho', rate: '$11500', month: 'May', status: 'Paid'},
                                        {tenantName: 'Francis Kho', rate: '$11500', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Francis Kho', rate: '$11500', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Francis Kho', rate: '$11500', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Francis Kho', rate: '$11500', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Francis Kho', rate: '$11500', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Francis Kho', rate: '$11500', month: 'Nov', status: 'Paid'},
                                        {tenantName: 'Francis Kho', rate: '$11500', month: 'Dec', status: 'Paid'}]},
            { tenantID: 'Tenant12', propertyID: 'Property2', landlordID: 'Landlord2',  startDate: new Date('2021-12-14'), endDate: new Date('2022-12-14'),
                leaseTenure: '1 Year', collectionMethod: 'Bank Transfer', rentDueDate: 'Every 15th of the Month', leaseDocument: 'images/Document12.pdf', 
                    paymentHistory: [{tenantName: 'Jesscia Specter', rate: '$4500', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Jesscia Specter', rate: '$4500', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Jesscia Specter', rate: '$4500', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Jesscia Specter', rate: '$4500', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Jesscia Specter', rate: '$4500', month: 'May', status: 'Paid'},
                                        {tenantName: 'Jesscia Specter', rate: '$4500', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Jesscia Specter', rate: '$4500', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Jesscia Specter', rate: '$4500', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Jesscia Specter', rate: '$4500', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Jesscia Specter', rate: '$4500', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Jesscia Specter', rate: '$4500', month: 'Nov', status: 'Paid'},
                                        {tenantName: 'Jesscia Specter', rate: '$4500', month: 'Dec', status: 'Paid'}]},
            { tenantID: 'Tenant13', propertyID: 'Property3', landlordID: 'Landlord3',  startDate: new Date('2022-08-01'), endDate: new Date('2023-07-30'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 1st of the Month', leaseDocument: 'images/Document13.pdf', 
                    paymentHistory: [{tenantName: 'Mike Ross', rate: '$2300', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Mike Ross', rate: '$2300', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Mike Ross', rate: '$2300', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Mike Ross', rate: '$2300', month: 'Nov', status: 'Paid'},
                                        {tenantName: 'Mike Ross', rate: '$2300', month: 'Dec', status: 'Paid'},
                                        {tenantName: 'Mike Ross', rate: '$2300', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Mike Ross', rate: '$2300', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Mike Ross', rate: '$2300', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Mike Ross', rate: '$2300', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Mike Ross', rate: '$2300', month: 'May', status: 'Paid'},
                                        {tenantName: 'Mike Ross', rate: '$2300', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Mike Ross', rate: '$2300', month: 'July', status: 'Paid'}]},
            { tenantID: 'Tenant14', propertyID: 'Property4', landlordID: 'Landlord4',  startDate: new Date('2021-11-01'), endDate: new Date('2022-10-30'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 1st of the Month', leaseDocument: 'images/Document14.pdf', 
                    paymentHistory: [{tenantName: 'Harvey Spector', rate: '$5200', month: 'Nov', status: 'Paid'},
                                        {tenantName: 'Harvey Spector', rate: '$5200', month: 'Dec', status: 'Paid'},
                                        {tenantName: 'Harvey Spector', rate: '$5200', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Harvey Spector', rate: '$5200', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Harvey Spector', rate: '$5200', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Harvey Spector', rate: '$5200', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Harvey Spector', rate: '$5200', month: 'May', status: 'Paid'},
                                        {tenantName: 'Harvey Spector', rate: '$5200', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Harvey Spector', rate: '$5200', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Harvey Spector', rate: '$5200', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Harvey Spector', rate: '$5200', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Harvey Spector', rate: '$5200', month: 'Oct', status: 'Paid'}]},
            { tenantID: 'Tenant1', propertyID: 'Property5', landlordID: 'Landlord5',  startDate: new Date('2022-06-01'), endDate: new Date('2023-05-30'),
                leaseTenure: '1 Year', collectionMethod: 'Cash', rentDueDate: 'Every 1st of the Month', leaseDocument: 'images/Document15.pdf', 
                    paymentHistory: [{tenantName: 'Lim Jun Ying', rate: '$4200', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$4200', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$4200', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$4200', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$4200', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$4200', month: 'Nov', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$4200', month: 'Dec', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$4200', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$4200', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$4200', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$4200', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Lim Jun Ying', rate: '$4200', month: 'May', status: 'Paid'}]},
            { tenantID: 'Tenant2', propertyID: 'Property6', landlordID: 'Landlord6',  startDate: new Date('2022-01-01'), endDate: new Date('2022-12-30'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 1st of the Month', leaseDocument: 'images/Document16.pdf', 
                    paymentHistory: [{tenantName: 'Hui Rong', rate: '$3500', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$3500', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$3500', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$3500', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$3500', month: 'May', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$3500', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$3500', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$3500', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$3500', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$3500', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$3500', month: 'Nov', status: 'Paid'},
                                        {tenantName: 'Hui Rong', rate: '$3500', month: 'Dec', status: 'Paid'}]},
            { tenantID: 'Tenant3', propertyID: 'Property7', landlordID: 'Landlord7',  startDate: new Date('2021-11-30'), endDate: new Date('2022-12-01'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 1st of the Month', leaseDocument: 'images/Document17.pdf', 
                    paymentHistory: [{tenantName: 'Sarah Han', rate: '$5800', month: 'Dec', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$5800', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$5800', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$5800', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$5800', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$5800', month: 'May', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$5800', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$5800', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$5800', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$5800', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$5800', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Sarah Han', rate: '$5800', month: 'Nov', status: 'Paid'}]},
            { tenantID: 'Tenant4', propertyID: 'Property8', landlordID: 'Landlord8',  startDate: new Date('2021-12-30'), endDate: new Date('2023-01-01'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 30th of the Month', leaseDocument: 'images/Document18.pdf', 
                    paymentHistory: [{tenantName: 'Wei Han', rate: '$13000', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$13000', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$13000', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$13000', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$13000', month: 'May', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$13000', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$13000', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$13000', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$13000', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$13000', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$13000', month: 'Nov', status: 'Paid'},
                                        {tenantName: 'Wei Han', rate: '$13000', month: 'Dec', status: 'Paid'}]},
            { tenantID: 'Tenant5', propertyID: 'Property9', landlordID: 'Landlord9',  startDate: new Date('2022-06-01'), endDate: new Date('2023-05-30'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 25th of the Month', leaseDocument: 'images/Document19.pdf', 
                    paymentHistory: [{tenantName: 'Tyler Ong', rate: '$3200', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Tyler Ong', rate: '$3200', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Tyler Ong', rate: '$3200', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Tyler Ong', rate: '$3200', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Tyler Ong', rate: '$3200', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Tyler Ong', rate: '$3200', month: 'Nov', status: 'Paid'},
                                        {tenantName: 'Tyler Ong', rate: '$3200', month: 'Dec', status: 'Paid'},
                                        {tenantName: 'Tyler Ong', rate: '$3200', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Tyler Ong', rate: '$3200', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Tyler Ong', rate: '$3200', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Tyler Ong', rate: '$3200', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Tyler Ong', rate: '$3200', month: 'May', status: 'Paid'}]},
            { tenantID: 'Tenant6', propertyID: 'Property10', landlordID: 'Landlord10',  startDate: new Date('2021-11-30'), endDate: new Date('2022-11-30'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 1st of the Month', leaseDocument: 'images/Document20.pdf', 
                    paymentHistory: [{tenantName: 'Christopher', rate: '$22500', month: 'Dec', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$22500', month: 'Jan', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$22500', month: 'Feb', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$22500', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$22500', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$22500', month: 'May', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$22500', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$22500', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$22500', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$22500', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$22500', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Christopher', rate: '$22500', month: 'Nov', status: 'Paid'}]},
            { tenantID: 'Tenant7', propertyID: 'Property11', landlordID: 'Landlord11',  startDate: new Date('2023-03-01'), endDate: new Date('2024-02-30'),
                leaseTenure: '1 Year', collectionMethod: 'Paynow', rentDueDate: 'Every 25th of the Month', leaseDocument: 'images/Document21.pdf', 
                    paymentHistory: [{tenantName: 'Angela Lim', rate: '$2800', month: 'Mar', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$2800', month: 'Apr', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$2800', month: 'May', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$2800', month: 'Jun', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$2800', month: 'Jul', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$2800', month: 'Aug', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$2800', month: 'Sep', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$2800', month: 'Oct', status: 'Paid'},
                                        {tenantName: 'Angela Lim', rate: '$2800', month: 'Nov', status: 'Paid'},]},
            { tenantID: 'Tenant8', propertyID: 'Property12', landlordID: 'Landlord12',  startDate: new Date('2022-01-01'), endDate: new Date('2024-12-30'),
                leaseTenure: '2 Years', collectionMethod: 'Paynow', rentDueDate: 'Every 25th of the Month', leaseDocument: 'images/Document22.pdf', 
                            paymentHistory: [{tenantName: 'Rachel Aw', rate: '$10000', month: 'Jan', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Feb', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Mar', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Apr', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'May', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Jun', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Jul', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Aug', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Sep', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Oct', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Nov', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Dec', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Jan', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Feb', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Mar', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Apr', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'May', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Jun', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Jul', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Aug', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Sep', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Oct', status: 'Paid'},
                                                {tenantName: 'Rachel Aw', rate: '$10000', month: 'Nov', status: 'Paid'}]},
        ]
        
        DataList.forEach(async (Data, index) => {
            const documentID = `Lease${index + 1}`;
    
            const docRef = doc(userCollection, documentID);
            const startDateTimeStamp = Timestamp.fromDate(Data.startDate);
            const endDateDataTimeStamp = Timestamp.fromDate(Data.endDate);
    
            Data.startDate = startDateTimeStamp;
            Data.endDate = endDateDataTimeStamp;

            try {
                await setDoc(docRef, Data);
            } catch (error) {
                console.error("Error", error);
            }
        }
            
    
        )      
      }
  

}