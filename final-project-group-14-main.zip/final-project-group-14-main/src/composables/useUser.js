import { ref, onMounted } from "vue";
import { useRouter } from "vue-router";
import { getAuth, onAuthStateChanged, signOut } from "firebase/auth";

export default function useUser() {
  const user = ref(null);
  const auth = getAuth();
  const router = useRouter(); // Initialize Vue Router

  // Listen for authentication state changes
  onMounted(() => {
    onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        user.value = firebaseUser;
      } else {
        user.value = null;
      }
    });
  });

  const logout = async () => {
    try {
      await signOut(auth);
      user.value = null;
      router.push("/login"); // Redirect to login page after successful logout
    } catch (error) {
      console.error("Logout error", error);
    }
  };

  // Add more logic here

  return { user, logout };
}
