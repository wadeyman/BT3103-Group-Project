import { createApp } from "vue";
import App from "./App.vue";
import "./global.css";
import { app, db, auth } from "./firebase";
import router from "./router";
import VueChartkick from 'vue-chartkick'
import 'chartkick/chart.js'

const myApp = createApp(App);
myApp.use(router);
myApp.use(VueChartkick)
myApp.mount("#app");
console.log(app, db, auth); // TEMP for lint
