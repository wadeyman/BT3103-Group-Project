<template>
  <div id="app">
    <NavbarSide />
    <!-- got better way of doing this but man use the fastest way  -->
    <div
      :class="{ 'content-no-marginleft': !user, 'content-marginleft': user }"
    >
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
import NavbarSide from "./components/NavbarSide.vue";
import { getAuth, onAuthStateChanged } from "firebase/auth";

export default {
  name: "App",
  components: {
    NavbarSide,
  },
  data() {
    return {
      user: false,
    };
  },

  mounted() {
    const auth = getAuth();

    onAuthStateChanged(auth, (newUser) => {
      if (newUser) {
        this.user = true;
      } else {
        this.user = false;
      }
    });
  },
};
</script>

<style>
#app {
  display: flex;
  flex-direction: column;
}

.content-no-marginleft {
  margin-left: 0px;
  height: fit-content;

}

.content-marginleft {
  flex-grow: 1;
  padding: 20px;
  margin-left: 220px;

}
</style>
