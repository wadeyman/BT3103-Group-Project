<template>
    <div class="grid-container">
        <div class="grid-item">
            <div class="header-wrapper">

                <img class="main-logo" src="@/assets/mainlogo.png">
                <h3> Real Estate Management App </h3>
            </div>
            <h2 style="text-align: center;"> Sign Up </h2>
            <div id="button-wrapper">
                <button class="google-button" type="button" v-on:click="signInWithGoogle">
                    <img class="google-img" src='@/assets/search.png'>Google</button>
            </div>
            <div class="text-wrapper">
                <p> Or</p>
            </div>
            <div class="input-wrapper">
                <label>Name </label>
                <input type="name" v-model="name" placeholder="Your name">
            </div>
            <div class="input-wrapper">
                <label>Email Address </label>
                <input type="email" v-model="email" placeholder="example@email.com">
            </div>
            <div class="input-wrapper">
                <label>Password </label>
                <input type="password" v-model="password" placeholder="••••••••">
            </div>
            <div class="input-wrapper">
                <label>Confirm Password </label>
                <input type="password" v-model="confirmPassword" placeholder="••••••••">
            </div>

            <div id="button-wrapper">
                <button class="primary-button" type="button" v-on:click="signUp">Create Account</button>
            </div>

            <div class="text-wrapper">
                <p style="color: black;"> Already have an account? <a href="/login"> Login </a> </p>
            </div>

        </div>

        <div class='grid-item' style="background-color: #F1F4FA ;">
            <div class="image-wrapper">
                <img src="@/assets/Login.png" class="login-image">
            </div>
        </div>
    </div>
    <MessageModal v-show="isMessageModalVisible" @close="closeMessageModal" :message="modalMessage" />
</template>

<script>
import { getAuth, createUserWithEmailAndPassword, GoogleAuthProvider, signInWithPopup, updateProfile } from 'firebase/auth';
import { doc, setDoc, collection } from "firebase/firestore";
import { db } from "@/firebase.js";
import MessageModal from '@/components/MessageModal.vue';

export default {
    data() {
        return {
            name: '',
            email: '',
            password: '',
            confirmPassword: '',
            modalMessage: '',
            isMessageModalVisible: false
        }
    },
    components: {
        MessageModal,
    },

    methods: {
        showMessageModal(otherMessage) {
            this.isMessageModalVisible = true;
            this.modalMessage = otherMessage;
        },
        closeMessageModal() {
            this.isMessageModalVisible = false;
        },
        async signInWithGoogle() {
            const provider = new GoogleAuthProvider();
            try {
                const auth = getAuth();
                await signInWithPopup(auth, provider);
                const user = getAuth().currentUser;

                // Since each user can only access information on their collection
                // Need to set a new document containing their username
                await setDoc(doc(collection(db, "Users"), user.email), {});
                this.$router.push("/");

            } catch (error) {
                this.showMessageModal("Google Sign-In error" + error);
            }
        },
        async signUp() {

            // Validations for sign up: matching passwords, all fields filled in
            if (this.password !== this.confirmPassword) {
                this.showMessageModal("Passwords do not match, please try again!");
                return;
            }
            if (this.email === '' || this.password === '' || this.name === '') {
                this.showMessageModal("Please fill in all fields!");
                return;
            }
            try {
                const auth = getAuth();
                await createUserWithEmailAndPassword(auth, this.email, this.password);
                this.$router.push('/');

                // Update Firebase Auth account to include displayName
                const user = getAuth().currentUser;
                await updateProfile(user, { displayName: this.name });

                // Since each user can only access information on their collection
                // Need to set a new document containing their username
                await setDoc(doc(collection(db, "Users"), user.email), {});
                location.reload();


            } catch (error) {
                if (error.code === 'auth/email-already-in-use') {
                    this.showMessageModal("This email is already in use. Please login or try anothher email.");
                } else {
                    this.showMessageModal("Error signing up, please try again." + error);
                }
            }
        },
    },
};
</script>


<style scoped>
.login-image {
    width: 450px;
    height: 400px;
    align-content: center;
}

.image-wrapper {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.header-wrapper {
    text-align: center;
    margin-bottom: 50px;
}

.input-wrapper {
    display: flex;
    flex-direction: column;
    width: 100%;
    margin-bottom: 30px;
}

label {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 10px;

}

input {
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 95%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

.text-wrapper {
    text-align: center;
}

.grid-container {
    display: grid;
    grid-template-columns: 10fr 20fr;
    height: fit-content;
    margin: 0px;
    grid-template-rows: auto auto;

}

.grid-item {
    background-color: white;
    padding: 30px 40px;
    height: fit-content;
    min-height: 100vh;
    border-radius: 0px;
    margin: 0px;
}


#button-wrapper {
    display: flex;
    justify-content: center;
    margin-bottom: 10px;
    width: 100%;
}

.primary-button {
    height: 45px;
    width: 99%;
    background-color: var(--primary-accent);
    color: white;
    font-size: 18px;
    border-radius: 10px;
    border: 0px;
    cursor: pointer;
}

.google-button {
    height: 45px;
    width: 33%;
    background-color: #F1F4FA;
    color: black;
    font-size: 18px;
    border-radius: 10px;
    border: 0px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.google-img {
    width: 18px;
    height: 18px;
    margin-right: 10px;
}

.login-signup-input {
    margin: 10px 0;
    padding: 12px;
    width: 80%;
    font-size: 1rem;
    border-radius: 4px;
    border: 1px solid #ccc;
}


.forgot-password-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

.forgot-password-dialog {
    background-color: white;
    padding: 20px;
    border-radius: 5px;
    min-width: 600px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
}

.forgot-password-buttons {
    display: flex;
    justify-content: flex-end;
    gap: 40px;
}
</style>
