<template>
    <div>
        <TenantList />
    </div>
</template>

<script>
import TenantList from "@/components/TenantList.vue"
export default {
    name: 'TenantManagement',
    components: {
        TenantList
    },
}
;
</script>
