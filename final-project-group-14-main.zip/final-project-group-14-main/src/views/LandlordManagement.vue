<template>
    <div>
        <LandlordList />
    </div>
</template>

<script>
import LandlordList from "@/components/LandlordList.vue"
export default {
    name: 'LandlordManagement',
    components: {
        LandlordList
    },
}
;
</script>
