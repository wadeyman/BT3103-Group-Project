<template>
    <div class="grid-container">

        <div class="grid-item">
            <h1 class="main-heading"> Create New Tenant Profile</h1>

            <div class="form-container">
                <form id="userForm">
                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="name">Tenant Name </label>
                            <input v-model.lazy="name" id="name" required="yes" placeholder="Name..." /><br /><br />
                        </div>
                        <div class="input-wrapper">
                            <label for="number">Phone Number:</label>
                            <input v-model.lazy="number" id="ticker1" required="yes"
                                placeholder="Phone Number..." /><br /><br />
                        </div>
                    </div>

                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="email">Email Address</label>
                            <input v-model.lazy="email" id="email" required="yes" placeholder="Email..." /><br /><br />
                        </div>
                        <div class="input-wrapper">
                            <label for="national">Nationalty</label>
                            <input v-model.lazy="national" id="national" required="yes"
                                placeholder="Nationality..." /><br /><br />
                        </div>
                    </div>

                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="email">Date of Birth</label>
                            <input v-model.lazy="dob" id="dob" required="yes" placeholder="YYYY-MM-DD" /><br /><br />
                        </div>
                        <div class="input-wrapper">
                            <label for="gender">Gender</label>
                            <input v-model.lazy="gender" id="gender" required="yes" placeholder="Male/Female" /><br /><br />
                        </div>
                    </div>

                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="active">Number of Active Rental</label>
                            <input v-model.lazy="active" disabled id="active" placeholder="0" /><br /><br />
                        </div>
                        <div class="input-wrapper">
                            <label for="address">Address</label>
                            <input v-model.lazy="address" id="address" required="yes" placeholder="Address.." /><br /><br />
                        </div>
                    </div>

                    <div id="button-wrapper">
                        <button class="primary-button" type="button" v-on:click="saveTenant">Save Record</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <MessageModal v-show="isMessageModalVisible" @close="closeMessageModal" :message="modalMessage" />
</template>

<script>
import { db, auth } from "@/firebase.js";
import { collection, doc, setDoc, Timestamp, getDocs } from 'firebase/firestore'
import MessageModal from '@/components/MessageModal.vue';

export default {

    name: "CreateNewTenant",
    data() {
        return {
            // Data Binding for Input Entered Into Form
            name: '', number: '', email: '', national: '', dob: '', gender: '', active: 0, address: '',
            // Data Binding for Message Modal
            modalMessage: '', isMessageModalVisible: false,
        }
    },
    components: {
        MessageModal,
    },
    methods: {
        // Show Message Modal //
        showMessageModal(otherMessage) {
            this.isMessageModalVisible = true;
            this.modalMessage = otherMessage;
        },
        // Closes Message Modal //
        closeMessageModal() {
            this.isMessageModalVisible = false;
        },
        // Creates New Tenant in Tenant Collection //
        async saveTenant() {
            let allInfoFilled = false;

            // Ensure that all Field are filled in //
            if (this.name === '' || this.number === '' || this.email === '' || this.national === '' || this.dob === '' ||
                this.gender === '' || this.address === '') {
                allInfoFilled = false;
                this.showMessageModal("Please fill in all Information!")
            } else {
                allInfoFilled = true;
            }

            { // Data validation}
                // Validate Date of Birth Format
                const dobRegex = /^(?:(?!0000)[0-9]{4}([-/])(?:(?:0?[1-9]|1[0-2])\1(?:31|30|[12]\d|0?[1-9])|(?:0?[13-9]|1[0-2])\1(?:29|30|[12]\d|0?[1-9])|(?:0?[1-9]|1[0-2])\1(?:2[1-9]|[12]\d|0?[1-9])))$/;
                if (!dobRegex.test(this.dob)) {
                    this.showMessageModal("Please enter a valid date format (YYYY-MM-DD) for Date of Birth!");
                    return;
                }

                const [year, month, day] = this.dob.split('-').map(Number);

                // Check if month is within 1-12
                if (month < 1 || month > 12) {
                    this.showMessageModal("Please enter a valid month (01-12) for Date of Birth!");
                    return;
                }

                // Check if day is within 1-31
                if (day < 1 || day > 31) {
                    this.showMessageModal("Please enter a valid day (01-31) for Date of Birth!");
                    return;
                }

                // Check if day is valid based on calendar month
                const daysInMonth = new Date(year, month, 0).getDate();
                if (day > daysInMonth) {
                    this.showMessageModal(`Please enter a valid day for the month of ${month}!`);
                    return;
                }

                // Check for leap year
                if (month === 2 && day === 29 && !(year % 400 === 0 || (year % 4 === 0 && year % 100 !== 0))) {
                    this.showMessageModal(`${year} is not a leap year! Please enter a valid day for February.`);
                    return;
                }


                // Validate Email Address Format
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(this.email)) {
                    this.showMessageModal("Please enter a valid email address format!");
                    return;
                }

                // Validate Phone Number Format
                const phoneRegex = /^[\d+() ]+$/;
                if (!phoneRegex.test(this.number)) {
                    this.showMessageModal("Please enter a valid phone number format!");
                    return;
                }

                // Validate Gender Input
                const genderRegex = /^(male|female)$/i;
                if (!genderRegex.test(this.gender)) {
                    this.showMessageModal("Please enter a valid gender (Male/Female)!");
                    return;
                }
            }

            // Execute Write Only if all Information is Filled //
            if (allInfoFilled === true) {

                // Routing to Tenant Collection //
                const tenantDocument = 'Tenant';
                const dbUser = doc(db, "Users", auth.currentUser.email);
                const tenantCollectionRef = collection(dbUser, tenantDocument);

                // Prepare Document //
                const allDocs = await getDocs(tenantCollectionRef);
                const count = allDocs.size;

                const tenantID = `Tenant${count + 1}`; // TenantID is the ID of the document //
                const tenantDOBTimestamp = new Date(this.dob);
                const birthDataTimeStamp = Timestamp.fromDate(tenantDOBTimestamp);
                const tenantDocRef = doc(tenantCollectionRef, tenantID);
                const tenantData = {
                    tenantName: this.name,
                    tenantNumber: this.number,
                    tenantEmail: this.email,
                    tenantNationality: this.national,
                    tenantDOB: birthDataTimeStamp,
                    tenantGender: this.gender,
                    tenantAddress: this.address,
                    leaseID: []
                }
                // Writes Data //
                try {
                    await setDoc(tenantDocRef, tenantData);
                    this.showMessageModal("New Tenant Added Successfully!")
                    document.getElementById('userForm').reset()
                } catch (error) {
                    console.log(error);
                }
            }

        }
    }

}
</script>

<style>
.grid-container {
    display: grid;
    grid-template-columns: 500px;
    grid-template-rows: 95vh 95vh;

}

.grid-item {
    background-color: white;
    border-radius: 10px;
    margin: 0px 10px;
    padding: 30px 40px;
    min-width: 500px;
}

.main-heading {
    margin-bottom: 40px;
}

.in-twos {
    display: flex;
    justify-content: space-between;
}

.input-wrapper {
    display: flex;
    flex-direction: column;
    width: 50%;
}

label {
    font-size: 18px;
    font-weight: 500;
    margin-bottom: 15px;

}

input {
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 80%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

#button-wrapper {
    display: flex;
    width: 100%;
}

.primary-button {
    height: 50px;
    width: 240px;
    background-color: var(--primary-accent);
    color: white;
    font-size: 18px;
    border-radius: 10px;
}
</style>