<template>
    <div class="grid-container">
        <div class="grid-item">
        <h1 class="main-heading"> Landlord Information</h1> 

        <div class="form-container">
            <form id="userForm">
            <div class="in-twos">
                <div class="input-wrapper"> 
                    <label for="name">Landlord Name </label>
                    <input v-model="name" :disabled="!openEditing" id="name" required="yes" placeholder="Name..." /><br /><br />
            </div>
                <div class="input-wrapper"> 
                    <label for="number">Phone Number</label>
                    <input v-model="number" :disabled="!openEditing" id="ticker1" required="yes" placeholder="Phone Number..." /><br /><br />
                </div>
            </div>

            <div class="in-twos">
                <div class="input-wrapper">
                    <label for="email">Email Address</label>
                    <input v-model="email" :disabled="!openEditing" id="email" required="yes" placeholder="Email..." /><br /><br />
                </div>
                <div class="input-wrapper">
                    <label for="national">Nationalty</label>
                    <input v-model="national" :disabled="!openEditing" id="national" required="yes" placeholder="Nationality..." /><br /><br />
                </div>
            </div>

            <div class="in-twos">
                <div class="input-wrapper">    
                    <label for="email">Date of Birth</label>
                    <input v-model="dob" :disabled="!openEditing" id="dob" required="yes" placeholder="YYYY-MM-DD" /><br /><br />
                </div>
                <div class="input-wrapper">
                    <label for="gender">Gender</label>
                    <input v-model="gender" :disabled="!openEditing" id="gender" required="yes" placeholder="Male/Female" /><br /><br />
                </div>
            </div>

            <div class="in-twos">
                <div class="input-wrapper">
                    <label for="active">Number of Active Rental</label>
                    <input v-model="noOfProperty" disabled id="active" required="yes" placeholder="Active Rental..." /><br /><br />
                </div>
                <div class="input-wrapper">
                    <label for="address">Address</label>
                    <input v-model="address" :disabled="!openEditing" id="address" required="yes" placeholder="Address.." /><br /><br />
                </div>
            </div>

            <div id="button-wrapper">
                <button class="primary-button" id="editInformation" type="button" v-on:click="editInformation">Edit Information</button>
                <button class="delete-button" type="button" v-on:click="startDelete">Delete Landlord</button>
            </div>
            </form>
        </div>
        </div>

        <div class='grid-item' > 
            <h1 class="main-heading" style="margin-bottom: 0px;"> All Rental Leases</h1> 
            <table id="rental-table">
                <tr>
                <th class='th-align-left'>Property Name <img src="@/assets/ArrowDown.png" alt="Filter"></th>
                <th>Rate <img src="@/assets/ArrowDown.png" alt="Filter"></th>
                <th>Lease Expiry <img src="@/assets/ArrowDown.png" alt="Filter"></th>
                <th>Lease Tenure <img src="@/assets/ArrowDown.png" alt="Filter"></th>
                </tr>
                <tr v-for="(lease) in landlordLeases" :key="lease.id">
                    <td class='td-align-left'>{{ lease.propertyName }}</td>
                    <td>{{ lease.paymentHistory[0].rate}}</td>
                    <td>{{ formatDateMonth(lease.endDate) }}</td>                                               
                    <td>{{ lease.leaseTenure }}</td>
                </tr>
            </table>
        </div>
    </div>

    <DeleteModal v-show="isModalVisible" @close="closeModal" @delete="confirmDelete" :title="title" :description='description' />
    <MessageModal v-show="isMessageModalVisible" @close="closeMessageModal" :message="modalMessage" />

</template>

<script>
import { db, auth} from "@/firebase.js";
import { collection, doc, Timestamp, getDoc, getDocs, query, updateDoc} from 'firebase/firestore'
import DeleteModal from '@/components/DeleteModal.vue';
import MessageModal from '@/components/MessageModal.vue';

export default {
    name: "ViewLandlord", 
    props: {
        landlordID: String,
    },
    data() {
        return {
            // Contains Data of the Landlord //
            landlordData: null,
            // Enable the Input to be edited. Initially set as False, hence user will not be able to edit the data //
            openEditing: false,
            // Data Binding for Landlord Data to Be Displayed Into Form //
            name: '', number: '',  email: '', national: '', dob: '', gender: '', noOfProperty: 0, address: '', landlordLeases: null, 
            // Data Binding for Message Modal and Delete Modal //
            isModalVisible: false, title: '', description: '', modalMessage: '', isMessageModalVisible: false,
        }
    },
    components: {
        DeleteModal,
        MessageModal,
    },

    async mounted() { 
        // Get Landlord Data from Database //
        const dbUser = doc(db, "Users", auth.currentUser.email);
        const landlordDocument = 'Landlord';
        const landlordCollectionRef = collection(dbUser, landlordDocument);
        const landlordDocRef = doc(landlordCollectionRef ,this.landlordID);
        await getDoc(landlordDocRef).then((doc) => {
            this.landlordData = doc.data();
        })

        // Reference to Data //
        this.name = this.landlordData.landlordName; 
        this.number = this.landlordData.landlordNumber;
        this.email = this.landlordData.landlordEmail;
        this.national = this.landlordData.landlordNationality;
        this.dob = this.formatDate(this.landlordData.landlordDOB);
        this.gender = this.landlordData.landlordGender;
        this.address = this.landlordData.landlordAddress;

        // Get All Leases Information //
        const leaseDocument = 'Lease';
        const leaseCollectionRef = collection(dbUser, leaseDocument);

        const qLease = query(leaseCollectionRef);
        const querySnapshotLease = await getDocs(qLease);
        const results = querySnapshotLease.docs
                .map((doc) => {
                    // Include the document ID in the mapped data object //
                    return { id: doc.id, ...doc.data() };
                }) // Filter leases only belonging to the Landlord based on ID //
                .filter((data) => data.landlordID === this.landlordID);

        this.landlordLeases = results;
        let landlordPropertyID = [];
        
        // Each Lease referrence to a PropertyID. Extract all Properties belonging to the Landlord //
        this.landlordLeases.forEach((lease) => {
            landlordPropertyID.push(lease.propertyID);
        })

        // Get All Properties Information //
        const propertyDocument = 'Property';
        const propertyCollectionRef = collection(dbUser, propertyDocument);

        const qProperty = query(propertyCollectionRef);
        const querySnapshotProperty = await getDocs(qProperty);
        const propertyData = querySnapshotProperty.docs
                .map((doc) => {
                    // Include the document ID in the mapped data object //
                    return { id: doc.id, ...doc.data() };
                });

        // Filter out only on Properties that belongs to the Landlord //
        const landlordProperty = propertyData.filter(lease => landlordPropertyID.includes(lease.id));
        
        // Attach Property Name to the Lease //
        const landlordPropertyMap = new Map(landlordProperty.map(property => [property.id, property.propertyName]));

        // Apppend PropertyName to each of the leases //
        this.landlordLeases = this.landlordLeases.map(lease => ({
            ...lease, 
            propertyName: landlordPropertyMap.get(lease.propertyID)
        }))

        // Calculate the Number of Properties // 
        const uniquePropertyID = new Set();
        for (const lease of this.landlordLeases) { 
            uniquePropertyID.add(lease.propertyID)
        }
        this.noOfProperty = uniquePropertyID.size;

        // Calculate the Number of Active Rental
        // const currentTime = new Date(); 
        // this.tenantLeases.forEach((lease) => { 
        //     if (lease.endDate.seconds * 1000> currentTime.getTime()) {
        //         this.active = this.active + 1;
        //     }
        // })

    }, 
    methods: {
        // Show Message Modal //
        showMessageModal(otherMessage) {
            this.isMessageModalVisible = true;
            this.modalMessage = otherMessage;
        },
        // Closes Message Modal //
        closeMessageModal() {
            this.isMessageModalVisible = false;
        },
        // Shows Delete Modal //
        showModal(otherTitle, otherDescription) {
            this.isModalVisible = true;
            this.title = otherTitle;
            this.description = otherDescription;
        },
        // Closes Delete Modal //
        closeModal() {
            this.isModalVisible = false;
        },
        // Delete Not Implemented, but will handle the delete on firebase //
        confirmDelete() { 
            this.closeModal(); 
        },
        // Handles when user clicks on delete button. Popup for comfirmation //
        startDelete() {
            this.showModal("Are you sure you want to delete this Tenant?",
                            "Deleteting this tenant will delete all leases as well");
        },
        // Formats Timestamp to Date Format for Display //
        formatDate(timestamp) {
            const date = new Date(timestamp.seconds * 1000); // Convert timestamp to Date
            const day = date.getDate();
            const month = date.toLocaleString('default', { month: 'long' });
            const year = date.getFullYear();
            return `${year} ${month} ${day}`;
      },
        // Formats Timestamp to Date Format for Display //
        formatDateMonth(timestamp) {
            const date = new Date(timestamp.seconds * 1000); // Convert timestamp to Date
            const month = date.toLocaleString('default', { month: 'long' });
            const year = date.getFullYear();
            return `${month} ${year}`;
      },    
        // Handles the Edit Functionality //
        // When Edit is Active, allow users to update data, and update doc on firebase accordingly //
        editInformation() { 
            const button = document.getElementById('editInformation')
            const currentStatus = button.innerText;

            // Opening Editing //
            if (currentStatus === "Edit Information") {
                button.innerText = "Save Edits";
                this.openEditing = true;
                button.className = "secondary-button";
            } else {
                // Close Editing and Update New Information //
                button.innerText = "Edit Information";
                this.openEditing = false;
                button.className = "primary-button";

                // Initialise Landlord Data //
                const dbUser = doc(db, "Users", auth.currentUser.email);
                const landlordDocument = 'Landlord';
                const landlordCollectionRef = collection(dbUser, landlordDocument);
                const landlordDocRef = doc(landlordCollectionRef ,this.landlordID);
                
                // Converts all Dates into Timestamp //
                const newDate = Timestamp.fromDate(new Date(this.dob));
                this.dob = this.formatDate(newDate);

                // Extract all Data Bindings from the Form to be Update //
                const updatedData = {landlordName: this.name, landlordNumber: this.number, landlordEmail: this.email, 
                                        landlordGender: this.gender, landlordDOB: Timestamp.fromDate(new Date(this.dob)), landlordNationality: this.national, 
                                        landlordAddress: this.address};
                
                // Update Doc with new Data //
                updateDoc(landlordDocRef, updatedData)
                    .then(() => {
                        this.showMessageModal("Landlord Information has been Updated Successfully!")
                    })
                    .catch((error) => {
                        alert("Error editing information: ", error)
                })
            }
        }
    }
}


</script>

<style>
.grid-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: 95vh 95vh;
}

.left-grid-container {
    display: grid;
    grid-template-rows: 52.5vh 42.5vh;
}

.grid-item {
    background-color: white; 
    border-radius: 10px;
    margin: 0px 10px;
    padding: 30px 40px;
}

.main-heading {
    margin-bottom: 40px;
}

.in-twos{
    display: flex;
    justify-content: space-between;
}

.input-wrapper {
    display: flex;
    flex-direction: column;
    width: 50%;
}

label {
    font-size: 18px;
    font-weight: 500;
    margin-bottom: 15px;

}

input { 
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 80%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1); 
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

#button-wrapper {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    width: 100%;
}

.primary-button {
    height: 50px;
    width: 240px;
    background-color: var(--primary-accent);
    color: white; 
    font-size: 18px;
    border-radius: 10px;
    border: 0px;
    cursor: pointer;
}

.secondary-button { 
    height: 50px;
    width: 240px;
    background-color: white;
    color: black; 
    font-size: 18px;
    border-radius: 10px;
    border: 2px var(--primary-accent) solid;
}

.delete-button { 
    height: 50px;
    width: 240px;
    background-color: #CE2F42;
    color: white; 
    font-size: 18px;
    border-radius: 10px;
    border: 0px;
}

#rental-table { 
  width: 100%;
  padding: 10px 0px;
  border-collapse: separate;
  border-spacing: 0 1em;
}

tr { 
    padding-bottom: 30px;
}

th {
  padding: 5px;
  font-size: 18px;
  background-color: white;
  text-align: center;
  color: black;

}

.th-align-left {
  padding: 5px;
  font-size: 18px;
  background-color: white;
  text-align: left;
  color: black;
}

td {
  padding: 5px;
  font-size: 16px;
  background-color: white;
  border-bottom: 1px rgb(177, 177, 177) solid;
  text-align: center;
  padding-bottom: 15px;
  
}

.td-align-left{
  padding: 5px;
  font-size: 16px;
  background-color: white;
  border-bottom: 1px rgb(177, 177, 177) solid;
  text-align: left;
  color: var(--primary-accent);
  padding-bottom: 15px;
}

img { 
    margin-left:5px; 
    cursor:pointer; 
    vertical-align: middle; 
}

.comment-section {
    background-color: #F1F4FA;
    height: 90%;
    width: 95%;
    border-radius: 10px;
    padding-left: 20px;
    padding-right: 20px;
    padding-top: 10px;

}

p { 
    color: rgba(6, 21, 43, 0.6);
}
</style>