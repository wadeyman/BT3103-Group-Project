<template>
    <div class="grid-container">
        <div class="grid-item">
        <h1 class="main-heading"> Incident Information</h1> 

        <div class="form-container">
            <form id="userForm">
            <div class="in-twos">
                <div class="input-wrapper"> 
                    <label for="name">Property Name </label>
                    <input v-model="propertyName" disabled id="name" required="yes" placeholder="Name..." /><br /><br />
            </div>
                <div class="input-wrapper"> 
                    <label for="number">Property Address</label>
                    <input v-model="propertyAddress" disabled id="ticker1" required="yes" placeholder="Phone Number..." /><br /><br />
                </div>
            </div>

            <div class="in-twos">
                <div class="input-wrapper">
                    <label for="email">Reporter Name</label>
                    <input v-model="reporterName" disabled id="email" required="yes" placeholder="Email..." /><br /><br />
                </div>
                <div class="input-wrapper">
                    <label for="incident">Incident Date</label>
                    <input v-model="incidentDate" disabled id="national" required="yes" placeholder="Nationality..." /><br /><br />
                </div>
            </div>
            <div class="in-twos">
                <div class="input-wrapper">
                    <label for="email">Status</label>
                    <input v-model="status" disabled id="email" required="yes" placeholder="Email..." /><br /><br />
                </div>
                <div class="input-wrapper">
                    <label for="incident">Resolved Date</label>
                    <input v-model="resolvedDate" disabled id="national" required="yes" placeholder="Nationality..." /><br /><br />
                </div>
            </div>

            </form>
        </div>
        </div>

        <div class='grid-item'> 
            <h1 class="main-heading" style="margin-bottom: 40px;">Incident Report</h1> 
            <div class="form-container">
                <form id="userFormReport">
                <div class="input-wrapper2" style="margin-bottom: 0px;">    
                    <label for="email">Title</label>
                    <input class="input_wide" v-model="reportTitle" :disabled="!openEditing" id="title" required="yes" placeholder="Title...." /><br /><br />
                </div>

                <div class="input-wrapper2">
                    <label for="gender">Report</label>
                    <textarea class="report" v-model="report" :disabled="!openEditing" id="report" required="yes" placeholder="Report/Description...." /><br /><br />
                </div>
                </form>
                </div>
            <div id="button-wrapper">
                <button class="primary-button" id="editInformation" type="button" v-on:click="markAsResolved">Mark as Resolved</button>
                <button class="secondary-button" type="button" v-on:click="markAsResolving">Mark as Resolving</button>
            </div>
            <div id="button-wrapper">
                <button class="delete-button2" type="button" v-on:click="startDelete">Delete Incident</button>
            </div>
        </div>
    </div>

    <DeleteModal v-show="isModalVisible" @close="closeModal" @delete="confirmDelete" :title="title" :description='description' />
    <MessageModal v-show="isMessageModalVisible" @close="closeMessageModal" :message="modalMessage" />

</template>

<script>
import { db, auth} from "@/firebase.js";
import { collection, doc, Timestamp, getDoc, updateDoc} from 'firebase/firestore'
import DeleteModal from '@/components/DeleteModal.vue';
import MessageModal from '@/components/MessageModal.vue';

export default {
    name: "CreateNewTenant", 
    props: {
        incidentID: String,
    },
    data() {
        return {
            // Contains Data of the Incident //
            incidentData: null, 
            // Enable the Input to be edited. Initially set as False, hence user will not be able to edit the data //
            openEditing: false, 
            // Data Binding for Incident Data to Be Displayed Into Form //
            status: '', resolvedDate: '', propertyData: null, reporterData: null, reporterName: '',
            propertyName: '', propertyAddress: '',  name: '', incidentDate: '', reportTitle: '', report: '', reporterID: '', propertyID: '',
            // Data Binding for Message Modal and Delete Modal //
            title: '', description: '', isModalVisible: false, modalMessage: '', isMessageModalVisible: false,
        }
    },
    components: {
        DeleteModal,
        MessageModal,
    },

    async mounted() { 
        // Get Incident Data from Database //
        const dbUser = doc(db, "Users", auth.currentUser.email);
        const incidentDocument = 'Incident';
        const incidentCollectionRef = collection(dbUser, incidentDocument);
        const incidentDocRef = doc(incidentCollectionRef ,this.incidentID);
        await getDoc(incidentDocRef).then((doc) => {
            this.incidentData = doc.data();
        })

        // Reference to Data //
        this.propertyID = this.incidentData.propertyID; 
        this.reporterID = this.incidentData.reporterID;
        this.reportTitle = this.incidentData.title;
        this.report = this.incidentData.description;
        this.incidentDate = this.formatDate(this.incidentData.reportedDate);
        this.status = this.incidentData.status;

        // Get Property Information //
        const propertyDocument = 'Property';
        const propertyCollectionRef = collection(dbUser, propertyDocument);
        const propertyDocRef = doc(propertyCollectionRef ,this.propertyID);
        await getDoc(propertyDocRef).then((doc) => {
            this.propertyData = doc.data();
        })

        // Reference to Data //
        this.propertyName = this.propertyData.propertyName; 
        this.propertyAddress = this.propertyData.propertyAddress;

        let  reporterDocument; 
        // Get Reporter Data. Need to be able to differentiate between different colleciton because reporter can be Landlord or Tenant //
        if (this.reporterID.includes("Tenant")) {
            reporterDocument = 'Tenant'
        } else { 
            reporterDocument = 'Landlord'
        }

        // Get Reporter Data //
        const reporterCollectionRef = collection(dbUser, reporterDocument);
        const reporterDocRef = doc(reporterCollectionRef ,this.reporterID);
     
        await getDoc(reporterDocRef).then((doc) => {
            this.reporterData = doc.data();
        })

        // Binds Reporter Data //
        if (this.reporterID.includes("Tenant")) {
            this.reporterName = this.reporterData.tenantName;
        } else { 
            this.reporterName = this.reporterData.landlordName;
        }
        
        // Get Status and Resolved Date if any //
        if (this.status === "Resolved") { 
            this.resolvedDate = this.formatDate(this.incidentData.resolvedDate);
        } else if (this.status === "Resolving") { 
            this.resolvedDate = "Not Resolved Yet"
        } else { 
            this.resolvedDate = "Not Resolved Yet";
        }

    }, 
    methods: {
        // Show Message Modal //
        showMessageModal(otherMessage) {
            this.isMessageModalVisible = true;
            this.modalMessage = otherMessage;
        },
        // Closes Message Modal //
        closeMessageModal() {
            this.isMessageModalVisible = false;
        },
        // Shows Delete Modal //
        showModal(otherTitle, otherDescription) {
            this.isModalVisible = true;
            this.title = otherTitle;
            this.description = otherDescription;
        },
        // Closes Delete Modal //
        closeModal() {
            this.isModalVisible = false;
        },
        // Delete Not Implemented, but will handle the delete on firebase //
        confirmDelete() { 
            this.closeModal(); 
        },
        // Handles when user clicks on delete button. Popup for comfirmation //
        startDelete() {
            this.showModal("Are you sure you want to delete this Incident?",
                            "Deleteting this Incident will delete all associated Data");
        },
        // Formats Timestamp to Date Format for Display //
        formatDate(timestamp) {
            const date = new Date(timestamp.seconds * 1000); // Convert timestamp to Date
            const day = date.getDate();
            const month = date.toLocaleString('default', { month: 'long' });
            const year = date.getFullYear();
            return `${year} ${month} ${day}`;
      },
        // Formats Timestamp to Date Format for Display //
        formatDateMonth(timestamp) {
            const date = new Date(timestamp.seconds * 1000); // Convert timestamp to Date
            const month = date.toLocaleString('default', { month: 'long' });
            const year = date.getFullYear();
            return `${month} ${year}`;
      },    
        // Handles When the User marks the Incident As Resolved //
        markAsResolved() { 
            // Get this Incident Data //
            const dbUser = doc(db, "Users", auth.currentUser.email);
            const incidentDocument = 'Incident';
            const incidentCollectionRef = collection(dbUser, incidentDocument);
            const incidentDocRef = doc(incidentCollectionRef ,this.incidentID);
            let updatedData = this.incidentData; 

            // Update Status to Resolved //
            updatedData.status = "Resolved";
            updatedData.resolvedDate = Timestamp.fromDate(new Date());
            
            // Updates Status and Update Doc //
            updateDoc(incidentDocRef, updatedData)
                .then(() => {
                    this.showMessageModal("Incident has been Marked as Resolved Successfully!")
                })
                .catch((error) => {
                    alert("Error editing information: ", error)
            })

            // Changes UI to reflect new changes in status //
            this.incidentData = updatedData; 
            this.status = "Resolved";
            this.resolvedDate = this.formatDate(Timestamp.fromDate(new Date()));
        },
        // Handles When the User marks the Incident As Resolving //
        markAsResolving() { 
            // Get this Incident Data //
            const dbUser = doc(db, "Users", auth.currentUser.email);
            const incidentDocument = 'Incident';
            const incidentCollectionRef = collection(dbUser, incidentDocument);
            const incidentDocRef = doc(incidentCollectionRef ,this.incidentID);
            let updatedData = this.incidentData; 
            
            // Update Status to Resolved //
            updatedData.status = "Resolving";
            updatedData.resolvedDate = '';

            // Updates Status and Update Doc //
            updateDoc(incidentDocRef, updatedData)
                .then(() => {
                    this.showMessageModal("Incident has been Marked as Resolving Successfully!")
                })
                .catch((error) => {
                    alert("Error editing information: ", error)
            })
            // Changes UI to reflect new changes in status //
            this.incidentData = updatedData; 
            this.status = "Resolving";
            this.resolvedDate = 'Not Resolved Yet';
        }
    }
}


</script>

<style>
.grid-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: 95vh 95vh;
}

.left-grid-container {
    display: grid;
    grid-template-rows: 52.5vh 42.5vh;
}

.grid-item {
    background-color: white; 
    border-radius: 10px;
    margin: 0px 10px;
    padding: 30px 40px;
    height: fit-content;
    min-height: 95vh;
}

.main-heading {
    margin-bottom: 40px;
}

.in-twos{
    display: flex;
    justify-content: space-between;
}

.input-wrapper {
    display: flex;
    flex-direction: column;
    width: 50%;
}

label {
    font-size: 18px;
    font-weight: 500;
    margin-bottom: 15px;

}

input { 
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 80%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1); 
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

textarea { 
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 80%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1); 
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
    resize: none;
    font-size: 16px; 
    padding-top: 25px;
}

#button-wrapper {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    width: 100%;
}

.primary-button {
    height: 50px;
    width: 240px;
    background-color: var(--primary-accent);
    color: white; 
    font-size: 18px;
    border-radius: 10px;
    border: 0px;
    cursor: pointer;
}

.secondary-button { 
    height: 50px;
    width: 240px;
    background-color: white;
    color: black; 
    font-size: 18px;
    border-radius: 10px;
    border: 2px var(--primary-accent) solid;
}

.delete-button { 
    height: 50px;
    width: 240px;
    background-color: #CE2F42;
    color: white; 
    font-size: 18px;
    border-radius: 10px;
    border: 0px;
}

.delete-button2 { 
    height: 50px;
    width: 100%;
    background-color: #CE2F42;
    color: white; 
    font-size: 18px;
    border-radius: 10px;
    border: 0px;
}

#rental-table { 
  width: 100%;
  padding: 10px 0px;
  border-collapse: separate;
  border-spacing: 0 1em;
}

tr { 
    padding-bottom: 30px;
}

.report {
    width: 95%;
    height: 250px;
    white-space: normal;
}
th {
  padding: 5px;
  font-size: 18px;
  background-color: white;
  text-align: center;
  color: black;

}

.th-align-left {
  padding: 5px;
  font-size: 18px;
  background-color: white;
  text-align: left;
  color: black;
}

td {
  padding: 5px;
  font-size: 16px;
  background-color: white;
  border-bottom: 1px rgb(177, 177, 177) solid;
  text-align: center;
  padding-bottom: 15px;
  
}

.td-align-left{
  padding: 5px;
  font-size: 16px;
  background-color: white;
  border-bottom: 1px rgb(177, 177, 177) solid;
  text-align: left;
  color: var(--primary-accent);
  padding-bottom: 15px;
}

img { 
    margin-left:5px; 
    cursor:pointer; 
    vertical-align: middle; 
}

.comment-section {
    background-color: #F1F4FA;
    height: 90%;
    width: 95%;
    border-radius: 10px;
    padding-left: 20px;
    padding-right: 20px;
    padding-top: 10px;
}

p { 
    color: rgba(6, 21, 43, 0.6);
}
</style>