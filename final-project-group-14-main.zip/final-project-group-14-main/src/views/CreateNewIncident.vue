<template>
    <div class="grid-container">

        <div class="grid-item">
            <h1 class="main-heading"> New Incident</h1>

            <div class="form-container">
                <form id="userForm">
                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="name">Property Name </label>

                            <input class="search" v-model="propertyName" id="name" required="yes"
                                placeholder="Search Property Name..." />

                            <div class="dropdown" v-show="showDropdown">
                                <div class="option" v-for="property in searchResultsProperty" :key="property.id"
                                    @click="selectProperty(property)">
                                    {{ property.propertyName }}
                                </div>


                            </div>
                        </div>
                        <div class="input-wrapper">
                            <label for="number">Property Address:</label>
                            <input v-model.lazy="propertyAddress" disabled id="ticker1" required="yes"
                                placeholder="Property Address..." /><br /><br />
                        </div>
                    </div>

                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="email">Reporter Name</label>
                            <input class="search" v-model="reporterName" id="email" required="yes"
                                placeholder="Search Landlord/Tenant Name..." />
                            <div class="dropdown" v-show="showDropdownReporter">
                                <div class="option" v-for="reporter in searchResultsReporter" :key="reporter.id"
                                    @click="selectReporter(reporter)">
                                    {{ getReporterName(reporter) }}
                                </div>
                            </div>
                        </div>
                        <div class="input-wrapper">
                            <label for="national">Incident Date</label>
                            <input v-model.lazy="incidentDate" id="national" required="yes"
                                placeholder="YYYY-MM-DD" /><br /><br />
                        </div>
                    </div>


                    <div id="button-wrapper">
                        <button class="primary-button" type="button" v-on:click="saveIncident">Save Record</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="grid-item">
            <h1 class="main-heading"> Incident Report</h1>

            <div class="form-container">
                <form id="userFormReport">

                    <div class="input-wrapper2">
                        <label for="email">Title</label>
                        <input class="input_wide" v-model.lazy="title" id="title" required="yes"
                            placeholder="Title...." /><br /><br />
                    </div>
                    <div class="input-wrapper2">
                        <label for="gender">Report</label>
                        <textarea class="report" v-model.lazy="report" id="report" required="yes"
                            placeholder="Report/Description...." /><br /><br />
                    </div>

                </form>
            </div>
        </div>

    </div>

    <MessageModal v-show="isMessageModalVisible" @close="closeMessageModal" :message="modalMessage" />
</template>

<script>
import { db, auth } from "@/firebase.js";
import { collection, doc, setDoc, Timestamp, getDocs, query } from 'firebase/firestore'
import MessageModal from '@/components/MessageModal.vue';

export default {

    name: "CreateNewIncident",
    data() {
        return {
            // Data Binding for Input Entered Into Form //
            propertyName: '', propertyAddress: '', reporterName: '', incidentDate: '', title: '', report: '', propertyID: '',
            // Data Binding to Search for Property based on search input //
            searchResultsProperty: [], selectedProperty: null, showDropdown: true,
            // Data Binding to Search for Reporter (Tenant/Landlord) based on search input //
            searchResultsReporter: [], selectedReporter: null, showDropdownReporter: true, selectedReporterID: null,
            // Data Binding for Message Modal //
            modalMessage: '', isMessageModalVisible: false,
        }
    },
    components: {
        MessageModal,
    },
    watch: {
        // Watches for Changes in Property Name. Perform Search PropertyName when user has inputted new propertyName //
        propertyName: function () {
            if (this.selectedProperty === null || this.propertyName === '') {
                this.performSearchProperty();
            } else {
                if (this.selectedProperty.propertyName !== this.propertyName) {
                    this.performSearchProperty();
                }
            }
        },
        // Watches for changes in Reporter Name. Perform SearchReporter when user has inputted new reportername //
        reporterName: function () {
            if (this.selectedReporter === null || this.reporterName === '') {
                this.performSearchReporter();
            } else {
                // Because Reporter can be both Tenant or Landlord, condition the search based on us landlordName or tenantName is present //
                if (this.selectedReporter.landlordName) {
                    if (this.selectedReporter.landlordName !== this.reporterName) {
                        this.performSearchReporter();
                    }
                } else if (this.selectedReporter.tenantName) {
                    if (this.selectedReporter.tenantName !== this.reporterName) {
                        this.performSearchReporter();
                    }
                }

            }
        },

    },
    methods: {
        // Show Message Modal //
        showMessageModal(otherMessage) {
            this.isMessageModalVisible = true;
            this.modalMessage = otherMessage;
        },
        // Closes Message Modal //
        closeMessageModal() {
            this.isMessageModalVisible = false;
        },
        // Searches the Property based on the input from propertyName //
        async performSearchProperty() {
            // Intialise Property Collection //
            const propertyDocument = 'Property';
            const dbUser = doc(db, "Users", auth.currentUser.email);
            const propertyCollectionRef = collection(dbUser, propertyDocument);

            const q = query(propertyCollectionRef);
            const querySnapshot = await getDocs(q);
            const results = querySnapshot.docs
                .map((doc) => {
                    // Include the document ID in the mapped data object //
                    return { id: doc.id, ...doc.data() };
                }) // Searches for Property that matches the input propertyName only //
                .filter((data) => data.propertyName.includes(this.propertyName));

            this.searchResultsProperty = results;

            /* 
                Show Dropdown of Searches based on few Condition 
                - When no properties is selected 
                - When selected property is different from the inputted property name -> User wants to change property
                - When search result has 1 or more properties that has this propertyName 
            */
            if (this.propertyName === '') {
                this.showDropdown = false;
            } else {
                this.showDropdown = this.searchResultsProperty.length > 0;
                if (this.selectedProperty !== null) {
                    if (this.selectedProperty.propertyName === this.propertyName) {
                        this.showDropdown = true;
                    } else {
                        this.showDropdown = true;
                    }
                } else {
                    this.showDropdown = this.searchResultsProperty.length > 0;
                }
            }
        },
        // Handles the selection of properties when clicked on the dropdown box //
        async selectProperty(property) {
            this.selectedProperty = property;
            this.propertyName = property.propertyName;
            this.propertyAddress = property.propertyAddress;
            this.propertyID = property.id;
            this.showDropdown = false;

        },
        // Reporter can be Tenant or Landlord. Since do binding to differentiate the difference for the user //
        getReporterName(reporter) {
            if (reporter.landlordName) {
                return reporter.landlordName + ' (Landlord)';
            } else {
                return reporter.tenantName + ' (Tenant)';
            }
        },
        // Searches the Reporter based on the input from reporterName. Could be Tenant or Landlord //
        async performSearchReporter() {
            const dbUser = doc(db, "Users", auth.currentUser.email);

            // Extract all Tenants //
            const tenantDocument = 'Tenant';
            const tenantCollectionRef = collection(dbUser, tenantDocument);
            const q = query(tenantCollectionRef);
            const querySnapshot = await getDocs(q);
            const resultsTenant = querySnapshot.docs
                .map((doc) => {
                    // Include the document ID in the mapped data object //
                    return { id: doc.id, ...doc.data() };
                }) // searches for tenant that matches the user inputted name //
                .filter((data) => data.tenantName.includes(this.reporterName));

            this.searchResultsReporter = resultsTenant;

            // Extract all Landlords //
            const landlordDocument = 'Landlord';
            const landlordCollectionRef = collection(dbUser, landlordDocument);
            const qLandlord = query(landlordCollectionRef);
            const querySnapshotLandlord = await getDocs(qLandlord);
            const resultsLandlord = querySnapshotLandlord.docs
                .map((doc) => {
                    // Include the document ID in the mapped data object //
                    return { id: doc.id, ...doc.data() };
                }) // searches for landlord that matches the user inputted name //
                .filter((data) => data.landlordName.includes(this.reporterName));

            // Combine result from tenant and landlord together //
            this.searchResultsReporter = this.searchResultsReporter.concat(resultsLandlord);

            /* 
                Show Dropdown of Searches based on few Condition 
                - When no reporter is selected 
                - When selected reporter is different from the inputted reporter name -> User wants to change reporter
                - When search result has 1 or more reporter that has this reporter name  
            */
            if (this.reporterName === '') {
                this.showDropdownReporter = false;
            } else {
                this.showDropdownReporter = this.searchResultsReporter.length > 0;
                if (this.selectedReporter !== null) {
                    if (this.selectedReporter.landlordName) {
                        if (this.selectedReporter.landlordName === this.reporterName) {
                            this.showDropdownReporter = false;
                        }
                    } else {
                        if (this.selectedReporter.tenantName === this.reporterName) {
                            this.showDropdownReporter = false;
                        }
                    }
                } else {
                    this.showDropdownReporter = this.searchResultsReporter.length > 0;
                }
            }
        },
        // Handles the selection of Reporter when clicked on the dropdown box //
        async selectReporter(reporter) {
            this.selectedReporter = reporter;
            if (reporter.landlordName) {
                this.reporterName = reporter.landlordName;
            } else {
                this.reporterName = reporter.tenantName;
            }
            this.reporterID = reporter.id;
            this.showDropdownReporter = false;

        },
        // Creates New Incident in Incident Collection //
        async saveIncident() {
            let allInfoFilled = false;

            // Ensure that all Field are filled in //
            if (this.propertyName === '' || this.propertyAddress === '' || this.reporterName === '' || this.incidentDate === '' || this.title === '' ||
                this.report === '') {
                allInfoFilled = false;
                this.showMessageModal("Please fill in all Information!")
            } else {
                allInfoFilled = true;
            }

            // Execute Write Only if all Information is Filled //
            if (allInfoFilled === true) {

                { //Data validation
                    // Check if Incident Date is in the correct format //
                    const dobRegex = /^(?:(?!0000)[0-9]{4}([-/])(?:(?:0?[1-9]|1[0-2])\1(?:31|30|[12]\d|0?[1-9])|(?:0?[13-9]|1[0-2])\1(?:29|30|[12]\d|0?[1-9])|(?:0?[1-9]|1[0-2])\1(?:2[1-9]|[12]\d|0?[1-9])))$/;
                    if (!dobRegex.test(this.incidentDate)) {
                        this.showMessageModal("Please enter a valid date format (YYYY-MM-DD) for Incident Date!");
                        return;
                    }

                    const [year, month, day] = this.incidentDate.split('-').map(Number);

                    // Check if month is within 1-12
                    if (month < 1 || month > 12) {
                        this.showMessageModal("Please enter a valid month (01-12) for Incident Date!");
                        return;
                    }

                    // Check if day is within 1-31
                    if (day < 1 || day > 31) {
                        this.showMessageModal("Please enter a valid day (01-31) for Incident Date!");
                        return;
                    }

                    // Check if day is valid based on calendar month
                    const daysInMonth = new Date(year, month, 0).getDate();
                    if (day > daysInMonth) {
                        this.showMessageModal(`Please enter a valid day for the month of ${month}!`);
                        return;
                    }

                    // Check for leap year
                    if (month === 2 && day === 29 && !(year % 400 === 0 || (year % 4 === 0 && year % 100 !== 0))) {
                        this.showMessageModal(`${year} is not a leap year! Please enter a valid day for February.`);
                        return;
                    }
                }

                // Routing to Tenant Collection //
                const incidentDocument = 'Incident';
                const dbUser = doc(db, "Users", auth.currentUser.email);
                const incidentCollectionRef = collection(dbUser, incidentDocument);

                // Prepare Document //
                const allDocs = await getDocs(incidentCollectionRef);
                const count = allDocs.size;

                const landlordID = `Incident${count + 1}`; // DocumentID is the IncidentID //
                const incidentDateTimestamp = new Date(this.incidentDate);
                const incidentDateTimeStamp = Timestamp.fromDate(incidentDateTimestamp); // Converting to timestamp //
                const incidentDocRef = doc(incidentCollectionRef, landlordID);
                const incidentData = {
                    propertyID: this.propertyID,
                    reporterID: this.reporterID,
                    reportedDate: incidentDateTimeStamp,
                    status: "Not Resolved",
                    title: this.title,
                    description: this.report
                }

                // Tries to Write to Database //
                try {
                    await setDoc(incidentDocRef, incidentData);
                    this.showMessageModal("New Incident Added Successfully!")
                    document.getElementById('userForm').reset()
                    document.getElementById('userFormReport').reset()

                } catch (error) {
                    alert(error)

                }
            }
        }
    }
}
</script>

<style>
.grid-container {
    display: grid;
    grid-template-columns: 500px;
    grid-template-rows: 95vh 95vh;

}

.grid-item {
    background-color: white;
    border-radius: 10px;
    margin: 0px 10px;
    padding: 30px 40px;
    min-width: 500px;
}

.main-heading {
    margin-bottom: 40px;
}

.in-twos {
    display: flex;
    justify-content: space-between;
}

.input-wrapper {
    display: flex;
    flex-direction: column;
    width: 50%;
}

.input-wrapper2 {
    display: flex;
    flex-direction: column;
    width: 100%;
}

label {
    font-size: 18px;
    font-weight: 500;
    margin-bottom: 15px;

}

input {
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 80%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

.input_wide {
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 95%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

.report {
    width: 95%;
    height: 400px;
    white-space: normal;
}

.search {
    background-color: #FFFFFF;
    height: 51px;
    padding-left: 15px;
    border-radius: 10px;
    width: 80%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border: 2px solid black;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

#button-wrapper {
    display: flex;
    width: 100%;
}

.primary-button {
    height: 50px;
    width: 240px;
    background-color: var(--primary-accent);
    color: white;
    font-size: 18px;
    border-radius: 10px;
}

.dropdown {
    background-color: #F1F4FA;
    z-index: 999;
    position: fixed;
    margin-top: 60px;
    border-radius: 10px;
}

textarea {
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 80%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
    resize: none;
    font-size: 16px;
    padding-top: 25px;
}

.option {
    border: 1px solid black;
    padding: 6px;
    margin-top: 5px;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border-radius: 5px;

}

.option:hover {
    background-color: var(--primary-accent);
    color: white;
    cursor: pointer;

}
</style>