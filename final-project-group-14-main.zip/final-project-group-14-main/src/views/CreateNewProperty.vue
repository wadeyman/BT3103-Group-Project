<template>
    <div class="grid-container">

        <div class="grid-item">
            <h1 class="main-heading">Create New Property</h1>

            <div class="form-container">
                <form id="userForm">

                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="name">Property Name </label>
                            <input v-model="propertyName" id="name" required="yes"
                                placeholder="Property Name..." /><br /><br />
                        </div>

                        <div class="input-wrapper">
                            <label for="number">Property Address</label>
                            <input v-model.lazy="propertyAddress" id="address" required="yes"
                                placeholder="Property Address..." /><br /><br />
                        </div>
                    </div>

                    <h1 class="main-heading">Landlord Information</h1>

                    <div class="in-twos">
                        <div class="input-wrapper2">
                            <label for="landlordName">Landlord Name </label>
                            <input class="search2" v-model="landlordName" id="name" required="yes"
                                placeholder="Search Landlord Name..." />

                            <div class="dropdown" v-show="showDropdown">
                                <div class="option" v-for="landlord in searchResultsLandlord" :key="landlord.id"
                                    @click="selectLandlord(landlord)">
                                    {{ landlord.landlordName }}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="email">Email</label>
                            <input v-model="landlordEmail" disabled id="email" required="yes"
                                placeholder="Landlord Email..." />
                        </div>
                        <div class="input-wrapper">
                            <label for="address">Address</label>
                            <input v-model="landlordAddress" disabled id="address" required="yes"
                                placeholder="Landlord Address.." /><br /><br />
                        </div>
                    </div>

                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="number">Phone Number</label>
                            <input v-model="landlordNumber" disabled id="number" required="yes"
                                placeholder="Landlord Number..." readonly />
                        </div>
                        <div class="input-wrapper">
                            <label for="national">Nationality</label>
                            <input v-model="landlordNational" disabled id="national" required="yes"
                                placeholder="Landlord Nationality.." readonly /><br /><br />
                        </div>
                    </div>


                    <div id="button-wrapper">
                        <button class="primary-button" type="button" v-on:click="saveProperty">Save Record</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="grid-item">
            <h1 class="main-heading">Upload Property Image</h1>

            <div id="imageContainer">
                <img id="selectedImage" :src="selectedImage" alt="Please Insert Property Image">
            </div>
            <div class="fileInputWrapper">
                <label for='fileInput' id='fileLabel'>Upload Property Photo
                    <input type="file" id="fileInput" @change="getFile" accept="image/jpg" />
                </label>
            </div>

        </div>
    </div>
    <MessageModal v-show="isMessageModalVisible" @close="closeMessageModal" :message="modalMessage" />
</template>

<script>
import { db, auth } from "@/firebase.js";
import { collection, doc, setDoc, getDocs, query } from 'firebase/firestore'
import { getStorage, ref, uploadBytes } from 'firebase/storage'
import { firebaseApp } from '../firebase.js'
import MessageModal from '@/components/MessageModal.vue';

export default {

    name: "CreateNewIncident",
    data() {
        return {
            // Data Binding for Input Entered Into Form //
            propertyName: '', propertyAddress: '', landlordName: '', landlordAddress: '', landlordEmail: '', landlordNumber: '', landlordNational: '',
            // Data Binding to Search for Landlord based on search input //
            searchResultsLandlord: [], selectedLandlord: null, showDropdown: true, landlordID: '',
            // Data Binding for the Property Image uploaded //
            selectedImage: null,
            // Data Binding for Message Modal //
            modalMessage: '', isMessageModalVisible: false
        }
    },
    components: {
        MessageModal,
    },
    watch: {
        // Watches for changes in landlordName. Perform SearchLandlord when user has inputted new landlordName
        landlordName: function () {
            if (this.selectedLandlord === null || this.landlordName === '') {
                this.performSearchLandlord();
            } else {
                if (this.selectedLandlord.landlordName !== this.landlordName) {
                    this.performSearchLandlord();
                }
            }
        },

    },
    methods: {
        // Show Message Modal //
        showMessageModal(otherMessage) {
            this.isMessageModalVisible = true;
            this.modalMessage = otherMessage;
        },
        // Closes Message Modal //
        closeMessageModal() {
            this.isMessageModalVisible = false;
        },
        // Function that allow user to upload the property picture //
        // only jpg format is supported //
        getFile(event) {

            // Only selects the first file uploaded //
            const selectedFile = event.target.files[0];

            if (selectedFile) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    this.selectedImage = event.target.result;
                };
                reader.readAsDataURL(selectedFile);
            }
        },
        // Searches the Landlord based on the input from Landlord Name. Display as DropDown Box for Selection //
        async performSearchLandlord() {

            // Intialise Landlord Collection //
            const landlordDocument = 'Landlord';
            const dbUser = doc(db, "Users", auth.currentUser.email);
            const landlordCollectionRef = collection(dbUser, landlordDocument);

            const q = query(landlordCollectionRef);
            const querySnapshot = await getDocs(q);
            const results = querySnapshot.docs
                .map((doc) => {
                    // Include the document ID in the mapped data object //
                    return { id: doc.id, ...doc.data() };
                }) // Searches for Landlord that matches the input landlordName only //
                .filter((data) => data.landlordName.includes(this.landlordName));

            this.searchResultsLandlord = results;

            /* 
                Show Dropdown of Searches based on few Condition 
                - When no properties is selected 
                - When selected property is different from the inputted property name -> User wants to change property
                - When search result has 1 or more properties that has this propertyName 
            */
            if (this.landlordName === '') {
                this.showDropdown = false;
            } else {
                this.showDropdown = this.searchResultsLandlord.length > 0;
                if (this.selectedLandlord !== null) {
                    if (this.selectedLandlord.landlordName === this.landlordName) {
                        this.showDropdown = true;
                    } else {
                        this.showDropdown = true;
                    }
                } else {
                    this.showDropdown = this.searchResultsLandlord.length > 0;
                }
            }
        },
        // Handles the selection of landlord when clicked on the dropdown box //
        async selectLandlord(landlord) {
            this.selectedLandlord = landlord;
            this.landlordName = landlord.landlordName;
            this.landlordAddress = landlord.landlordAddress;
            this.landlordEmail = landlord.landlordEmail;
            this.landlordNational = landlord.landlordNationality;
            this.landlordNumber = landlord.landlordNumber;
            this.landlordID = landlord.id;
            this.showDropdown = false;

        },
        // Creates New Property in Property Collection //
        async saveProperty() {
            let allInfoFilled = false;

            // Ensure that all Field are filled in //
            if (this.propertyName === '' || this.propertyAddress === '' || this.landlordID === '' || this.landlordEmail === '' || this.landlordAddress === '' ||
                this.landlordNumber === '' || this.landlordNational === '' || this.selectedImage === null) {
                allInfoFilled = false;
                this.showMessageModal("Please fill in all Information!")
            } else {
                allInfoFilled = true;
            }

            // Execute Write Only if all Information is Filled //
            if (allInfoFilled === true) {

                // Routing to Property Collection //
                const propertyDocument = 'Property';
                const dbUser = doc(db, "Users", auth.currentUser.email);
                const propertyCollectionRef = collection(dbUser, propertyDocument);

                // Prepare Document //
                const allDocs = await getDocs(propertyCollectionRef);
                const count = allDocs.size;

                const propertyID = `Property${count + 1}`;
                const propertyDocRef = doc(propertyCollectionRef, propertyID);

                // Write File to Storage //
                const storageImagesRef = ref(getStorage(firebaseApp), 'images/' + propertyID + '.jpg');
                let response = await fetch(this.selectedImage)
                let blob = await response.blob(); // Convert it as an File Object

                // Upload to Firebase Storage with the PropertyID as the FileName //
                try {
                    uploadBytes(storageImagesRef, blob).then(() => { console.log("Images Uploaded Successfully") });
                } catch (error) {
                    console.error(error);
                }

                const propertyData = {
                    propertyName: this.propertyName,
                    propertyAddress: this.propertyAddress,
                    landlordID: this.landlordID,
                    leasesID: [],
                    picture: "images/" + propertyID + '.jpg'
                }

                // Tries to Write to Database
                try {
                    await setDoc(propertyDocRef, propertyData);
                    this.showMessageModal("New Property Added Successfully!")
                    document.getElementById('userForm').reset();
                } catch (error) {
                    alert(error)
                    console.error(error);
                }
            }
        }
    }

}
</script>

<style>
.grid-container {
    display: grid;
    grid-template-columns: 500px;
    grid-template-rows: 95vh 95vh;

}

.grid-item {
    background-color: white;
    border-radius: 10px;
    margin: 0px 10px;
    padding: 30px 40px;
    min-width: 500px;
}

.main-heading {
    margin-bottom: 40px;
}

.in-twos {
    display: flex;
    justify-content: space-between;
}

.input-wrapper {
    display: flex;
    flex-direction: column;
    width: 50%;
}

.input-wrapper2 {
    display: flex;
    flex-direction: column;
    width: 100%;
    margin-bottom: 35px;
}

label {
    font-size: 18px;
    font-weight: 500;
    margin-bottom: 15px;

}

input {
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 80%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

.input_wide {
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 95%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

.report {
    width: 95%;
    height: 400px;
    white-space: normal;
}

.search2 {
    background-color: #FFFFFF;
    height: 51px;
    padding-left: 15px;
    border-radius: 10px;
    width: 90%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border: 2px solid black;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

#button-wrapper {
    display: flex;
    width: 100%;
}

.primary-button {
    height: 50px;
    width: 240px;
    background-color: var(--primary-accent);
    color: white;
    font-size: 18px;
    border-radius: 10px;
}

.dropdown {
    background-color: #F1F4FA;
    z-index: 999;
    position: fixed;
    margin-top: 60px;
    border-radius: 10px;
}

.option {
    border: 1px solid black;
    padding: 6px;
    margin-top: 5px;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border-radius: 5px;

}

.option:hover {
    background-color: var(--primary-accent);
    color: white;
    cursor: pointer;

}

#imageContainer {
    width: 95%;
    height: 500px;
    display: flex;
    justify-content: center;
    align-items: flex-start;
}

#selectedImage {
    max-width: 100%;
    max-height: 500px;
}

#fileInput {
    display: none;
}

#fileLabel {
    width: 240px;
    background-color: var(--primary-accent);
    color: white;
    font-size: 18px;
    border-radius: 10px;
    padding: 21px 50px;
    cursor: pointer;
    text-align: center;
}

.fileInputWrapper {
    display: flex;
    margin-top: 40px;
    justify-content: center;

}
</style>