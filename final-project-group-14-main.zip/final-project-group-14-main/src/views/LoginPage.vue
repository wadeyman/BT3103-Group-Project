<template>
    <div class="grid-container">
        <div class="grid-item">
            <div class="header-wrapper"> 
                
                <img class="main-logo" src="@/assets/mainlogo.png" >
                <h3> Real Estate Management App </h3> 
            </div> 

            <div id="button-wrapper">
                <button class="google-button" type="button" v-on:click="signInWithGoogle">
                    <img class="google-img" src='@/assets/search.png'>Google</button>
            </div>
             <div class="text-wrapper">
                <p> Or</p>  
            </div> 
            <div class="input-wrapper"> 
                <label>Email Address </label> 
                <input type="email" v-model="email" placeholder="example@email.com">
            </div> 
            <div class="input-wrapper"> 
                <label>Password </label> 
                <input type="password" v-model="password" placeholder="••••••••">
            </div> 

            <div id="button-wrapper">
                <button class="primary-button" type="button" v-on:click="login">Login</button>
            </div>

            <div class="text-wrapper">
                <p style="color: black;"> Don't have an account yet? <a href ="/signup"> New Account </a> </p>  
            </div> 
        </div>
    

        <div class='grid-item' style="background-color: #F1F4FA ;"> 
            <div class="image-wrapper">
            <img src="@/assets/Login.png" class="login-image">
            </div>
        </div> 

        </div>

        <button v-if="failedAttempts >= 3" class="pure-material-button-contained" @click="showForgotPasswordDialog = true">Forgot Password?</button>

        <div v-if="showForgotPasswordDialog" class="forgot-password-overlay">
            <div class="forgot-password-dialog">
                <h2>Forgot Password</h2>
                <input type="email" v-model="recoveryEmail" placeholder="Enter your recovery email">
                <div class="forgot-password-buttons">
                    <button class="primary-button2" @click="forgotPassword">Send Reset Link</button>
                    <button class="primary-button2" @click="showForgotPasswordDialog = false">Cancel</button>
                </div>
            </div>
        </div>
    <MessageModal v-show="isMessageModalVisible" @close="closeMessageModal" :message="modalMessage" />
</template>

<script>
import { getAuth, signInWithEmailAndPassword, GoogleAuthProvider, signInWithPopup, sendPasswordResetEmail } from 'firebase/auth';
import MessageModal from '@/components/MessageModal.vue';
import { doc, setDoc, collection } from "firebase/firestore"; 
import {db} from "@/firebase.js";

export default {    
    data() { 
        return {
            // Data Binding for Message Modal // 
            modalMessage: '', isMessageModalVisible: false,
            // Data Binding for Form of Login Details //
            email: '',  password: '',
            failedAttempts: 0,
            showForgotPasswordDialog: false,
            recoveryEmail: '',
        }
    },
    components: {
        MessageModal,
    },

    methods: {
        showMessageModal(otherMessage) {
            this.isMessageModalVisible = true;
            this.modalMessage = otherMessage;
        },
        closeMessageModal() {
            this.isMessageModalVisible = false;
        },
        async login() {
            try {
                const auth = getAuth();
                await signInWithEmailAndPassword(auth, this.email, this.password);
                this.$router.push("/");
            } catch (error) {

                this.failedAttempts++;
                // Input Error Code based on Login Error //
                switch (error.code) {
                    case "auth/missing-email":
                        this.showMessageModal("Please enter an email address.");
                        break;
                    case "auth/missing-password":
                        this.showMessageModal("Please enter a password.");
                        break;
                    case "auth/invalid-email":
                        this.showMessageModal("Invalid email. Please check your email and try again.");
                        break;
                    case "auth/invalid-login-credentials":
                        this.showMessageModal("Invalid password. Please check your password and try again.");
                        break;
                    default:
                        this.showMessageModal("An unknown error occurred. Please try again.");
                        break;
                }
            }
            // Allow the User to reset their password after more than 3 failed attemps //
            if (this.failedAttempts >= 3) {
                this.showForgotPasswordDialog = true;
            }
        },
        async signInWithGoogle () {
            const provider = new GoogleAuthProvider();
            try {
                const auth = getAuth();
                await signInWithPopup(auth, provider);
                const user = getAuth().currentUser; 
                
                // Since each user can only access information on their collection
                // Need to set a new document containing their username
                await setDoc(doc(collection(db,"Users"),user.email),{});
                this.$router.push("/");
    
            } catch (error) {
                this.showMessageModal("Google Sign-In error: " + error)
            }
        },
        async forgotPassword (){
            try {
                const auth = getAuth();
                await sendPasswordResetEmail(auth, this.recoveryEmail);
                this.showMessageModal("Password reset email sent if the email address is associated with an account.");
                this.showForgotPasswordDialog = false;
            } catch (error) {
                this.showMessageModal("An error occurred while trying to send the password reset email. Please try again.");
            }
        }
    },

};
</script>


<style scoped>

.login-image {
    width: 450px;
    height: 400px;
    align-content: center;
}
.image-wrapper { 
     display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}
.header-wrapper { 
    text-align: center;
    margin-bottom: 50px;
}
.input-wrapper {
    display: flex;
    flex-direction: column;
    width: 100%;
    margin-bottom: 30px;
}

label {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 10px;

}

input { 
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 95%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1); 
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

.text-wrapper { 
    text-align: center; 
}
.grid-container {
    display: grid;
    grid-template-columns: 10fr 20fr;
    height: 100vh;
    margin: 0px;
    width: fit-content;
    grid-template-rows: auto;
    
}

.grid-item {
    background-color: white; 
    padding: 30px 40px;
    height: fit-content;
    min-height: 100vh;
    border-radius: 0px;
    margin: 0px;
}


#button-wrapper {
    display: flex;
    justify-content: center;
    margin-bottom: 10px;
    width: 100%;
}

.primary-button {
    height: 45px;
    width: 99%;
    background-color: var(--primary-accent);
    color: white; 
    font-size: 18px;
    border-radius: 10px;
    border: 0px;
    cursor: pointer;
}

.google-button {
    height: 45px;
    width: 33%;
    background-color: #F1F4FA;
    color: black; 
    font-size: 18px;
    border-radius: 10px;
    border: 0px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.google-img { 
    width: 18px;
    height: 18px;
    margin-right: 10px;
}
.login-signup-input {
    margin: 10px 0;
    padding: 12px;
    width: 80%;
    font-size: 1rem;
    border-radius: 4px;
    border: 1px solid #ccc;
}


.forgot-password-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

.forgot-password-dialog {
    background-color: white;
    padding: 20px;
    border-radius: 5px;
    min-width: 600px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
}

.forgot-password-buttons {
    display: flex;
    justify-content: flex-end;
    gap: 40px;
    margin-top: 20px;
}

.primary-button2 {
    height: 50px;
    width: 240px;
    background-color: var(--primary-accent);
    color: white; 
    font-size: 18px;
    border-radius: 10px;
    border: 0px;
    cursor: pointer;
}

</style>
