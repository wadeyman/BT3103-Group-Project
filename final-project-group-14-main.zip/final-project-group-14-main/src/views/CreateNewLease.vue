<template>
    <div class="grid-container">

        <div class="grid-item">
            <h1 class="main-heading"> Create New Lease</h1>

            <div class="form-container">
                <form id="userForm">
                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="active">Property Name</label>
                            <input v-model.lazy="propertyName" disabled id="active" placeholder="0" /><br /><br />
                        </div>
                        <div class="input-wrapper">
                            <label for="address">Property Address</label>
                            <input v-model.lazy="propertyAddress" disabled id="address" required="yes"
                                placeholder="Address.." /><br /><br />
                        </div>
                    </div>
                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="active">Montly Rental</label>
                            <input v-model.lazy="rate" id="active" placeholder="$..." /><br /><br />
                        </div>
                        <div class="input-wrapper">
                            <label for="address">Lease Tenure</label>
                            <input v-model.lazy="leaseTenure" id="address" required="yes"
                                placeholder="1 Year... etc" /><br /><br />
                        </div>
                    </div>
                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="active">Lease Start Date</label>
                            <input v-model.lazy="startDate" id="active" placeholder="YYYY-MM-DD" /><br /><br />
                        </div>
                        <div class="input-wrapper">
                            <label for="address">Lease End Date</label>
                            <input v-model.lazy="endDate" id="address" required="yes"
                                placeholder="YYYY-MM-DD" /><br /><br />
                        </div>
                    </div>
                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="active">Rental Collection Method</label>
                            <input v-model.lazy="collectionMethod" id="active"
                                placeholder="Bank Transfer/Paynow" /><br /><br />
                        </div>
                        <div class="input-wrapper">
                            <label for="address">Rental Due Date</label>
                            <input v-model.lazy="dueDate" id="address" required="yes"
                                placeholder="Every --th of the Month..." /><br /><br />
                        </div>
                    </div>
                    <h1 class="main-heading">Landlord Information</h1>
                    <div class="in-twos">
                        <div class="input-wrapper2" style="margin-bottom: 0px;">
                            <label for="active">Name</label>
                            <input style="width: 90%" v-model.lazy="landlordName" disabled id="active"
                                placeholder="0" /><br /><br />
                        </div>

                    </div>
                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="active">Email</label>
                            <input v-model.lazy="landlordEmail" disabled id="active" placeholder="0" /><br /><br />
                        </div>
                        <div class="input-wrapper">
                            <label for="address">Address</label>
                            <input v-model.lazy="landlordAddress" disabled id="address" required="yes"
                                placeholder="Address.." /><br /><br />
                        </div>
                    </div>
                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="active">Phone Number</label>
                            <input v-model.lazy="landlordNumber" disabled id="active" placeholder="$..." /><br /><br />
                        </div>
                        <div class="input-wrapper">
                            <label for="address">Nationality</label>
                            <input v-model.lazy="landlordNational" disabled id="address" required="yes"
                                placeholder="1 Year... etc" /><br /><br />
                        </div>
                    </div>


                </form>
            </div>
        </div>

        <div class="grid-item">
            <h1 class="main-heading"> Tenant Information</h1>

            <div class="form-container">
                <form id="userFormReport">
                    <div class="input-wrapper2">
                        <label for="name">Tenant Name </label>
                        <input class="search" v-model="tenantName" id="name" required="yes"
                            placeholder="Search Tenant Name..." />

                        <div class="dropdown" v-show="showDropdown">
                            <div class="option" v-for="tenant in searchResultsTenant" :key="tenant.id"
                                @click="selectTenant(tenant)">
                                {{ tenant.tenantName }}
                            </div>
                        </div>
                    </div>

                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="active">Email</label>
                            <input v-model.lazy="tenantEmail" disabled id="active" placeholder="0" /><br /><br />
                        </div>
                        <div class="input-wrapper">
                            <label for="address">Address</label>
                            <input v-model.lazy="tenantAddress" disabled id="address" required="yes"
                                placeholder="Address.." /><br /><br />
                        </div>
                    </div>

                    <div class="in-twos">
                        <div class="input-wrapper">
                            <label for="active">Phone Number</label>
                            <input v-model.lazy="tenantNumber" disabled id="active"
                                placeholder="+65 88888888" /><br /><br />
                        </div>
                        <div class="input-wrapper">
                            <label for="address">Nationality</label>
                            <input v-model.lazy="tenantNational" disabled id="address" required="yes"
                                placeholder="Singapore..." /><br /><br />
                        </div>
                    </div>

                    <div id="button-wrapper">
                        <button class="primary-button" type="button" v-on:click="saveLease">Save Lease</button>
                    </div>


                </form>
            </div>
        </div>

    </div>

    <MessageModal v-show="isMessageModalVisible" @close="closeMessageModal" :message="modalMessage" />
</template>

<script>
import { db, auth } from "@/firebase.js";
import { collection, doc, setDoc, Timestamp, getDocs, query, getDoc, updateDoc } from 'firebase/firestore'
// import {customAlert} from '@/composables/alertBox.js';
import MessageModal from '@/components/MessageModal.vue';

export default {

    name: "CreateNewLease",
    props: {
        // Props are based by ViewProperty. One can only create a new leaese for a given property. //
        // Hence, this helps data validation and reduces the number of input by the user //
        propertyID: String,
        landlordID: String,
    },
    components: {
        MessageModal,
    },
    data() {
        return {
            propertyName: '', propertyAddress: '',
            // Data Binding for Input Entered Into Form
            rate: '', leaseTenure: '', startDate: '', endDate: '', collectionMethod: '', dueDate: '',
            landlordName: '', landlordEmail: '', landlordAddress: '', landlordNumber: '', landlordNational: '',
            // Data Binding for Selected Tenant Selected
            tenantID: '', tenantName: '', tenantEmail: '', tenantAddress: '', tenantNumber: '', tenantNational: '',
            tenantData: null, landlordData: null, propertyData: null,
            // Data Binding to Search for Tenant based on search input
            searchResultsTenant: [], selectedTenant: null, showDropdown: true,
            // Data Binding for Message Modal
            modalMessage: '', isMessageModalVisible: false,
        }
    },
    watch: {
        // Watch to perform search on firebase when new input is entered in tenantName //
        tenantName: function () {
            if (this.selectedTenant === null || this.tenantName === '') {
                this.performSearchTenant();
            } else {
                if (this.selectedTenant.tenantName !== this.tenantName) {
                    this.performSearchTenant();
                }
            }
        },

    },
    async mounted() {
        const dbUser = doc(db, "Users", auth.currentUser.email);

        // Get Property Data from Database //
        const propertyDocument = 'Property';
        const propertyCollectionRef = collection(dbUser, propertyDocument);
        const propertyDocRef = doc(propertyCollectionRef, this.propertyID);
        await getDoc(propertyDocRef).then((doc) => {
            this.propertyData = doc.data();
        })

        // Reference to Data to bind data to input //
        this.propertyName = this.propertyData.propertyName;
        this.propertyAddress = this.propertyData.propertyAddress;

        // Get Landlord Data from Database //
        const landlordDocument = 'Landlord';
        const landlordCollectionRef = collection(dbUser, landlordDocument);
        const landlordDocRef = doc(landlordCollectionRef, this.propertyData.landlordID);
        await getDoc(landlordDocRef).then((doc) => {
            this.landlordData = doc.data();
        })

        // Reference to Data to bind data to input //
        this.landlordName = this.landlordData.landlordName;
        this.landlordEmail = this.landlordData.landlordEmail;
        this.landlordAddress = this.landlordData.landlordAddress;
        this.landlordNumber = this.landlordData.landlordNumber;
        this.landlordNational = this.landlordData.landlordNationality;

    },
    methods: {
        // Show Message Modal when new lease is created successfully //
        showMessageModal(otherMessage) {
            this.isMessageModalVisible = true;
            this.modalMessage = otherMessage;
        },
        // Event that closes the modal //
        closeMessageModal() {
            this.isMessageModalVisible = false;
        },
        // Searches the Tenant based on the input from Tenant Name //
        async performSearchTenant() {

            // Initialise Tenant Data from Firebase //
            const tenantDocument = 'Tenant';
            const dbUser = doc(db, "Users", auth.currentUser.email);
            const tenantCollectionRef = collection(dbUser, tenantDocument);

            const q = query(tenantCollectionRef);
            const querySnapshot = await getDocs(q);
            const results = querySnapshot.docs
                .map((doc) => {
                    // Include the document ID in the mapped data object //
                    return { id: doc.id, ...doc.data() };
                })  // Filters only Tenant with Matching Tenant Name as the tenantName input //
                .filter((data) => data.tenantName.includes(this.tenantName));

            this.searchResultsTenant = results;

            /* 
                Show Dropdown of Searches based on few Condition 
                - When no Tenant is selected 
                - When selected Tenant is different from the inputted Tenant name -> User wants to change Tenant
                - When search result has 1 or more Tenant that has this Tenant name  
            */
            if (this.tenantName === '') {
                // Dropdown bar of result do not show when it is empty as it will only show all of the result //
                this.showDropdown = false;
            } else {
                this.showDropdown = this.searchResultsTenant.length > 0;
                if (this.selectedTenant !== null) {
                    if (this.searchResultsTenant.tenantName === this.tenantName) {
                        this.showDropdown = true;
                    } else {
                        this.showDropdown = true;
                    }
                } else {
                    this.showDropdown = this.searchResultsTenant.length > 0;
                }
            }
        },
        // Handles the selection of Reporter when clicked on the dropdown box //
        async selectTenant(tenant) {
            this.selectedTenant = tenant;
            this.tenantName = tenant.tenantName;
            this.tenantID = tenant.id;
            this.tenantAddress = tenant.tenantAddress;
            this.tenantNumber = tenant.tenantNumber;
            this.tenantNational = tenant.tenantNationality;
            this.tenantEmail = tenant.tenantEmail;
            this.showDropdown = false;
        },
        // Creates New Lease in Lease Collection //
        async saveLease() {
            let allInfoFilled = false;

            // Ensure that all Field are filled in //
            if (this.rate === '' || this.leaseTenure === '' || this.startDate === '' || this.endDate === '' || this.dueDate === '' ||
                this.collectionMethod === '' || this.tenantName === '') {
                allInfoFilled = false;
                this.showMessageModal("Please fill in all Information!")
            } else {
                allInfoFilled = true;
            }

            { // Data validation}
                // Validate Start Date Format
                const startDateRegex = /^(?:(?!0000)[0-9]{4}([-/])(?:(?:0?[1-9]|1[0-2])\1(?:31|30|[12]\d|0?[1-9])|(?:0?[13-9]|1[0-2])\1(?:29|30|[12]\d|0?[1-9])|(?:0?[1-9]|1[0-2])\1(?:2[1-9]|[12]\d|0?[1-9])))$/;
                if (!startDateRegex.test(this.startDate)) {
                    this.showMessageModal("Please enter a valid date format (YYYY-MM-DD) for Start Date!");
                    return;
                }

                const [startYear, startMonth, startDay] = this.startDate.split('-').map(Number);

                // Check if month is within 1-12
                if (startMonth < 1 || startMonth > 12) {
                    this.showMessageModal("Please enter a valid month (01-12) for Start Date!");
                    return;
                }

                // Check if day is within 1-31
                if (startDay < 1 || startDay > 31) {
                    this.showMessageModal("Please enter a valid day (01-31) for Start Date!");
                    return;
                }

                // Check if day is valid based on calendar month
                const startDaysInMonth = new Date(startYear, startMonth, 0).getDate();
                if (startDay > startDaysInMonth) {
                    this.showMessageModal(`Please enter a valid day for the month of ${startMonth}!`);
                    return;
                }

                // Validate End Date Format
                const endDateRegex = /^(?:(?!0000)[0-9]{4}([-/])(?:(?:0?[1-9]|1[0-2])\1(?:31|30|[12]\d|0?[1-9])|(?:0?[13-9]|1[0-2])\1(?:29|30|[12]\d|0?[1-9])|(?:0?[1-9]|1[0-2])\1(?:2[1-9]|[12]\d|0?[1-9])))$/;
                if (!endDateRegex.test(this.endDate)) {
                    this.showMessageModal("Please enter a valid date format (YYYY-MM-DD) for End Date!");
                    return;
                }

                const [endYear, endMonth, endDay] = this.endDate.split('-').map(Number);

                // Check if month is within 1-12
                if (endMonth < 1 || endMonth > 12) {
                    this.showMessageModal("Please enter a valid month (01-12) for End Date!");
                    return;
                }

                // Check if day is within 1-31
                if (endDay < 1 || endDay > 31) {
                    this.showMessageModal("Please enter a valid day (01-31) for End Date!");
                    return;
                }

                // Check if day is valid based on calendar month
                const endDaysInMonth = new Date(endYear, endMonth, 0).getDate();
                if (endDay > endDaysInMonth) {
                    this.showMessageModal(`Please enter a valid day for the month of ${endMonth}!`);
                    return;
                }

                // Check if start date is before end date
                const startDateObj = new Date(this.startDate);
                const endDateObj = new Date(this.endDate);
                if (startDateObj >= endDateObj) {
                    this.showMessageModal("End Date must be after Start Date!");
                    return;
                }

                // Ensure that Monthly Rental is a Number
                if (isNaN(this.rate)) {
                    this.showMessageModal("Please enter a valid number for Monthly Rental (without '$')!");
                    return;
                }
            }

            // Execute Write Only if all Information is Filled //
            if (allInfoFilled === true) {

                // Routing to Lease Collection //
                const leaseDocument = 'Lease';
                const dbUser = doc(db, "Users", auth.currentUser.email);
                const leaseCollectionRef = collection(dbUser, leaseDocument);

                // Prepare Document //
                const allDocs = await getDocs(leaseCollectionRef);
                const count = allDocs.size;

                const leaseID = `Lease${count + 1}`;
                const startDateTimestamp = Timestamp.fromDate(new Date(this.startDate));
                const endDateTimestamp = Timestamp.fromDate(new Date(this.endDate));
                const leaseDocRef = doc(leaseCollectionRef, leaseID);

                // Create New Payment History for the New Lease and Set it as Pending //
                const monthNames = [
                    "January", "February", "March", "April", "May", "June",
                    "July", "August", "September", "October", "November", "December"
                ];

                // Get only the frist three letters of the month //
                const month = monthNames[new Date(this.startDate).getMonth()].substring(0, 3);

                const leaseData = {
                    propertyID: this.propertyID,
                    tenantID: this.tenantID,
                    landlordID: this.landlordID,
                    collectionMethod: this.collectionMethod,
                    endDate: endDateTimestamp,
                    startDate: startDateTimestamp,
                    rentDueDate: this.dueDate,
                    leaseTenure: this.leaseTenure,
                    paymentHistory: [{
                        tenantName: this.tenantName,
                        rate: this.rate,
                        month: month,
                        status: "Pending"
                    }]
                }

                // Updates the Property LeasesID to also include this newly created Lease //
                const propertylordDocument = 'Property';
                const propertyCollectionRef = collection(dbUser, propertylordDocument);
                const propertyDocRef = doc(propertyCollectionRef, this.propertyID);
                const propertyDoc = await getDoc(propertyDocRef);
                const propData = propertyDoc.data();

                // Pushes New LeaseID to the property array of leasesID //
                propData.leases = propData.leasesID.push(leaseID);

                // Updates the Property Information //
                updateDoc(propertyDocRef, propData)
                    .then(() => {
                        this.showMessageModal("Property Information has been Updated Successfully!")
                    })
                    .catch((error) => {
                        alert("Error editing information: ", error)
                    })

                // Create New Document for the Lease //
                try {
                    await setDoc(leaseDocRef, leaseData);
                    this.showMessageModal("New Lease Added Successfully!")
                    document.getElementById('userForm').reset()
                    document.getElementById('userFormReport').reset()

                } catch (error) {
                    alert(error)
      
                }
            }
        }
    }

}
</script>

<style scoped>
.grid-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: 95vh 95vh;

}

.grid-item {
    background-color: white;
    border-radius: 10px;
    margin: 0px 10px;
    padding: 30px 40px;
    min-width: 500px;
}

.main-heading {
    margin-bottom: 40px;
}

.in-twos {
    display: flex;
    justify-content: space-between;
}

.input-wrapper {
    display: flex;
    flex-direction: column;
    width: 50%;
}

.input-wrapper2 {
    display: flex;
    flex-direction: column;
    width: 100%;
}

label {
    font-size: 18px;
    font-weight: 500;
    margin-bottom: 15px;

}

input {
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 80%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

.input_wide {
    background-color: #F1F4FA;
    height: 55px;
    padding-left: 15px;
    border-radius: 10px;
    width: 95%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

.report {
    width: 95%;
    height: 400px;
    white-space: normal;
}

.search {
    background-color: #FFFFFF;
    height: 51px;
    padding-left: 15px;
    border-radius: 10px;
    width: 95%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border: 2px solid black;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

#button-wrapper {
    display: flex;
    width: 100%;
}

.primary-button {
    height: 50px;
    width: 240px;
    background-color: var(--primary-accent);
    color: white;
    font-size: 18px;
    border-radius: 10px;
}

.dropdown {
    background-color: #F1F4FA;
    z-index: 999;
    position: fixed;
    margin-top: 60px;
    border-radius: 10px;
}

.option {
    border: 1px solid black;
    padding: 6px;
    margin-top: 5px;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1);
    border-radius: 5px;

}

.option:hover {
    background-color: var(--primary-accent);
    color: white;
    cursor: pointer;

}
</style>