<template>
    <div>
        <IncidentList />
    </div>
</template>

<script>
import IncidentList from "@/components/IncidentList.vue"
export default {
    name: 'IncidentManagement',
    components: {
        IncidentList
    },
}
;
</script>
