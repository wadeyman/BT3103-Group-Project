<template>
    <div>
        <PropertyList />
    </div>
</template>

<script>
import PropertyList from "@/components/PropertyList.vue"
export default {
    name: 'PropertyManagement',
    components: {
        PropertyList
    },
}
;
</script>
