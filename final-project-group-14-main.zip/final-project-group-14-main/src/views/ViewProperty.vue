<template>
    <div class="grid-container">
        <div class="grid-item">
        <h1 class="main-heading"> Property View</h1> 
        <div id="imageContainer_2"> 
            <img id="selectedImage_2" :src="selectedImage" alt="Please Insert Property Image">
        </div>
        <div class="form-container">
            <form id="userForm">
            <div class="in-twos">
                <div class="input-wrapper"> 
                    <label for="name">Property Name </label>
                    <input class="input_small" v-model="propertyName" :disabled="!openEditing" id="name" required="yes" placeholder="Name..." /><br /><br />
            </div>
                <div class="input-wrapper"> 
                    <label for="number">Property Address</label>
                    <input class="input_small" v-model="propertyAddress" :disabled="!openEditing" id="ticker1" required="yes" placeholder="Phone Number..." /><br /><br />
                </div>
            </div>

            <h1 class="main-heading"> Landlord Information</h1> 
            <div class="in-twos">
                <div class="input-wrapper_2">
                    <label for="email">Name</label>
                    <input class="input_small_wide" v-model="landlordName" :disabled="!openEditing" id="email" required="yes" placeholder="Seach Landlord Name..." /><br /><br />
                    <div class="dropdown" v-show="showDropdown">
                    <div class="option" v-for="landlord in searchResultsLandlord" :key="landlord.id" @click="selectLandlord(landlord)">
                        {{ landlord.landlordName }}
                    </div>
                    </div>
                </div>

            </div>

            <div class="in-twos">
                <div class="input-wrapper">    
                    <label for="email">Email</label>
                    <input class="input_small" v-model="landlordEmail" disabled id="dob" required="yes" placeholder="YYYY-MM-DD" /><br /><br />
                </div>
                <div class="input-wrapper">
                    <label for="gender">Address</label>
                    <input class="input_small" v-model="landlordAddress" disabled id="gender" required="yes" placeholder="Male/Female" /><br /><br />
                </div>
            </div>

            <div class="in-twos">
                <div class="input-wrapper">
                    <label for="active">Phone Number</label>
                    <input class="input_small" v-model="landlordNumber" disabled id="active" required="yes" placeholder="Active Rental..." /><br /><br />
                </div>
                <div class="input-wrapper">
                    <label for="address">Nationality</label>
                    <input class="input_small" v-model="landlordNational" disabled id="address" required="yes" placeholder="Address.." /><br /><br />
                </div>
            </div>

            <div id="button-wrapper">
                <button class="primary-button" id="editInformation" type="button" v-on:click="editInformation">Edit Information</button>
                <button class="delete-button" type="button" v-on:click="startDelete">Delete Property</button>
            </div>
            </form>
        </div>
        </div>

            <div class='grid-item' > 


                <h1 class="main-heading" style="margin-bottom: 20px; "> Current Lease</h1> 
                <div class="form-container">
                <form id="userForm">
            <div class="in-twos">
                <div class="input-wrapper"> 
                    <label for="name">Tenant Name </label>
                    <input class="input_small" v-model="tenantName" id="name" required="yes" placeholder="Name..." /><br /><br />
            </div>
                <div class="input-wrapper"> 
                    <label for="number">Tenant Phone Number</label>
                    <input class="input_small" v-model="tenantNumber" id="ticker1" required="yes" placeholder="Phone Number..." /><br /><br />
                </div>
            </div>

            <div class="in-twos">
                <div class="input-wrapper">    
                    <label for="email">Lease Start Date</label>
                    <input class="input_small" v-model="startDate"  id="dob" required="yes" placeholder="YYYY-MM-DD" /><br /><br />
                </div>
                <div class="input-wrapper">
                    <label for="gender">Lease End Date</label>
                    <input class="input_small" v-model="endDate" id="gender" required="yes" placeholder="Male/Female" /><br /><br />
                </div>
            </div>

            <div class="in-twos">
                <div class="input-wrapper">
                    <label for="active">Rental Collection Method</label>
                    <input class="input_small" v-model="collectionMethod" id="active" required="yes" placeholder="Active Rental..." /><br /><br />
                </div>
                <div class="input-wrapper">
                    <label for="address">Rental Due Date</label>
                    <input class="input_small" v-model="rentalDueDate" id="address" required="yes" placeholder="Address.." /><br /><br />
                </div>
            </div>

            <div id="button-wrapper">
                <button class="primary-button" id="editInformation" type="button" v-on:click="addNewLease">Add New Lease</button>
            </div>
            </form>
            </div>
                <h1 class="main-heading" style=" margin-bottom: 0px; margin-top: 40px;"> Payment History</h1> 
                <div class="table_container"> 
                <table id="rental-table2">
                    <tr>
                    <th class='th-align-left'>Tenant Name <img src="@/assets/ArrowDown.png" alt="Filter"></th>
                    <th>Rate <img src="@/assets/ArrowDown.png" alt="Filter"></th>
                    <th>Month <img src="@/assets/ArrowDown.png" alt="Filter"></th>
                    <th >Payment Status <img src="@/assets/ArrowDown.png" alt="Filter"></th>
                    </tr>

            
                    <tr class="newTR" v-for="(lease, index) in paymentHistory" :key="lease.id" @click="handleRowClick(index)" >
                        <td class='td-align-left'>{{ lease.tenantName }}</td>
                        <td>{{ lease.rate}}</td>
                        <td>{{ lease.month }}</td>                                               
                        <td :class="{'Paid': lease.status === 'Paid','Pending': lease.status === 'Pending', 'Overdue' : lease.status ==='Overdue'}">{{ lease.status}}</td>
                    </tr>
                </table>

                </div>
                    <div id="button-wrapper">
                    <button class="primary-button" id="editInformation" type="button" v-on:click="createPaymentHistory">Add New Payment</button>
                    </div>
            </div>
            </div>

    <DeleteModal v-show="isModalVisible" @close="closeModal" @delete="confirmDelete" :title="title" :description='description' />
    <MessageModal v-show="isMessageModalVisible" @close="closeMessageModal" :message="modalMessage" />
    <CreateNewPaymentHistory v-show="isPaymentHistoryVisible" @close="closePayment" @savePaymentHistory="newPaymentHistory" :tenantName="tenantName"/>
    <EditPaymentStatus v-show="isEditPaymentStatusVisible" @close="closeEditStatus" @markAsPaid="markAsPaid" @markAsOverdue="markAsOverdue" :tenantName="tenantName" :month="indexMonth" :rate="indexRate"/>

</template>

<script>
import { db, auth} from "@/firebase.js";
import { collection, doc, getDoc, getDocs, query, updateDoc} from 'firebase/firestore'
import { getStorage, ref, getDownloadURL } from 'firebase/storage';
import {firebaseApp} from '../firebase.js'
import DeleteModal from '@/components/DeleteModal.vue';
import MessageModal from '@/components/MessageModal.vue';
import CreateNewPaymentHistory from '@/components/CreateNewPaymentHistory.vue';
import EditPaymentStatus from '@/components/EditPaymentStatus.vue';



export default {
    name: "ViewProperty", 
    props: {
        propertyID: String,
    },
    data() {
        return {
            // Binding of Property, Leases, Landlord and Tenant Data //
            propertyData: null, landlordData: null, propertyLeases: null, latestLease: null, tenantData: null, paymentHistory: null,
            // Enable the Input to be edited. Initially set as False, hence user will not be able to edit the data //
            openEditing: false,
            // Data Binding for Property and Landlord Data to Be Displayed Into Form //
            propertyName: '', propertyAddress: '',  landlordName: '', landlordNational: '', landlordEmail: '', landlordAddress: '', landlordNumber: 0, address: '',
            // Data Binding for Message Modal and Delete Modal //
            isModalVisible: false, title: '', description: '', modalMessage: '', isMessageModalVisible: false,
            // Data Binding for the Image of the Property from Firebase Storage //
            selectedImage: null, 
            // Data Binding for the Latest Lease for the Property //
            tenantID: null, tenantName: '', tenantNumber: '', monthlyRental : '', leaseTenure: '', startDate: '', endDate: '', collectionMethod: '', rentalDueDate: '',
            // Data Binding for Search Landlord Functionality when Updating the Property Information //
            searchResultsLandlord: [], selectedLandlord: null, landlordID: null, showDropdown: false,
            // Data Binding that Allow Users to CLick on the Status, Shows a Modal, and Update the Payment Status //
            isPaymentHistoryVisible: false, isEditPaymentStatusVisible: false, paymentIndex: null, indexRate: null, indexMonth: null
        }
    },
    components: {
        DeleteModal,
        MessageModal,
        CreateNewPaymentHistory,
        EditPaymentStatus
    },

    async mounted() { 
        const dbUser = doc(db, "Users", auth.currentUser.email);
     
        // Get Property Data from Database //
        const propertyDocument = 'Property';
        const propertyCollectionRef = collection(dbUser, propertyDocument);
        const propertyDocRef = doc(propertyCollectionRef, this.propertyID);
        await getDoc(propertyDocRef).then((doc) => {
            this.propertyData = doc.data();
        })

        // Get Landlord Data from Database //
        const landlordDocument = 'Landlord';
        const landlordCollectionRef = collection(dbUser, landlordDocument);
        const landlordDocRef = doc(landlordCollectionRef ,this.propertyData.landlordID);
        await getDoc(landlordDocRef).then((doc) => {
            this.landlordData = doc.data();
        })

        // Reference to Data //
        this.propertyName = this.propertyData.propertyName; 
        this.propertyAddress = this.propertyData.propertyAddress;
        this.landlordName = this.landlordData.landlordName;
        this.landlordNational = this.landlordData.landlordNationality;
        this.landlordNumber = this.landlordData.landlordNumber;
        this.landlordAddress = this.landlordData.landlordAddress;
        this.landlordEmail = this.landlordData.landlordEmail;
        this.landlordID = this.propertyData.landlordID;

        // Get Property Image from Firebase Storage //
        const storage = getStorage(firebaseApp);
        const storageRef = ref(storage, this.propertyData.picture);
        getDownloadURL(storageRef).then((url) => {
            this.selectedImage = url;
        })

        // Get All Leases Information associated with this Property //
        const leaseDocument = 'Lease';
        const leaseCollectionRef = collection(dbUser, leaseDocument);

        const qLease = query(leaseCollectionRef);
        const querySnapshotLease = await getDocs(qLease);
        const results = querySnapshotLease.docs
                .map((doc) => {
                    // Include the document ID in the mapped data object //
                    return { id: doc.id, ...doc.data() };
                }) // Filters only leases that belongs to this property //
                .filter((data) => data.propertyID === this.propertyID);

        this.propertyLeases = results;
        
        // Find the Latest Lease for the Property based on the endDate for each Lease //
        let latestLeaseTemp;
        if (this.propertyLeases.length !== 0) {
            latestLeaseTemp = this.propertyLeases[0].endDate.seconds;
            this.latestLease = this.propertyLeases[0];
            this.propertyLeases.forEach((lease) => {
                if (lease.endDate.seconds > latestLeaseTemp) { 
                    this.latestLease = lease; 
                    this.latestLeaseTemp = lease.endDate.seconds;
                }
            })
        } else { 
            // No Current Lease. Nothing to be displayed //
            this.latestLease =  { tenantID: 'no lease', propertyID: 'no lease', landlordID: 'no lease',  startDate: 'no lease', endDate: 'no lease',
                leaseTenure: 'no lease', collectionMethod: 'no lease', rentDueDate: 'no lease', leaseDocument: 'no lease', 
                            paymentHistory: [{tenantName: 'no lease', rate: 'no lease', month: 'no lease', status: 'no lease'}]}
        }

        // Binds the Latest Lease Data // 
        this.monthlyRental = this.latestLease.paymentHistory[0].rate; 
        this.leaseTenure = this.latestLease.leaseTenure;
        this.startDate = this.formatDate(this.latestLease.startDate);
        this.endDate = this.formatDate(this.latestLease.endDate);
        this.collectionMethod = this.latestLease.collectionMethod;
        this.rentalDueDate = this.latestLease.rentDueDate;

        if (this.latestLease.tenantID !== 'no lease') { 
            const propertyDocument = 'Tenant';
            const propertyCollectionRef = collection(dbUser, propertyDocument);
            const propertyDocRef = doc(propertyCollectionRef, this.latestLease.tenantID);
            await getDoc(propertyDocRef).then((doc) => {
                this.tenantData = doc.data();
            })
            this.tenantName = this.tenantData.tenantName;
            this.tenantNumber = this.tenantData.tenantNumber;

        } else {
            this.tenantName = 'no lease';
            this.tenantNumber = 'no lease';
        }

        this.paymentHistory = this.latestLease.paymentHistory;

    }, 
    watch: { 
        // Watch that perform SearchLandlord when edit is open and user enters new Landlord Name //
        landlordName: function () {
            if (this.openEditing) {
                if (this.selectedLandlord === null || this.landlordName === '') {
                    this.performSearchLandlord();
                } else { 
                    if (this.selectedLandlord.landlordName !== this.landlordName) { 
                        this.performSearchLandlord();
                    }
                }
            }

        }, 
    },
    methods: {
        // Routing to CreateNewLease.vue //
        addNewLease() { 
            this.$router.push({name: 'create-new-lease', params: {propertyID: this.propertyID, landlordID: this.landlordID}})
        },
        // Handles when User click on the Row in Payment History. Allow Users to Change Payment Status //
        handleRowClick(index) { 
            this.paymentIndex = index;
            this.indexMonth = this.paymentHistory[index].month; 
            this.indexRate = this.paymentHistory[index].rate;
            
            this.isEditPaymentStatusVisible = true; 
        },
        // Marks Payment History as Paid. Which Month to Change is handled by handleRowClick() //
        markAsPaid() { 
            // Get Lease Data //
            const dbUser = doc(db, "Users", auth.currentUser.email);
            const leaseDocument = 'Lease';
            const leaseCollectionRef = collection(dbUser, leaseDocument);
            const leaseDocRef = doc(leaseCollectionRef ,this.latestLease.id);
    
            // Set Payment Status as Paid //
            this.latestLease.paymentHistory[this.paymentIndex].status = "Paid";

            // Updates this on Firebase //
            updateDoc(leaseDocRef, this.latestLease)
                .then(() => {
                        this.showMessageModal("Payment Status Updated Successfully!")
                })
                .catch((error) => {
                        alert("Error editing information: ", error)
            })
            
            // Updates the New Payment History on the UI //
            this.paymentHistory = this.latestLease.paymentHistory; 
            this.closeEditStatus();             
        },
        // Marks Payment History as Overdue. Which Month to Change is handled by handleRowClick() //
        markAsOverdue() { 
            const dbUser = doc(db, "Users", auth.currentUser.email);
            const leaseDocument = 'Lease';
            const leaseCollectionRef = collection(dbUser, leaseDocument);
            const leaseDocRef = doc(leaseCollectionRef ,this.latestLease.id);
     
            // Set Payment Status as Paid //
            this.latestLease.paymentHistory[this.paymentIndex].status = "Overdue";

            // Updates this on Firebase //
            updateDoc(leaseDocRef, this.latestLease)
                .then(() => {
                        this.showMessageModal("Payment Status Updated Successfully!")
                })
                .catch((error) => {
                        alert("Error editing information: ", error)
            })

            // Updates the New Payment History on the UI //
            this.paymentHistory = this.latestLease.paymentHistory;       
            this.closeEditStatus();     
        },
        // Closes EditPaymentStatus Modal //
        closeEditStatus() { 
            this.isEditPaymentStatusVisible = false; 
        },
        // Handles Create New Payment History. Opends CreateNewPaymentHistoryModal //
        createPaymentHistory() { 
            this.isPaymentHistoryVisible = true;
            this.tenantNameLater = this.tenantName;
        },
        // Closes CreateNewPayment Modal //
        closePayment() { 
            this.isPaymentHistoryVisible = false;
        },
        // Show Message Modal //
        showMessageModal(otherMessage) {
            this.isMessageModalVisible = true;
            this.modalMessage = otherMessage;
        },
        // Closes Message Modal //
        closeMessageModal() {
            this.isMessageModalVisible = false;
        },
        // Shows Delete Modal //
        showModal(otherTitle, otherDescription) {
            this.isModalVisible = true;
            this.title = otherTitle;
            this.description = otherDescription;
        },
        // Closes Delete Modal //
        closeModal() {
            this.isModalVisible = false;
        },
        // Delete Not Implemented, but will handle the delete on firebase //
        confirmDelete() { 
            console.log("DELETE CONFIRMED");
            this.closeModal(); 
        },
        // Handles the emitted event, when a new Payment History is created by CreateNewPayment.vue Modal //
        newPaymentHistory(dataList) { 
            // Extract Information of this lease //
            const dbUser = doc(db, "Users", auth.currentUser.email);
            const leaseDocument = 'Lease';
            const leaseCollectionRef = collection(dbUser, leaseDocument);
            const leaseDocRef = doc(leaseCollectionRef ,this.latestLease.id);
            
            // Concat New Payment into Payment History Array //
            this.latestLease.paymentHistory = this.latestLease.paymentHistory.concat({tenantName: this.tenantName, rate: dataList.rate, month: dataList.month, status: 'Pending'})
            updateDoc(leaseDocRef, this.latestLease)
                .then(() => {
                        this.showMessageModal("New Payment History Added Successfully!")
                })
                .catch((error) => {
                        alert("Error editing information: ", error)
            })

            // Updates UI //
            this.paymentHistory = this.latestLease.paymentHistory;
            this.closePayment();
        },
        // Handles when user clicks on delete button. Popup for comfirmation //
        startDelete() {
            this.showModal("Are you sure you want to delete this Property?",
                            "Deleteting this Property will delete all leases as well");
        },
        // Formats Timestamp to Date Format for Display //
        formatDate(timestamp) {
            const date = new Date(timestamp.seconds * 1000); // Convert timestamp to Date
            const day = date.getDate();
            const month = date.toLocaleString('default', { month: 'long' });
            const year = date.getFullYear();
            return `${year} ${month} ${day}`;

      },
        // Formats Timestamp to Date Format for Display //
        formatDateMonth(timestamp) {
            const date = new Date(timestamp.seconds * 1000); // Convert timestamp to Date
            const month = date.toLocaleString('default', { month: 'long' });
            const year = date.getFullYear();
            return `${month} ${year}`;

      },    
        // Seach Landlord based on LandlordName Edit when User enables Editing //
        async performSearchLandlord() {
            const landlordDocument = 'Landlord';
            const dbUser = doc(db, "Users", auth.currentUser.email);
            const landlordCollectionRef = collection(dbUser, landlordDocument);

            const q = query(landlordCollectionRef);
            const querySnapshot = await getDocs(q);
            const results = querySnapshot.docs
                .map((doc) => {
                    // Include the document ID in the mapped data object //
                    return { id: doc.id, ...doc.data() };
                }) // Filters Landlord that has similar landlordName in the search input //
                .filter((data) => data.landlordName.includes(this.landlordName));

            this.searchResultsLandlord = results;
            
               /* 
                Show Dropdown of Searches based on few Condition 
                - When no reporter is selected 
                - When selected reporter is different from the inputted reporter name -> User wants to change reporter
                - When search result has 1 or more reporter that has this reporter name  
            */
            if (this.landlordName === '') {
                this.showDropdown = false; 
            } else { 
                this.showDropdown = this.searchResultsLandlord.length > 0;
                if (this.selectedLandlord !== null) {
                    if (this.selectedLandlord.landlordName === this.landlordName) {
                        this.showDropdown = true;
                    } else { 
                        this.showDropdown = true;
                    }
                } else { 
                    this.showDropdown = this.searchResultsLandlord.length > 0;
                }
            }

        },
        // Handles the selection of Landlord when clicked on the dropdown box //
        async selectLandlord(landlord) { 
            this.selectedLandlord = landlord;
            this.landlordAddress = landlord.landlordAddress;
            this.landlordEmail = landlord.landlordEmail;
            this.landlordNumber = landlord.landlordNumber; 
            this.landlordNational = landlord.landlordNationality;
            this.landlordID = landlord.id;
            this.showDropdown = false;
            this.landlordName = landlord.landlordName;

        },
        // Handles the Edit Functionality //
        // When Edit is Active, allow users to update data, and update doc on firebase accordingly //
        editInformation() { 
            const button = document.getElementById('editInformation')
            const currentStatus = button.innerText;

            // Opening Editing //
            if (currentStatus === "Edit Information") {
                button.innerText = "Save Edits";
                this.openEditing = true;
                button.className = "secondary-button";

            } else {
                // Close Editing and Update New Information //
                button.innerText = "Edit Information";
                this.openEditing = false;
                button.className = "primary-button";
                
                // Initialise Property Data //
                const dbUser = doc(db, "Users", auth.currentUser.email);
                const propertylordDocument = 'Property';
                const propertyCollectionRef = collection(dbUser, propertylordDocument);
                const propertyDocRef = doc(propertyCollectionRef ,this.propertyID);

                // Extract all Data Bindings from the Form to be Update //
                const updatedData = {landlordID: this.landlordID, propertyAddress: this.propertyAddress, propertyName: this.propertyName, 
                                        picture: this.propertyData.picture, leasesID: this.propertyData.leasesID};

                // Update Doc with new Data //
                updateDoc(propertyDocRef, updatedData)
                    .then(() => {
                        this.showMessageModal("Property Information has been Updated Successfully!")
                    })
                    .catch((error) => {
                        alert("Error editing information: ", error)
                })
            }
        }
    }
}


</script>

<style scoped>
.grid-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    /* grid-template-rows: 95vh 95vh; */
    height: fit-content;
    
}

.left-grid-container {
    display: grid;
    grid-template-rows: 52.5vh 42.5vh;
}

.grid-item {
    background-color: white; 
    border-radius: 10px;
    margin: 0px 10px;
    padding: 30px 40px;
    height: fit-content;
    min-height: 100vh;
}

.main-heading {
    margin-bottom: 30px;
}

.in-twos{
    display: flex;
    justify-content: space-between;
}

.input-wrapper {
    display: flex;
    flex-direction: column;
    width: 50%;
}

label {
    font-size: 18px;
    font-weight: 500;
    margin-bottom: 15px;

}

.input_small { 
    background-color: #F1F4FA;
    height: 45px;
    padding-left: 15px;
    border-radius: 10px;
    width: 80%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1); 
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

.input-wrapper_2{
    display: flex;
    flex-direction: column;
    width: 100%;
}


.input_small_wide { 
    background-color: #F1F4FA;
    height: 45px;
    padding-left: 15px;
    border-radius: 10px;
    width: 90%;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1); 
    border: 0px;
    font-size: 15px;
    color: rgba(6, 21, 43, 0.7);
}

#button-wrapper {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    width: 100%;
}

.primary-button {
    height: 50px;
    width: 240px;
    background-color: var(--primary-accent);
    color: white; 
    font-size: 18px;
    border-radius: 10px;
    border: 0px;
    cursor: pointer;
}

.secondary-button { 
    height: 50px;
    width: 240px;
    background-color: white;
    color: black; 
    font-size: 18px;
    border-radius: 10px;
    border: 2px var(--primary-accent) solid;
}

.delete-button { 
    height: 50px;
    width: 240px;
    background-color: #CE2F42;
    color: white; 
    font-size: 18px;
    border-radius: 10px;
    border: 0px;
}


#rental-table { 
  width: 100%;
  padding: 10px 0px;
  border-collapse: separate;
  border-spacing: 0 1em;
}

#rental-table2 { 
  width: 100%;
  padding: 10px 0px;
  border-collapse: separate;
  border-spacing: 0 1em;
}

#rental-table2 tr:hover { 
    font-size: 18px;
    cursor: pointer;
}

.table_container {
    max-height: 400px;
    overflow-y: auto;
}

tr { 
    padding-bottom: 30px;
}

th {
  padding: 5px;
  font-size: 18px;
  background-color: white;
  text-align: center;
  color: black;

}

.th-align-left {
  padding: 5px;
  font-size: 18px;
  background-color: white;
  text-align: left;
  color: black;
}

td {
  padding: 5px;
  font-size: 16px;
  border-bottom: 1px rgb(177, 177, 177) solid;
  text-align: center;
  padding-bottom: 15px;
  
}

.td-align-left{
  padding: 5px;
  font-size: 16px;
  background-color: white;
  border-bottom: 1px rgb(177, 177, 177) solid;
  text-align: left;
  color: var(--primary-accent);
  padding-bottom: 15px;
}

img { 
    margin-left:5px; 
    cursor:pointer; 
    vertical-align: middle; 

}


.comment-section {
    background-color: #F1F4FA;
    height: 90%;
    width: 95%;
    border-radius: 10px;
    padding-left: 20px;
    padding-right: 20px;
    padding-top: 10px;

}

p { 
    color: rgba(6, 21, 43, 0.6);
}

#imageContainer_2 { 
    width: 95%; 
    height: 400px;
    display: flex; 
    justify-content: center;
    align-items: flex-start;
    margin-bottom: 30px;
    
}

#selectedImage_2 {
    width: 100%; 
    height: 400px;
    object-fit: contain;
}

.Paid {
    color: green;
}

.Pending {
    color: orange;
}

.Overdue { 
    color: red;
}
.dropdown {
    background-color: #F1F4FA;
    z-index: 999;
    margin-top: 80px;
    border-radius: 10px;
    position: absolute;
}

.option {
    border: 1px solid black;
    padding: 6px;
    margin-top: 5px;
    box-shadow: 2px 0px 2px rgba(0, 0, 0, 0.1); 
    border-radius: 5px;

}
</style>