<template>
    <DashboardCharts/> 
</template>

<script setup>

   import DashboardCharts from '@/components/DashboardCharts.vue'

</script>

<style scoped></style>
